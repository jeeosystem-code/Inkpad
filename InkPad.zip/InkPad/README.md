# InkPad
Native Android (Kotlin, no WebView) note-taking + PDF annotation app.

## Fonts
Bundled in `app/src/main/assets/fonts` (licenses in `assets/fonts/licenses`), all under the SIL Open Font License 1.1:
Plus Jakarta Sans (interface + Sans text), Lora (Serif text), JetBrains Mono (Mono text), Caveat (Hand text).

## Build
Upload this folder or zip to GitHub with the build.yml workflow, run "Build APK",
download the `InkPad-debug-apk` artifact.
