# InkPad
Native Android (Kotlin, no WebView) note-taking + PDF annotation app.

## Build the APK on GitHub
1. Create a new GitHub repo and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Open the repo > Actions > "Build APK" > Run workflow (it also runs on every push to main).
3. When it finishes, download the artifact `InkPad-debug-apk` and install the .apk.
