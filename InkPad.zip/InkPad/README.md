# InkPad
Native Android (Kotlin, no WebView) note-taking + PDF annotation app.
Glass UI, vector icon set, light/dark themes, pressure-sensitive pen.

Build: upload this zip (or the folder) to GitHub with the build.yml workflow, run "Build APK",
download the `InkPad-debug-apk` artifact.
