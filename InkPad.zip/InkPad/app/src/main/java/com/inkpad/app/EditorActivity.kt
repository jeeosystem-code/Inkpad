package com.inkpad.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors
import kotlin.math.max

class EditorActivity : Activity() {

    private val REQ_IMG = 11
    private val REQ_PDF = 12
    private val REQ_PNG = 13

    private lateinit var nb: Notebook
    private var pdf: PdfSource? = null
    private lateinit var env: ImgEnv
    private lateinit var view: NoteView
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var subTv: TextView
    private lateinit var undoBtn: IconView
    private lateinit var redoBtn: IconView
    private lateinit var stack: LinearLayout
    private lateinit var selBar: LinearLayout
    private lateinit var panel: InteractLayout
    private lateinit var dock: HorizontalScrollView
    private lateinit var exitFocus: FrameLayout
    private lateinit var scorePill: LinearLayout
    private lateinit var scoreTv: TextView

    private class ToolBtn(val box: LinearLayout, val icon: IconView, val name: TextView)

    private val toolBtns = HashMap<Int, ToolBtn>()
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val saveRun = Runnable { saveNow(false) }
    private var ready = false
    private var topI = 0
    private var botI = 0
    private var focus = false
    private var panelOpen = true
    private var saveState = ""
    private val hidePanelRun = Runnable { hidePanel() }

    private var recorder: MediaRecorder? = null
    private var recName: String? = null
    private var player: MediaPlayer? = null

    private val penColors = intArrayOf(
        0xFF111111.toInt(), 0xFF6B7280.toInt(), 0xFFEF4444.toInt(), 0xFFF59E0B.toInt(),
        0xFF22C55E.toInt(), 0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFFFFFFF.toInt()
    )
    private val laserColors = intArrayOf(
        0xFFFF2828.toInt(), 0xFF22C55E.toInt(), 0xFF3B82F6.toInt(), 0xFFFFC53D.toInt(), 0xFFFF4DD2.toInt()
    )
    private val stickyColors = intArrayOf(
        0xFFFFF59D.toInt(), 0xFFFFCDD2.toInt(), 0xFFBBDEFB.toInt(), 0xFFC8E6C9.toInt(), 0xFFFFE0B2.toInt()
    )
    private var exportOnly = -1
    private var pngWidth = 1600
    private val hlColors = intArrayOf(
        0xFFFFEB3B.toInt(), 0xFF76FF03.toInt(), 0xFFFF4081.toInt(),
        0xFF18FFFF.toInt(), 0xFFFF9100.toInt(), 0xFFB388FF.toInt()
    )
    private val colorTools = intArrayOf(
        NoteView.PEN, NoteView.HL, NoteView.SHAPE, NoteView.TEXT, NoteView.STICKY,
        NoteView.TABLE, NoteView.TAPE, NoteView.RULER, NoteView.LASER
    )
    private val sizeTools = intArrayOf(
        NoteView.PEN, NoteView.HL, NoteView.ERASER, NoteView.TEXT, NoteView.STICKY,
        NoteView.SHAPE, NoteView.RULER, NoteView.TABLE, NoteView.LASER
    )

    // id, icon, label  (-2 = separator, -1 = image action)
    private fun toolDefs(): List<Triple<Int, Int, String>> {
        val l = ArrayList<Triple<Int, Int, String>>()
        l.add(Triple(NoteView.HAND, Ic.HAND, "Move"))
        if (nb.review) {
            l.add(Triple(NoteView.MARK, Ic.CHECK_CIRCLE, "Marks"))
            l.add(Triple(NoteView.SECTION, Ic.SECTION, "Section"))
            l.add(Triple(-2, 0, ""))
        }
        l.add(Triple(NoteView.PEN, Ic.PEN, "Pen"))
        l.add(Triple(NoteView.HL, Ic.HL, "Marker"))
        l.add(Triple(NoteView.ERASER, Ic.ERASER, "Eraser"))
        l.add(Triple(NoteView.LASSO, Ic.LASSO, "Select"))
        l.add(Triple(-2, 0, ""))
        l.add(Triple(NoteView.SHAPE, Ic.SHAPES, "Shapes"))
        l.add(Triple(NoteView.TEXT, Ic.TEXT, "Text"))
        l.add(Triple(NoteView.STICKY, Ic.STICKY, "Note"))
        l.add(Triple(-1, Ic.IMAGE, "Image"))
        l.add(Triple(NoteView.TABLE, Ic.TABLE, "Table"))
        l.add(Triple(NoteView.TAPE, Ic.TAPE, "Tape"))
        l.add(Triple(NoteView.RULER, Ic.RULER, "Ruler"))
        l.add(Triple(NoteView.LASER, Ic.LASER, "Laser"))
        return l
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        Theme.apply(this)
        val id = intent.getStringExtra("id")
        val loaded = if (id != null) Store.load(this, id) else null
        if (loaded == null) {
            toast("Could not open notebook")
            finish()
            return
        }
        nb = loaded
        env = ImgEnv(Store.dir(this, nb.id))
        if (nb.hasPdf) {
            try {
                pdf = PdfSource(File(Store.dir(this, nb.id), "doc.pdf"))
            } catch (t: Throwable) {
                toast("The PDF could not be opened")
                finish()
                return
            }
        }
        edgeToEdge()
        buildUi()
        ready = true
    }

    // ============================ building the UI ============================

    private fun ibtn(icon: Int, onClick: (View) -> Unit): IconView {
        val v = IconView(this, icon, Theme.text(), 0.56f)
        v.isClickable = true
        v.pressable()
        v.setOnClickListener {
            tick(it)
            onClick(it)
        }
        return v
    }

    private fun tick(v: View) {
        if (Prefs.bool(this, "haptic", true)) v.tick()
    }

    private fun applyPrefs() {
        view.fingerDraw = Prefs.bool(this, "finger", true)
        view.pressure = Prefs.bool(this, "pressure", true)
        view.momentum = Prefs.bool(this, "momentum", true)
        view.viewMode = Prefs.intOf(this, "view_layout", 0)
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Theme.surround())

        view = NoteView(this, nb, pdf, env)
        view.surround = Theme.surround()
        applyPrefs()
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        topBar = buildTopBar()
        root.addView(topBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56), Gravity.TOP))

        selBar = buildSelBar()
        panel = InteractLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.onTouch = { schedulePanelHide() }
        panel.background = glass(24f)
        panel.elevation = dpf(6f)
        panel.visibility = View.GONE
        dock = buildDock()

        stack = LinearLayout(this)
        stack.orientation = LinearLayout.VERTICAL
        stack.addView(selBar, stackLp())
        stack.addView(panel, stackLp())
        stack.addView(dock, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)))
        root.addView(stack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        exitFocus = FrameLayout(this)
        exitFocus.background = glass(24f, true)
        exitFocus.elevation = dpf(6f)
        exitFocus.visibility = View.GONE
        exitFocus.addView(IconView(this, Ic.FOCUS, Theme.text(), 0.5f), FrameLayout.LayoutParams(dp(48), dp(48)))
        exitFocus.isClickable = true
        exitFocus.pressable()
        exitFocus.setOnClickListener { setFocus(false) }
        root.addView(exitFocus, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.BOTTOM or Gravity.END))

        scorePill = LinearLayout(this)
        scorePill.orientation = LinearLayout.HORIZONTAL
        scorePill.gravity = Gravity.CENTER_VERTICAL
        scorePill.background = glass(22f, true)
        scorePill.elevation = dpf(6f)
        scorePill.setPadding(dp(12), 0, dp(14), 0)
        scorePill.addView(IconView(this, Ic.CHART, Theme.accent, 0.8f), LinearLayout.LayoutParams(dp(22), dp(22)))
        scoreTv = label("0", 17f, Theme.text(), Fonts.bold, true)
        scoreTv.setPadding(dp(6), 0, 0, 0)
        scorePill.addView(scoreTv)
        scorePill.isClickable = true
        scorePill.pressable()
        scorePill.setOnClickListener {
            tick(it)
            showScore()
        }
        scorePill.visibility = if (nb.review) View.VISIBLE else View.GONE
        root.addView(scorePill, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40), Gravity.TOP or Gravity.END))

        setContentView(root)

        view.onChanged = {
            saveState = "Saving…"
            updateUndo()
            scheduleSave()
        }
        view.onSelection = { has ->
            selBar.visibility = if (has) View.VISIBLE else View.GONE
        }
        view.onPage = { updateSub() }
        view.onToolChanged = {
            panelOpen = true
            refreshTools()
            refreshProps(true)
        }
        view.onText = { existing, pg, x, y, sticky -> askText(existing, pg, x, y, sticky) }
        view.onTable = { pg, r -> askTable(pg, r) }
        view.onSection = { pg, y -> askSection(pg, y, null) }
        view.onDividerTap = { d, pg ->
            tileSheet(
                d.name,
                listOf(
                    Tile(Ic.EDIT, "Rename") { askSection(pg, d.y, d) },
                    Tile(Ic.TRASH, "Delete") { view.removeItem(pg, d) }
                )
            )
        }
        view.onGesture = { tick(view) }
        view.onInteract = { down ->
            if (down && view.tool != NoteView.HAND && view.tool != NoteView.LASER && view.tool != NoteView.MARK &&
                panel.visibility == View.VISIBLE && Prefs.bool(this, "panel_autohide", true)
            ) {
                handler.removeCallbacks(hidePanelRun)
                handler.postDelayed(hidePanelRun, 700L)
            }
            if (!focus && Prefs.bool(this, "autohide", true)) {
                val a = if (down) 0.14f else 1f
                topBar.animate().alpha(a).setDuration(if (down) 120L else 240L).start()
                stack.animate().alpha(a).setDuration(if (down) 120L else 240L).start()
            }
        }

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, ins ->
            topI = ins.systemWindowInsetTop
            botI = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        root.requestApplyInsets()

        refreshTools()
        refreshProps(false)
        updateUndo()
        applyInsets()
        if (nb.review) startReviewTool()
    }

    private fun stackLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(8)
        return lp
    }

    private fun applyInsets() {
        val tl = topBar.layoutParams as FrameLayout.LayoutParams
        val maxW = dp(760)
        val availW = resources.displayMetrics.widthPixels - dp(24)
        val useW = minOf(availW, maxW)
        tl.topMargin = topI + dp(8)
        tl.leftMargin = dp(12)
        tl.rightMargin = dp(12)
        tl.width = useW
        tl.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        topBar.layoutParams = tl
        val sl = stack.layoutParams as FrameLayout.LayoutParams
        sl.bottomMargin = botI + dp(10)
        sl.leftMargin = dp(12)
        sl.rightMargin = dp(12)
        sl.width = useW
        sl.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        stack.layoutParams = sl
        val el = exitFocus.layoutParams as FrameLayout.LayoutParams
        el.bottomMargin = botI + dp(18)
        el.rightMargin = dp(16)
        exitFocus.layoutParams = el
        val pl = scorePill.layoutParams as FrameLayout.LayoutParams
        pl.topMargin = topI + dp(8) + dp(56) + dp(8)
        pl.rightMargin = dp(12)
        scorePill.layoutParams = pl
        view.setInsets((topI + dp(8) + dp(56) + dp(6)).toFloat(), (botI + dp(10) + dp(66) + dp(8)).toFloat())
    }

    private fun buildTopBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = glass(24f)
        bar.elevation = dpf(6f)
        bar.setPadding(dp(4), 0, dp(6), 0)

        val back = ibtn(Ic.BACK) { finish() }
        titleTv = label(nb.title, 16f, Theme.text(), Fonts.medium)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        titleTv.setOnClickListener { askRename() }
        subTv = label("", 11f, Theme.sub(), Fonts.regular, true)
        subTv.setOnClickListener { askGoTo() }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(4), 0, dp(4), 0)
        col.addView(titleTv)
        col.addView(subTv)

        undoBtn = ibtn(Ic.UNDO) {
            view.undo()
            updateUndo()
        }
        redoBtn = ibtn(Ic.REDO) {
            view.redo()
            updateUndo()
        }
        val pagesBtn = ibtn(Ic.PAGES) { showPages() }
        val moreBtn = ibtn(Ic.MORE) { showMore() }

        bar.addView(back, LinearLayout.LayoutParams(dp(46), dp(52)))
        bar.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(undoBtn, LinearLayout.LayoutParams(dp(46), dp(52)))
        bar.addView(redoBtn, LinearLayout.LayoutParams(dp(46), dp(52)))
        bar.addView(pagesBtn, LinearLayout.LayoutParams(dp(46), dp(52)))
        bar.addView(moreBtn, LinearLayout.LayoutParams(dp(46), dp(52)))
        return bar
    }

    private fun buildSelBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.background = glass(24f)
        bar.elevation = dpf(6f)
        bar.visibility = View.GONE
        bar.setPadding(dp(6), dp(4), dp(6), dp(4))
        fun item(icon: Int, name: String, tint: Int, a: () -> Unit) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            box.addView(IconView(this, icon, tint, 0.62f), LinearLayout.LayoutParams(dp(40), dp(28)))
            val t = label(name, 10f, tint, Fonts.medium)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            box.addView(t)
            box.isClickable = true
            box.pressable()
            box.setOnClickListener {
                tick(it)
                a()
            }
            bar.addView(box, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        item(Ic.CLIPBOARD, "Copy", Theme.text()) {
            view.copySelection()
            toast("Copied")
        }
        item(Ic.COPY, "Clone", Theme.text()) { view.duplicateSelection() }
        item(Ic.DROP, "Color", Theme.text()) { view.recolorSelection(view.penColor) }
        item(Ic.CHEV_UP, "Front", Theme.text()) { view.reorderSelection(true) }
        item(Ic.CHEV_DOWN, "Back", Theme.text()) { view.reorderSelection(false) }
        item(Ic.TRASH, "Delete", Theme.danger) { view.deleteSelection() }
        item(Ic.CLOSE, "Done", Theme.text()) { view.clearSelection() }
        return bar
    }

    private fun buildDock(): HorizontalScrollView {
        val sv = HorizontalScrollView(this)
        sv.background = glass(26f)
        sv.elevation = dpf(8f)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(6), dp(8), dp(6))
        for ((id, ic, name) in toolDefs()) {
            if (id == -2) {
                val sep = View(this)
                sep.setBackgroundColor(Theme.field())
                val lp = LinearLayout.LayoutParams(dp(1), dp(30))
                lp.setMargins(dp(4), 0, dp(4), 0)
                row.addView(sep, lp)
                continue
            }
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            val icon = IconView(this, ic, Theme.sub(), 0.66f)
            box.addView(icon, LinearLayout.LayoutParams(dp(34), dp(28)))
            val tv = label(name, 10.5f, Theme.sub(), Fonts.medium)
            tv.gravity = Gravity.CENTER
            box.addView(tv)
            box.isClickable = true
            box.pressable()
            box.setOnClickListener {
                tick(it)
                if (id == -1) {
                    openImagePicker()
                } else if (view.tool == id && id != NoteView.HAND && id != NoteView.LASSO && id != NoteView.LASER) {
                    panelOpen = !panelOpen
                    refreshProps(true)
                } else {
                    view.selectTool(id)
                    if (id == NoteView.SHAPE) panelOpen = true
                }
            }
            if (id >= 0) toolBtns[id] = ToolBtn(box, icon, tv)
            row.addView(box, LinearLayout.LayoutParams(dp(58), dp(54)))
        }
        sv.addView(row)
        return sv
    }

    private fun refreshTools() {
        for ((id, b) in toolBtns) {
            val sel = id == view.tool
            b.box.background = if (sel) accentFill(18f) else null
            b.icon.set(b.icon.icon, if (sel) Color.WHITE else Theme.sub())
            b.name.setTextColor(if (sel) Color.WHITE else Theme.sub())
            if (id == NoteView.MARK) b.name.text = Review.fmt(view.currentMark)
        }
    }

    private fun updateUndo() {
        undoBtn.alpha = if (view.canUndo()) 1f else 0.3f
        redoBtn.alpha = if (view.canRedo()) 1f else 0.3f
        updateScore()
        updateSub()
    }

    private fun updateSub() {
        var s = "Page ${view.currentPage() + 1} of ${nb.pages.size}"
        if (recorder != null) s += "  ·  ● Recording"
        else if (saveState.isNotEmpty()) s += "  ·  $saveState"
        subTv.text = s
    }

    // ============================ tool options panel ============================

    private fun range(t: Int): Pair<Float, Float> = when (t) {
        NoteView.HL -> Pair(6f, 40f)
        NoteView.ERASER -> Pair(4f, 40f)
        NoteView.TEXT, NoteView.STICKY -> Pair(10f, 60f)
        NoteView.LASER -> Pair(4f, 24f)
        else -> Pair(1f, 20f)
    }

    private fun getW(t: Int): Float = when (t) {
        NoteView.HL -> view.hlW
        NoteView.ERASER -> view.eraserW
        NoteView.TEXT, NoteView.STICKY -> view.textSize
        NoteView.LASER -> view.laserW
        else -> view.penW
    }

    private fun setW(t: Int, v: Float) {
        when (t) {
            NoteView.HL -> view.hlW = v
            NoteView.ERASER -> view.eraserW = v
            NoteView.TEXT, NoteView.STICKY -> view.textSize = v
            NoteView.LASER -> view.laserW = v
            else -> view.penW = v
        }
    }

    private fun refreshProps(animate: Boolean) {
        refreshPropsInner(animate)
        schedulePanelHide()
    }

    private fun schedulePanelHide() {
        handler.removeCallbacks(hidePanelRun)
        if (Prefs.bool(this, "panel_autohide", true) && panelOpen && panel.visibility == View.VISIBLE) {
            handler.postDelayed(hidePanelRun, panelDelay())
        }
    }

    // Floating tool menus in other apps stay up for about 3 s of inactivity
    // (Android's own media controller uses 3 s, video players 3-5 s). The mark palette gets longer.
    private fun panelDelay(): Long {
        val base = when (Prefs.intOf(this, "panel_delay", 1)) {
            0 -> 2000L
            2 -> 5000L
            3 -> 8000L
            else -> 3000L
        }
        return if (view.tool == NoteView.MARK) max(base, 5000L) else base
    }

    private fun hidePanel() {
        if (panel.visibility != View.VISIBLE) return
        panelOpen = false
        panel.animate().alpha(0f).translationY(dp(10).toFloat()).setDuration(180).withEndAction {
            panel.visibility = View.GONE
            panel.alpha = 1f
            panel.translationY = 0f
        }.start()
    }

    private fun refreshPropsInner(animate: Boolean) {
        panel.animate().cancel()
        panel.alpha = 1f
        panel.translationY = 0f
        val t = view.tool
        val hasColors = colorTools.contains(t)
        val hasSize = sizeTools.contains(t)
        panel.removeAllViews()
        if (t == NoteView.MARK) {
            if (!panelOpen) {
                panel.visibility = View.GONE
                return
            }
            panel.visibility = View.VISIBLE
            panel.setPadding(dp(12), dp(10), dp(12), dp(10))
            panel.addView(buildMarks())
            if (animate) {
                panel.alpha = 0f
                panel.animate().alpha(1f).setDuration(160).start()
            }
            return
        }
        val hasExtra = t == NoteView.LASSO || t == NoteView.ERASER || t == NoteView.PEN || t == NoteView.HL ||
            t == NoteView.RULER || t == NoteView.SHAPE
        if (!(hasColors || hasSize || hasExtra) || !panelOpen) {
            panel.visibility = View.GONE
            return
        }
        panel.visibility = View.VISIBLE
        panel.setPadding(dp(12), dp(8), dp(12), dp(8))
        if (hasColors) panel.addView(buildColors(t))
        if (hasSize) panel.addView(buildSize(t))
        if (t == NoteView.SHAPE) panel.addView(buildShapes())
        val ex = buildExtras(t)
        if (ex != null) panel.addView(ex)
        if (animate) {
            panel.alpha = 0f
            panel.animate().alpha(1f).setDuration(160).start()
        }
    }

    private fun applyColor(c: Int) {
        if (view.tool == NoteView.LASER) {
            view.laserColor = c
        } else if (view.tool == NoteView.HL) {
            view.hlColor = c
        } else {
            view.penColor = c
            Prefs.addRecent(this, c)
        }
        refreshProps(false)
    }

    private fun buildColors(t: Int): View {
        val sv = HorizontalScrollView(this)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val cur = if (t == NoteView.LASER) view.laserColor else view.toolColor()
        val list = ArrayList<Int>()
        val pal = if (t == NoteView.HL) hlColors else if (t == NoteView.LASER) laserColors else penColors
        for (c in pal) list.add(c)
        if (t != NoteView.HL && t != NoteView.LASER) {
            for (c in Prefs.recent(this)) if (!list.contains(c) && list.size < pal.size + 5) list.add(c)
        }
        for (c in list) {
            val sel = c == cur
            val sw = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c)
            g.setStroke(if (sel) dp(3) else dp(1), if (sel) Theme.accent else (if (Theme.dark) 0x44FFFFFF else 0x33000000))
            sw.background = g
            sw.pressable()
            sw.setOnClickListener {
                tick(it)
                applyColor(c)
            }
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.setMargins(dp(3), dp(2), dp(3), dp(2))
            row.addView(sw, lp)
        }
        val custom = FrameLayout(this)
        val rg = GradientDrawable()
        rg.shape = GradientDrawable.OVAL
        rg.gradientType = GradientDrawable.SWEEP_GRADIENT
        rg.colors = intArrayOf(
            0xFFFF4D4D.toInt(), 0xFFFFC53D.toInt(), 0xFF4DFF88.toInt(),
            0xFF3DD6FF.toInt(), 0xFF8B5CF6.toInt(), 0xFFFF4D4D.toInt()
        )
        custom.background = rg
        custom.addView(IconView(this, Ic.PLUS, Color.WHITE, 0.6f), FrameLayout.LayoutParams(dp(40), dp(40)))
        custom.pressable()
        custom.setOnClickListener {
            tick(it)
            colorSheet(cur) { c -> applyColor(c) }
        }
        val clp = LinearLayout.LayoutParams(dp(40), dp(40))
        clp.setMargins(dp(3), dp(2), dp(3), dp(2))
        row.addView(custom, clp)
        sv.addView(row)
        return sv
    }

    private fun buildSize(t: Int): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, 0)
        val name = when (t) {
            NoteView.ERASER -> "Eraser"
            NoteView.TEXT, NoteView.STICKY -> "Text size"
            else -> "Size"
        }
        val lab = label(name, 12f, Theme.sub(), Fonts.medium)
        val prev = BrushPreview(this)
        val valTv = label("", 12f, Theme.text(), Fonts.medium)
        valTv.gravity = Gravity.END
        val sb = SeekBar(this)
        sb.max = 100
        val tint = ColorStateList.valueOf(Theme.accent)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        val density = resources.displayMetrics.density
        fun refresh() {
            val w = getW(t)
            prev.color = if (t == NoteView.HL) view.hlColor else if (t == NoteView.LASER) view.laserColor else view.penColor
            prev.ring = t == NoteView.ERASER
            prev.diameter = if (t == NoteView.TEXT || t == NoteView.STICKY) w * density * 0.7f else w * density * 0.8f
            prev.invalidate()
            valTv.text = w.toInt().toString()
        }
        val r = range(t)
        sb.progress = ((getW(t) - r.first) / (r.second - r.first) * 100f).toInt().coerceIn(0, 100)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                setW(t, r.first + (r.second - r.first) * p / 100f)
                refresh()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        refresh()
        row.addView(lab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(valTv, LinearLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.WRAP_CONTENT))
        val plp = LinearLayout.LayoutParams(dp(44), dp(44))
        plp.leftMargin = dp(6)
        row.addView(prev, plp)
        return row
    }

    private fun buildShapes(): View {
        val sv = HorizontalScrollView(this)
        sv.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(6), 0, 0)
        for ((i, n) in SHAPE_NAMES.withIndex()) {
            val c = chipView(n, view.shapeKind == i)
            c.setOnClickListener {
                tick(it)
                view.shapeKind = i
                refreshProps(false)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(6)
            row.addView(c, lp)
        }
        val fill = chipView(if (view.shapeFill) "Fill: on" else "Fill: off", view.shapeFill)
        fill.setOnClickListener {
            tick(it)
            view.shapeFill = !view.shapeFill
            refreshProps(false)
        }
        row.addView(fill)
        sv.addView(row)
        return sv
    }

    // ============================ extra tool options ============================

    private fun buildOpacity(t: Int): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, 0)
        val lo = if (t == NoteView.HL) 15 else 10
        val hi = if (t == NoteView.HL) 90 else 100
        val cur = if (t == NoteView.HL) view.hlOpacity else view.penOpacity
        val lab = label("Opacity", 12f, Theme.sub(), Fonts.medium)
        val valTv = label("$cur%", 12f, Theme.text(), Fonts.medium)
        valTv.gravity = Gravity.END
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (cur - lo).coerceIn(0, hi - lo)
        val tint = ColorStateList.valueOf(Theme.accent)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = lo + p
                if (t == NoteView.HL) view.hlOpacity = v else view.penOpacity = v
                valTv.text = "$v%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        row.addView(lab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(valTv, LinearLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.WRAP_CONTENT))
        return row
    }

    private fun lineStyleRow(): View =
        iconSegment(listOf(Ic.L_SOLID, Ic.L_DASH, Ic.L_DOT), view.penStyle) { view.penStyle = it }

    private fun buildExtras(t: Int): View? {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        when (t) {
            NoteView.PEN -> {
                box.addView(lineStyleRow(), rowLp())
                box.addView(buildOpacity(t))
            }
            NoteView.RULER, NoteView.SHAPE -> box.addView(lineStyleRow(), rowLp())
            NoteView.HL -> {
                box.addView(
                    iconSegment(listOf(Ic.TIP_FLAT, Ic.TIP_ROUND), if (view.hlFlat) 0 else 1) { view.hlFlat = it == 0 },
                    rowLp()
                )
                box.addView(buildOpacity(t))
            }
            NoteView.ERASER -> {
                box.addView(chipRow(listOf("Stroke", "Pixel"), view.eraserMode) { view.eraserMode = it }, rowLp())
                box.addView(chipRow(listOf("All", "Pen", "Marker", "Tape"), view.eraseOnly) { view.eraseOnly = it }, rowLp())
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                val back = toggleChip("Auto-back", view.autoBack) { view.autoBack = it }
                val bl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                bl.rightMargin = dp(8)
                line.addView(back, bl)
                val clear = chipView("Clear page", false)
                clear.setOnClickListener {
                    tick(it)
                    confirmSheet("Clear page", "", "Clear", true) {
                        view.clearPage()
                        updateUndo()
                    }
                }
                line.addView(clear)
                box.addView(line, rowLp())
            }
            NoteView.LASSO -> {
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                line.gravity = Gravity.CENTER_VERTICAL
                line.addView(chipRow(listOf("Free", "Rect"), if (view.lassoRect) 1 else 0) { view.lassoRect = it == 1 })
                val all = chipView("All", false)
                all.setOnClickListener {
                    tick(it)
                    view.selectAll()
                }
                val al = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                al.leftMargin = dp(10)
                line.addView(all, al)
                box.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            else -> return null
        }
        return box
    }

    // ============================ review test ============================

    private fun markRange(): Pair<Int, Int> {
        val lo = Prefs.intOf(this, "mark_min", -2)
        val hi = Prefs.intOf(this, "mark_max", 4)
        return Pair(minOf(lo, 0), maxOf(hi, 0))
    }

    private fun startReviewTool() {
        val r = markRange()
        view.currentMark = Prefs.intOf(this, "mark_last", r.second).coerceIn(r.first, r.second)
        view.selectTool(NoteView.MARK)
        if (!Prefs.bool(this, "review_tip", false)) {
            Prefs.setBool(this, "review_tip", true)
            toast("Section ▸ Marks ▸ Tap")
        }
    }

    private fun toggleReview() {
        nb.review = !nb.review
        rebuildDock()
        if (nb.review) {
            startReviewTool()
        } else if (view.tool == NoteView.MARK || view.tool == NoteView.SECTION) {
            view.selectTool(NoteView.PEN)
        }
        updateScore()
        scheduleSave()
    }

    private fun rebuildDock() {
        toolBtns.clear()
        val idx = stack.indexOfChild(dock)
        stack.removeView(dock)
        dock = buildDock()
        stack.addView(dock, idx, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)))
        refreshTools()
    }

    private fun updateScore() {
        scorePill.visibility = if (nb.review) View.VISIBLE else View.GONE
        if (!nb.review) return
        val t = Review.total(nb)
        scoreTv.text = Review.fmt(t)
        scoreTv.setTextColor(if (t == 0) Theme.text() else Review.tone(t))
    }

    private fun buildMarks(): View {
        val r = markRange()
        if (view.currentMark < r.first || view.currentMark > r.second) view.currentMark = r.second
        val flow = FlowLayout(this)
        flow.hGap = dp(8)
        flow.vGap = dp(8)
        for (v in r.first..r.second) {
            val sel = v == view.currentMark
            val tone = Review.tone(v)
            val chip = label(Review.fmt(v), 15f, if (sel) Color.WHITE else tone, Fonts.bold, true)
            chip.gravity = Gravity.CENTER
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(if (sel) tone else ((tone and 0x00FFFFFF) or 0x26000000))
            chip.background = g
            chip.pressable()
            chip.setOnClickListener {
                tick(it)
                view.currentMark = v
                Prefs.setInt(this, "mark_last", v)
                refreshTools()
                refreshProps(false)
            }
            flow.addView(chip, ViewGroup.LayoutParams(dp(48), dp(48)))
        }
        val gear = IconView(this, Ic.SETTINGS, Theme.sub(), 0.5f)
        gear.isClickable = true
        gear.pressable()
        gear.setOnClickListener {
            tick(it)
            settingsSheet { refreshProps(false) }
        }
        flow.addView(gear, ViewGroup.LayoutParams(dp(48), dp(48)))
        return flow
    }

    private fun askSection(pg: Page, y: Float, existing: DividerItem?) {
        val used = HashSet<String>()
        for (p in nb.pages) for (item in p.items) {
            if (item is DividerItem && item !== existing) used.add(item.name.trim().lowercase())
        }
        val suggestions = listOf("Physics", "Chemistry", "Math")
        val start = existing?.name ?: (suggestions.firstOrNull { !used.contains(it.lowercase()) } ?: "")
        val et = EditText(this)
        et.setText(start)
        et.setSelection(et.text.length)
        et.hint = "…"
        et.setTextColor(Theme.text())
        et.setHintTextColor(Theme.sub())
        et.typeface = Fonts.medium
        et.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 17f)
        et.background = fieldBg(14f)
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        et.maxLines = 1
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        val chips = chipRow(suggestions, suggestions.indexOf(start)) { i ->
            et.setText(suggestions[i])
            et.setSelection(et.text.length)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        Sheet(this).title("Section").view(chips).view(et, lp)
            .iconBtn(Ic.CLOSE, false)
            .iconBtn(Ic.CHECK, true) { view.applySection(pg, y, existing, et.text.toString().trim()) }
            .show()
    }

    private fun countsRow(p: Int, n: Int, z: Int, sizeSp: Float): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        fun group(icon: Int, tint: Int, count: Int) {
            row.addView(IconView(this, icon, tint, 0.75f), LinearLayout.LayoutParams(dp(20), dp(20)))
            val t = label(count.toString(), sizeSp, Theme.text(), Fonts.medium)
            t.setPadding(dp(3), 0, dp(12), 0)
            row.addView(t)
        }
        group(Ic.CHECK, Review.GREEN, p)
        group(Ic.CLOSE, Review.RED, n)
        group(Ic.MINUS, Review.GRAY, z)
        return row
    }

    private fun showScore() {
        val secs = Review.sections(nb)
        val total = Review.total(nb)
        var p = 0
        var n = 0
        var z = 0
        for (s in secs) {
            p += s.pos
            n += s.neg
            z += s.zero
        }
        val sh = Sheet(this)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(IconView(this, Ic.CHART, Theme.accent, 0.7f), LinearLayout.LayoutParams(dp(44), dp(44)))
        val big = label(Review.fmt(total), 38f, if (total == 0) Theme.text() else Review.tone(total), Fonts.medium)
        big.setPadding(dp(6), 0, 0, 0)
        head.addView(big, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(countsRow(p, n, z, 17f))
        sh.view(head)
        for (s in secs) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = fieldBg(14f)
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            val dot = View(this)
            dot.background = roundBg(Review.colorFor(s.name), 5)
            row.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
            val nm = label(s.name, 15f, Theme.text(), Fonts.medium)
            nm.setPadding(dp(10), 0, dp(8), 0)
            row.addView(nm, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(countsRow(s.pos, s.neg, s.zero, 13f))
            val tv = label(Review.fmt(s.total), 17f, if (s.total == 0) Theme.text() else Review.tone(s.total), Fonts.medium)
            tv.gravity = Gravity.END
            row.addView(tv, LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.isClickable = true
            row.pressable(0.98f)
            row.setOnClickListener {
                view.goTo(s.page)
                sh.dismiss()
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            sh.view(row, lp)
        }
        sh.iconBtn(Ic.CLOSE, false).show()
    }

    // ============================ dialogs ============================

    private fun rowLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        return lp
    }

    private fun askText(existing: TextItem?, pg: Page, x: Float, y: Float, sticky: Boolean) {
        val base = existing?.fmt() ?: view.lastFmt
        var family = base.family
        var bold = base.bold
        var italic = base.italic
        var align = base.align
        var bg = base.bg
        val et = EditText(this)
        et.setText(existing?.text ?: "")
        et.setSelection(et.text.length)
        et.hint = "…"
        et.setTextColor(Theme.text())
        et.setHintTextColor(Theme.sub())
        et.background = fieldBg(14f)
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        et.typeface = Fonts.regular
        et.minLines = 3
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        val sh = Sheet(this).title(if (sticky) "Note" else "Text").view(et).keyboard()
        sh.view(chipRow(listOf("Sans", "Serif", "Mono", "Hand"), family) { family = it }, rowLp())
        val tg = LinearLayout(this)
        tg.orientation = LinearLayout.HORIZONTAL
        tg.gravity = Gravity.CENTER_VERTICAL
        val bChip = toggleChip("B", bold) { bold = it }
        bChip.typeface = Fonts.bold
        val iChip = toggleChip("I", italic) { italic = it }
        iChip.typeface = Fonts.textFace(0, false, true)
        val chipLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        chipLp.rightMargin = dp(8)
        tg.addView(bChip, chipLp)
        val chipLp2 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        chipLp2.rightMargin = dp(14)
        tg.addView(iChip, chipLp2)
        tg.addView(iconSegment(listOf(Ic.ALIGN_L, Ic.ALIGN_C, Ic.ALIGN_R), align) { align = it })
        sh.view(tg, rowLp())
        if (sticky) {
            val sw = LinearLayout(this)
            sw.orientation = LinearLayout.HORIZONTAL
            val dots = ArrayList<View>()
            fun paintDots() {
                for ((i, d) in dots.withIndex()) {
                    val g = GradientDrawable()
                    g.shape = GradientDrawable.OVAL
                    g.setColor(stickyColors[i])
                    g.setStroke(if (stickyColors[i] == bg) dp(3) else dp(1), if (stickyColors[i] == bg) Theme.accent else 0x33000000)
                    d.background = g
                }
            }
            for ((i, c) in stickyColors.withIndex()) {
                val d = View(this)
                dots.add(d)
                d.setOnClickListener {
                    bg = c
                    paintDots()
                }
                val lp = LinearLayout.LayoutParams(dp(38), dp(38))
                lp.rightMargin = dp(8)
                sw.addView(d, lp)
            }
            paintDots()
            sh.view(sw, rowLp())
        }
        if (existing != null) sh.iconBtn(Ic.TRASH, false, true, true) { view.applyText(existing, pg, x, y, sticky, "", base) }
        sh.iconBtn(Ic.CLOSE, false).iconBtn(Ic.CHECK, true) {
            view.applyText(existing, pg, x, y, sticky, et.text.toString().trim(), TextFmt(family, bold, italic, align, bg))
        }.show()
        et.requestFocus()
    }

    private fun stepper(name: String, init: Int, onChange: (Int) -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        row.addView(label(name, 16f, Theme.text(), Fonts.medium), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        var v = init
        val value = label(v.toString(), 18f, Theme.text(), Fonts.medium)
        value.gravity = Gravity.CENTER
        fun sbtn(sym: String, d: Int): TextView {
            val b = label(sym, 22f, Theme.text(), Fonts.medium)
            b.gravity = Gravity.CENTER
            b.background = fieldBg(14f)
            b.pressable()
            b.setOnClickListener {
                v = (v + d).coerceIn(1, 20)
                value.text = v.toString()
                onChange(v)
            }
            return b
        }
        row.addView(sbtn("–", -1), LinearLayout.LayoutParams(dp(48), dp(48)))
        row.addView(value, LinearLayout.LayoutParams(dp(52), dp(48)))
        row.addView(sbtn("+", 1), LinearLayout.LayoutParams(dp(48), dp(48)))
        return row
    }

    private fun askTable(pg: Page, r: RectF) {
        var rows = 3
        var cols = 3
        var header = false
        val sh = Sheet(this).title("Table")
        sh.view(stepper("Rows", rows) { rows = it })
        sh.view(stepper("Columns", cols) { cols = it })
        sh.view(toggleChip("Header row", false) { header = it }, rowLp())
        sh.iconBtn(Ic.CLOSE, false).iconBtn(Ic.CHECK, true) { view.addTable(pg, r, rows, cols, header) }.show()
    }

    private fun askGoTo() {
        inputSheet("Go to page", "", "1 – ${nb.pages.size}", numeric = true, ok = "Go") { s ->
            val n = s.toIntOrNull()
            if (n != null) view.goTo((n - 1).coerceIn(0, nb.pages.size - 1))
        }
    }

    private fun askRename() {
        inputSheet("Rename notebook", nb.title, "Title") { s ->
            if (s.isNotEmpty()) {
                nb.title = s
                titleTv.text = s
                scheduleSave()
            }
        }
    }

    private fun pickTemplate() {
        val sh = Sheet(this).title("Page template")
        for ((i, n) in TEMPLATE_NAMES.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(8), dp(6), dp(8), dp(6))
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
            val tmp = Notebook("tmp", "")
            tmp.pageColor = nb.pageColor
            val pg = Page(595f, 842f)
            pg.template = TEMPLATE_IDS[i]
            tmp.pages.add(pg)
            try {
                iv.setImageBitmap(Exporter.renderPage(tmp, 0, dp(48), null, env))
            } catch (t: Throwable) {
            }
            row.addView(iv, LinearLayout.LayoutParams(dp(48), dp(64)))
            val tv = label(n, 16f, Theme.text(), Fonts.medium)
            tv.setPadding(dp(14), 0, 0, 0)
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.isClickable = true
            row.pressable(0.97f)
            row.setOnClickListener {
                sh.dismiss()
                view.setTemplate(view.currentPage(), TEMPLATE_IDS[i])
            }
            sh.view(row)
        }
        sh.iconBtn(Ic.CLOSE, false).show()
    }

    private fun pickPageColor() {
        chooseSheet("Paper color", PAGE_COLOR_NAMES.toList(), null, nb.pageColor) { which ->
            nb.pageColor = which
            view.refreshAll()
            scheduleSave()
        }
    }

    private fun showMore() {
        val tiles = ArrayList<Tile>()
        tiles.add(Tile(Ic.REVIEW, "Review", nb.review) { toggleReview() })
        tiles.add(Tile(Ic.EDIT, "Rename") { askRename() })
        tiles.add(Tile(Ic.PAGES, "Pages") { showPages() })
        tiles.add(Tile(Ic.SEARCH, "Go to") { askGoTo() })
        tiles.add(Tile(Ic.PLUS, "Add page") { addPageSheet() })
        tiles.add(Tile(Ic.NOTE, "Template") { pickTemplate() })
        tiles.add(Tile(Ic.DROP, "Paper") { pickPageColor() })
        if (nb.hasPdf) {
            tiles.add(Tile(if (nb.invertPdf) Ic.SUN else Ic.MOON, if (nb.invertPdf) "Normal PDF" else "Night PDF") {
                nb.invertPdf = !nb.invertPdf
                view.refreshAll()
                scheduleSave()
            })
        }
        if (view.hasClip()) tiles.add(Tile(Ic.CLIPBOARD, "Paste") { view.paste() })
        tiles.add(Tile(Ic.LASSO, "Select all") { view.selectAll() })
        tiles.add(Tile(Ic.TRASH, "Clear page") {
            confirmSheet("Clear page", "", "Clear", true) {
                view.clearPage()
                updateUndo()
            }
        })
        tiles.add(Tile(Ic.FOCUS, "Focus") { setFocus(true) })
        tiles.add(Tile(Ic.ZOOM, "View") { viewSheet() })
        tiles.add(Tile(Ic.MIC, if (recorder == null) "Record" else "Stop") { toggleRecord() })
        tiles.add(Tile(Ic.PLAY, "Recordings") { showRecordings() })
        tiles.add(Tile(Ic.DOWNLOAD, "Export") { exportSheet() })
        tiles.add(Tile(Ic.SETTINGS, "Settings") { settingsSheet { applyPrefs() } })
        tileSheet("Notebook", tiles)
    }

    private fun exportSheet() {
        chooseSheet(
            "Export",
            listOf("PDF · all pages", "PDF · this page", "Share PDF", "Image · this page", "Image · HD"),
            listOf(Ic.DOWNLOAD, Ic.DOWNLOAD, Ic.SHARE, Ic.IMAGE, Ic.IMAGE)
        ) { i ->
            when (i) {
                0 -> exportPdfSave(false)
                1 -> exportPdfSave(true)
                2 -> sharePdf()
                3 -> exportPngSave(1600)
                4 -> exportPngSave(2800)
            }
        }
    }

    private fun addPageSheet() {
        val cur = view.currentPage()
        val tpl = if (nb.pages[cur].pdfIndex < 0) nb.pages[cur].template else "blank"
        chooseSheet("Add page", listOf("After", "Before", "End"), listOf(Ic.CHEV_DOWN, Ic.CHEV_UP, Ic.PLUS)) { i ->
            when (i) {
                0 -> view.addPage(cur, tpl)
                1 -> view.addPage(cur - 1, tpl)
                else -> view.addPage(nb.pages.size - 1, tpl)
            }
            updateUndo()
        }
    }

    private fun viewSheet() {
        val sel = if (view.viewMode == 1) 1 else 0
        chooseSheet(
            "View", listOf("Continuous", "Page by page", "Fit width", "Fit page"),
            listOf(Ic.LIST, Ic.FILE, Ic.ZOOM, Ic.FOCUS), sel
        ) { i ->
            when (i) {
                0 -> {
                    view.viewMode = 0
                    Prefs.setInt(this, "view_layout", 0)
                }
                1 -> {
                    view.viewMode = 1
                    Prefs.setInt(this, "view_layout", 1)
                    view.fitWidth()
                }
                2 -> view.fitWidth()
                3 -> view.fitPage()
            }
        }
    }

    private fun showPages() {
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sh = Sheet(this).title("Pages").view(list)

        fun fill() {
            list.removeAllViews()
            val curPage = view.currentPage()
            for (i in nb.pages.indices) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(6), dp(4), dp(6), dp(4))
                if (i == curPage) row.background = fieldBg(14f)
                val iv = ImageView(this)
                iv.setBackgroundColor(0xFFE6E8EF.toInt())
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                row.addView(iv, LinearLayout.LayoutParams(dp(56), dp(76)))
                worker.execute {
                    try {
                        val bmp = Exporter.renderPage(nb, i, 160, pdf, env)
                        runOnUiThread { iv.setImageBitmap(bmp) }
                    } catch (t: Throwable) {
                    }
                }
                val name = label("Page ${i + 1}", 15f, Theme.text(), Fonts.medium)
                name.setPadding(dp(12), 0, dp(6), 0)
                name.setOnClickListener {
                    view.goTo(i)
                    sh.dismiss()
                }
                row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                fun act(icon: Int, tint: Int, a: () -> Unit) {
                    val b = IconView(this, icon, tint, 0.6f)
                    b.isClickable = true
                    b.pressable()
                    b.setOnClickListener {
                        a()
                        updateUndo()
                        fill()
                    }
                    row.addView(b, LinearLayout.LayoutParams(dp(38), dp(44)))
                }
                act(Ic.CHEV_UP, Theme.sub()) { view.movePage(i, -1) }
                act(Ic.CHEV_DOWN, Theme.sub()) { view.movePage(i, 1) }
                act(Ic.COPY, Theme.sub()) { view.duplicatePage(i) }
                act(Ic.TRASH, Theme.danger) { view.deletePage(i) }
                list.addView(row)
            }
        }
        fill()
        sh.iconBtn(Ic.CLOSE, false).iconBtn(Ic.PLUS, true, false) {
            view.addPage(view.currentPage(), "blank")
            updateUndo()
            fill()
        }.show()
    }

    private fun setFocus(on: Boolean) {
        focus = on
        val d = dp(40).toFloat()
        if (on) {
            topBar.animate().alpha(0f).translationY(-d).setDuration(180).withEndAction {
                if (focus) topBar.visibility = View.GONE
            }.start()
            stack.animate().alpha(0f).translationY(d).setDuration(180).withEndAction {
                if (focus) stack.visibility = View.GONE
            }.start()
            exitFocus.alpha = 0f
            exitFocus.visibility = View.VISIBLE
            exitFocus.animate().alpha(0.85f).setDuration(200).start()
        } else {
            topBar.visibility = View.VISIBLE
            stack.visibility = View.VISIBLE
            topBar.animate().alpha(1f).translationY(0f).setDuration(200).start()
            stack.animate().alpha(1f).translationY(0f).setDuration(200).start()
            exitFocus.visibility = View.GONE
        }
    }

    // ============================ images ============================

    private fun openImagePicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        startActivityForResult(i, REQ_IMG)
    }

    private fun importImage(uri: Uri) {
        worker.execute {
            try {
                val o1 = BitmapFactory.Options()
                o1.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o1) }
                var sample = 1
                while (max(o1.outWidth, o1.outHeight) / sample > 1600) sample *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = sample
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                    ?: throw RuntimeException("decode failed")
                val name = "img_${System.currentTimeMillis()}.png"
                File(Store.dir(this, nb.id), name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val aspect = bmp.width.toFloat() / max(1, bmp.height)
                runOnUiThread { view.addImage(name, aspect) }
            } catch (t: Throwable) {
                runOnUiThread { toast("Could not load that image") }
            }
        }
    }

    // ============================ export ============================

    private fun safeName(): String = nb.title.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifBlank { "note" }

    private fun exportPdfSave(pageOnly: Boolean) {
        exportOnly = if (pageOnly) view.currentPage() else -1
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/pdf"
        i.putExtra(Intent.EXTRA_TITLE, safeName() + ".pdf")
        startActivityForResult(i, REQ_PDF)
    }

    private fun exportPngSave(width: Int) {
        pngWidth = width
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, safeName() + "_page${view.currentPage() + 1}.png")
        startActivityForResult(i, REQ_PNG)
    }

    private fun sharePdf() {
        toast("Preparing PDF…")
        worker.execute {
            try {
                val f = File(cacheDir, "exports/" + safeName() + ".pdf")
                f.parentFile?.mkdirs()
                f.outputStream().use { Exporter.exportPdf(nb, pdf, env, it) }
                runOnUiThread {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                    val s = Intent(Intent.ACTION_SEND)
                    s.type = "application/pdf"
                    s.putExtra(Intent.EXTRA_STREAM, uri)
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(s, "Share PDF"))
                }
            } catch (t: Throwable) {
                runOnUiThread { toast("Export failed") }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_IMG -> importImage(uri)
            REQ_PDF -> {
                toast("Exporting…")
                worker.execute {
                    try {
                        contentResolver.openOutputStream(uri)?.use { Exporter.exportPdf(nb, pdf, env, it, exportOnly) }
                        runOnUiThread { toast("PDF saved") }
                    } catch (t: Throwable) {
                        runOnUiThread { toast("Export failed") }
                    }
                }
            }
            REQ_PNG -> {
                val page = view.currentPage()
                worker.execute {
                    try {
                        val bmp = Exporter.renderPage(nb, page, pngWidth, pdf, env)
                        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        runOnUiThread { toast("Image saved") }
                    } catch (t: Throwable) {
                        runOnUiThread { toast("Export failed") }
                    }
                }
            }
        }
    }

    // ============================ audio ============================

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun toggleRecord() {
        if (recorder != null) {
            stopRecord()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5)
            return
        }
        startRecord()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 5 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startRecord()
    }

    private fun startRecord() {
        try {
            val name = "rec_${System.currentTimeMillis()}.m4a"
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(File(Store.dir(this, nb.id), name).path)
            r.prepare()
            r.start()
            recorder = r
            recName = name
            updateSub()
            toast("Recording… open ⋮ › Stop recording")
        } catch (t: Throwable) {
            recorder = null
            toast("Could not start recording")
        }
    }

    private fun stopRecord() {
        val r = recorder ?: return
        try {
            r.stop()
        } catch (t: RuntimeException) {
        }
        r.release()
        recorder = null
        val n = recName
        if (n != null) {
            nb.recordings.add(n)
            scheduleSave()
            toast("Recording saved")
        }
        recName = null
        updateSub()
    }

    private fun showRecordings() {
        if (nb.recordings.isEmpty()) {
            toast("No recordings yet")
            return
        }
        val fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        val names = nb.recordings.mapIndexed { i, f ->
            val ts = f.removePrefix("rec_").removeSuffix(".m4a").toLongOrNull() ?: 0L
            "Recording ${i + 1} — ${fmt.format(Date(ts))}"
        }
        chooseSheet("Recordings", names, names.map { Ic.MIC }) { which ->
            chooseSheet(names[which], listOf("Play", "Delete"), listOf(Ic.PLAY, Ic.TRASH)) { a ->
                val f = nb.recordings[which]
                if (a == 0) {
                    try {
                        player?.release()
                        val p = MediaPlayer()
                        p.setDataSource(File(Store.dir(this, nb.id), f).path)
                        p.prepare()
                        p.start()
                        p.setOnCompletionListener { it.release() }
                        player = p
                    } catch (t: Throwable) {
                        toast("Could not play recording")
                    }
                } else {
                    player?.release()
                    player = null
                    File(Store.dir(this, nb.id), f).delete()
                    nb.recordings.remove(f)
                    scheduleSave()
                }
            }
        }
    }

    // ============================ lifecycle ============================

    private fun scheduleSave() {
        handler.removeCallbacks(saveRun)
        handler.postDelayed(saveRun, 1500)
    }

    private fun saveNow(thumb: Boolean) {
        if (!ready) return
        handler.removeCallbacks(saveRun)
        try {
            Store.save(this, nb)
            saveState = "Saved"
            updateSub()
        } catch (t: Throwable) {
        }
        if (thumb) worker.execute { Exporter.writeThumb(this, nb, pdf, env) }
    }

    override fun onResume() {
        super.onResume()
        if (!ready) return
        val d = Theme.dark
        Theme.apply(this)
        if (d != Theme.dark) {
            recreate()
            return
        }
        applyPrefs()
        refreshProps(false)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (ready) applyInsets()
    }

    override fun onPause() {
        super.onPause()
        saveNow(true)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!ready) return
        handler.removeCallbacks(saveRun)
        handler.removeCallbacks(hidePanelRun)
        try {
            recorder?.stop()
        } catch (t: Throwable) {
        }
        recorder?.release()
        recorder = null
        player?.release()
        player = null
        view.release()
        worker.execute { pdf?.close() }
        worker.shutdown()
    }
}
