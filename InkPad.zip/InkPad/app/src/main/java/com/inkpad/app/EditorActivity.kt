package com.inkpad.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.RectF
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors
import kotlin.math.max

class EditorActivity : Activity() {

    private val REQ_IMG = 11
    private val REQ_PDF = 12
    private val REQ_PNG = 13

    private lateinit var nb: Notebook
    private var pdf: PdfSource? = null
    private lateinit var env: ImgEnv
    private lateinit var view: NoteView
    private lateinit var titleTv: TextView
    private lateinit var pageTv: TextView
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var selBar: LinearLayout
    private lateinit var propBar: LinearLayout
    private lateinit var colorRow: LinearLayout
    private lateinit var seek: SeekBar
    private val toolButtons = HashMap<Int, TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val saveRun = Runnable { saveNow(false) }
    private var ready = false

    private var recorder: MediaRecorder? = null
    private var recName: String? = null
    private var player: MediaPlayer? = null

    private val penColors = intArrayOf(
        0xFF000000.toInt(), 0xFF5F6368.toInt(), 0xFFE53935.toInt(), 0xFFFB8C00.toInt(),
        0xFF43A047.toInt(), 0xFF1E88E5.toInt(), 0xFF8E24AA.toInt(), 0xFFFFFFFF.toInt()
    )
    private val hlColors = intArrayOf(
        0xFFFFEB3B.toInt(), 0xFF76FF03.toInt(), 0xFFFF4081.toInt(),
        0xFF18FFFF.toInt(), 0xFFFF9100.toInt(), 0xFFB388FF.toInt()
    )

    private val toolDefs = listOf(
        Triple(NoteView.HAND, "✋", "Hand"),
        Triple(NoteView.PEN, "✏️", "Pen"),
        Triple(NoteView.HL, "🖍️", "Marker"),
        Triple(NoteView.ERASER, "⌫", "Eraser"),
        Triple(NoteView.LASSO, "◌", "Lasso"),
        Triple(NoteView.SHAPE, "△", "Shape"),
        Triple(NoteView.TEXT, "T", "Text"),
        Triple(NoteView.STICKY, "🗒️", "Sticky"),
        Triple(-1, "🖼️", "Image"),
        Triple(NoteView.TABLE, "▦", "Table"),
        Triple(NoteView.TAPE, "▬", "Tape"),
        Triple(NoteView.RULER, "📏", "Ruler"),
        Triple(NoteView.LASER, "🔴", "Laser")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val loaded = if (id != null) Store.load(this, id) else null
        if (loaded == null) {
            toast("Could not open notebook")
            finish()
            return
        }
        nb = loaded
        env = ImgEnv(Store.dir(this, nb.id))
        if (nb.hasPdf) {
            try {
                pdf = PdfSource(File(Store.dir(this, nb.id), "doc.pdf"))
            } catch (t: Throwable) {
                toast("The PDF could not be opened")
                finish()
                return
            }
        }
        window.statusBarColor = 0xFF1F2023.toInt()
        buildUi()
        ready = true
    }

    // ============================ UI ============================

    private fun iconBtn(text: String, onClick: (View) -> Unit): TextView {
        val t = label(text, 22f)
        t.gravity = Gravity.CENTER
        t.isClickable = true
        t.setOnClickListener { onClick(it) }
        return t
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF2B2D31.toInt())

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setBackgroundColor(0xFF1F2023.toInt())
        top.setPadding(dp(4), 0, dp(4), 0)

        val back = iconBtn("←") { finish() }
        titleTv = label(nb.title, 16f)
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        titleTv.setPadding(dp(6), 0, dp(6), 0)
        pageTv = label("1/${nb.pages.size}", 13f, 0xFFB0B3B8.toInt())
        pageTv.setPadding(dp(6), 0, dp(6), 0)
        pageTv.setOnClickListener { askGoTo() }
        undoBtn = iconBtn("↶") { view.undo(); updateUndo() }
        redoBtn = iconBtn("↷") { view.redo(); updateUndo() }
        val pagesBtn = iconBtn("▤") { showPages() }
        val menuBtn = iconBtn("⋮") { showMenu(it) }

        top.addView(back, LinearLayout.LayoutParams(dp(44), dp(48)))
        top.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(pageTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)))
        top.addView(undoBtn, LinearLayout.LayoutParams(dp(42), dp(48)))
        top.addView(redoBtn, LinearLayout.LayoutParams(dp(42), dp(48)))
        top.addView(pagesBtn, LinearLayout.LayoutParams(dp(42), dp(48)))
        top.addView(menuBtn, LinearLayout.LayoutParams(dp(36), dp(48)))
        pageTv.gravity = Gravity.CENTER

        view = NoteView(this, nb, pdf, env)
        view.onChanged = {
            updateUndo()
            scheduleSave()
        }
        view.onSelection = { has -> selBar.visibility = if (has) View.VISIBLE else View.GONE }
        view.onPage = { i -> pageTv.text = "${i + 1}/${nb.pages.size}" }
        view.onToolChanged = {
            refreshTools()
            refreshProps()
        }
        view.onText = { existing, pg, x, y, sticky -> askText(existing, pg, x, y, sticky) }
        view.onTable = { pg, r -> askTable(pg, r) }

        selBar = LinearLayout(this)
        selBar.orientation = LinearLayout.HORIZONTAL
        selBar.setBackgroundColor(0xFF3F51B5.toInt())
        selBar.gravity = Gravity.CENTER
        selBar.visibility = View.GONE
        fun selBtn(text: String, action: () -> Unit) {
            val t = label(text, 14f)
            t.setPadding(dp(14), dp(10), dp(14), dp(10))
            t.setOnClickListener { action() }
            selBar.addView(t)
        }
        selBtn("🗑 Delete") { view.deleteSelection() }
        selBtn("⧉ Duplicate") { view.duplicateSelection() }
        selBtn("🎨 Apply color") { view.recolorSelection(view.penColor) }
        selBtn("✕ Done") { view.clearSelection() }

        propBar = LinearLayout(this)
        propBar.orientation = LinearLayout.HORIZONTAL
        propBar.gravity = Gravity.CENTER_VERTICAL
        propBar.setBackgroundColor(0xFF26282C.toInt())
        propBar.setPadding(dp(6), dp(2), dp(6), dp(2))
        colorRow = LinearLayout(this)
        colorRow.orientation = LinearLayout.HORIZONTAL
        colorRow.gravity = Gravity.CENTER_VERTICAL
        val colorScroll = HorizontalScrollView(this)
        colorScroll.isHorizontalScrollBarEnabled = false
        colorScroll.addView(colorRow)
        seek = SeekBar(this)
        seek.max = 100
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val r = range(view.tool)
                setW(view.tool, r.first + (r.second - r.first) * p / 100f)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        propBar.addView(colorScroll, LinearLayout.LayoutParams(0, dp(44), 1f))
        propBar.addView(seek, LinearLayout.LayoutParams(dp(130), ViewGroup.LayoutParams.WRAP_CONTENT))

        val toolScroll = HorizontalScrollView(this)
        toolScroll.setBackgroundColor(0xFF1F2023.toInt())
        toolScroll.isHorizontalScrollBarEnabled = false
        val toolRow = LinearLayout(this)
        toolRow.orientation = LinearLayout.HORIZONTAL
        for ((id, icon, name) in toolDefs) {
            val t = label("$icon\n$name", 11f)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(10), dp(4), dp(10), dp(4))
            t.setOnClickListener {
                if (id == -1) {
                    openImagePicker()
                } else {
                    view.selectTool(id)
                    if (id == NoteView.SHAPE) showShapeMenu(it)
                }
            }
            if (id >= 0) toolButtons[id] = t
            toolRow.addView(t, LinearLayout.LayoutParams(dp(62), dp(54)))
        }
        toolScroll.addView(toolRow)

        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(selBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(propBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(toolScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)))
        setContentView(root)

        refreshTools()
        refreshProps()
        updateUndo()
    }

    private fun updateUndo() {
        undoBtn.alpha = if (view.canUndo()) 1f else 0.35f
        redoBtn.alpha = if (view.canRedo()) 1f else 0.35f
        pageTv.text = "${view.currentPage() + 1}/${nb.pages.size}"
    }

    private fun refreshTools() {
        for ((id, tv) in toolButtons) {
            tv.background = if (id == view.tool) roundBg(0xFF3F51B5.toInt(), 8) else null
        }
    }

    private fun range(t: Int): Pair<Float, Float> = when (t) {
        NoteView.HL -> Pair(6f, 40f)
        NoteView.ERASER -> Pair(4f, 40f)
        NoteView.TEXT, NoteView.STICKY -> Pair(10f, 60f)
        else -> Pair(1f, 20f)
    }

    private fun getW(t: Int): Float = when (t) {
        NoteView.HL -> view.hlW
        NoteView.ERASER -> view.eraserW
        NoteView.TEXT, NoteView.STICKY -> view.textSize
        else -> view.penW
    }

    private fun setW(t: Int, v: Float) {
        when (t) {
            NoteView.HL -> view.hlW = v
            NoteView.ERASER -> view.eraserW = v
            NoteView.TEXT, NoteView.STICKY -> view.textSize = v
            else -> view.penW = v
        }
    }

    private fun refreshProps() {
        val t = view.tool
        val colorTools = intArrayOf(
            NoteView.PEN, NoteView.HL, NoteView.SHAPE, NoteView.TEXT, NoteView.STICKY,
            NoteView.TABLE, NoteView.TAPE, NoteView.RULER
        )
        val seekTools = intArrayOf(
            NoteView.PEN, NoteView.HL, NoteView.ERASER, NoteView.TEXT, NoteView.STICKY,
            NoteView.SHAPE, NoteView.RULER, NoteView.TABLE
        )
        val showColors = colorTools.contains(t)
        val showSeek = seekTools.contains(t)
        propBar.visibility = if (showColors || showSeek) View.VISIBLE else View.GONE
        colorRow.removeAllViews()
        if (showColors) {
            val pal = if (t == NoteView.HL) hlColors else penColors
            val cur = view.toolColor()
            for (c in pal) {
                val sw = View(this)
                val sel = c == cur
                sw.background = roundBg(c, 15, if (sel) 0xFF82B1FF.toInt() else 0xFF666666.toInt(), if (sel) 3 else 1)
                sw.setOnClickListener {
                    if (view.tool == NoteView.HL) view.hlColor = c else view.penColor = c
                    refreshProps()
                }
                val lp = LinearLayout.LayoutParams(dp(30), dp(30))
                lp.setMargins(dp(5), 0, dp(5), 0)
                colorRow.addView(sw, lp)
            }
        }
        seek.visibility = if (showSeek) View.VISIBLE else View.GONE
        if (showSeek) {
            val r = range(t)
            seek.progress = ((getW(t) - r.first) / (r.second - r.first) * 100f).toInt().coerceIn(0, 100)
        }
    }

    private fun showShapeMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        for ((i, n) in SHAPE_NAMES.withIndex()) pm.menu.add(0, i, i, n)
        pm.setOnMenuItemClickListener { item ->
            view.shapeKind = item.itemId
            true
        }
        pm.show()
    }

    // ============================ dialogs ============================

    private fun askText(existing: TextItem?, pg: Page, x: Float, y: Float, sticky: Boolean) {
        val et = EditText(this)
        et.setText(existing?.text ?: "")
        et.setSelection(et.text.length)
        et.minLines = 3
        et.gravity = Gravity.TOP
        val b = AlertDialog.Builder(this)
            .setTitle(if (sticky) "Sticky note" else "Text")
            .setView(et)
            .setPositiveButton("OK") { _, _ -> view.applyText(existing, pg, x, y, sticky, et.text.toString().trim()) }
            .setNegativeButton("Cancel", null)
        if (existing != null) b.setNeutralButton("Delete") { _, _ -> view.applyText(existing, pg, x, y, sticky, "") }
        val d = b.create()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
    }

    private fun askTable(pg: Page, r: RectF) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val rows = EditText(this)
        rows.inputType = InputType.TYPE_CLASS_NUMBER
        rows.hint = "Rows"
        rows.setText("3")
        val cols = EditText(this)
        cols.inputType = InputType.TYPE_CLASS_NUMBER
        cols.hint = "Columns"
        cols.setText("3")
        box.addView(rows)
        box.addView(cols)
        AlertDialog.Builder(this)
            .setTitle("Insert table")
            .setView(box)
            .setPositiveButton("Insert") { _, _ ->
                view.addTable(pg, r, rows.text.toString().toIntOrNull() ?: 3, cols.text.toString().toIntOrNull() ?: 3)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askGoTo() {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.hint = "Page 1 – ${nb.pages.size}"
        AlertDialog.Builder(this)
            .setTitle("Go to page")
            .setView(et)
            .setPositiveButton("Go") { _, _ ->
                val n = et.text.toString().toIntOrNull()
                if (n != null) view.goTo((n - 1).coerceIn(0, nb.pages.size - 1))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askRename() {
        val et = EditText(this)
        et.setText(nb.title)
        et.setSelection(et.text.length)
        AlertDialog.Builder(this)
            .setTitle("Rename")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) {
                    nb.title = s
                    titleTv.text = s
                    scheduleSave()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        m.add(0, 1, 0, "Rename")
        m.add(0, 2, 0, "Pages overview")
        m.add(0, 3, 0, "Go to page…")
        m.add(0, 4, 0, "Add blank page")
        m.add(0, 5, 0, "Template: this page…")
        m.add(0, 15, 0, "Template: all blank pages…")
        m.add(0, 6, 0, "Page color…")
        if (nb.hasPdf) m.add(0, 7, 0, if (nb.invertPdf) "PDF colors: normal" else "PDF colors: invert (night)")
        m.add(0, 8, 0, if (view.fingerDraw) "Finger drawing: ON" else "Finger drawing: OFF (stylus only)")
        m.add(0, 10, 0, if (recorder == null) "Record audio" else "Stop recording")
        m.add(0, 11, 0, "Recordings…")
        m.add(0, 12, 0, "Export PDF…")
        m.add(0, 13, 0, "Share PDF")
        m.add(0, 14, 0, "Save this page as PNG…")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> askRename()
                2 -> showPages()
                3 -> askGoTo()
                4 -> view.addPage(view.currentPage(), "blank")
                5 -> pickTemplate(false)
                15 -> pickTemplate(true)
                6 -> pickPageColor()
                7 -> {
                    nb.invertPdf = !nb.invertPdf
                    view.refreshAll()
                    scheduleSave()
                }
                8 -> {
                    view.fingerDraw = !view.fingerDraw
                    toast(if (view.fingerDraw) "Finger draws; use two fingers to pan and zoom" else "Stylus only; finger pans and zooms")
                }
                10 -> toggleRecord()
                11 -> showRecordings()
                12 -> exportPdfSave()
                13 -> sharePdf()
                14 -> exportPngSave()
            }
            true
        }
        pm.show()
    }

    private fun pickTemplate(all: Boolean) {
        AlertDialog.Builder(this)
            .setTitle("Page template")
            .setItems(TEMPLATE_NAMES) { _, which ->
                val id = TEMPLATE_IDS[which]
                if (all) {
                    for (i in nb.pages.indices) view.setTemplate(i, id)
                } else {
                    view.setTemplate(view.currentPage(), id)
                }
            }
            .show()
    }

    private fun pickPageColor() {
        AlertDialog.Builder(this)
            .setTitle("Page color")
            .setItems(PAGE_COLOR_NAMES) { _, which ->
                nb.pageColor = which
                view.refreshAll()
                scheduleSave()
            }
            .show()
    }

    private fun showPages() {
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(8), dp(8), dp(8), dp(8))
        val sv = ScrollView(this)
        sv.addView(list)
        val holder = arrayOfNulls<AlertDialog>(1)

        fun fill() {
            list.removeAllViews()
            for (i in nb.pages.indices) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(4), 0, dp(4))
                val iv = ImageView(this)
                iv.setBackgroundColor(0xFFDDDDDD.toInt())
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                row.addView(iv, LinearLayout.LayoutParams(dp(64), dp(88)))
                worker.execute {
                    try {
                        val bmp = Exporter.renderPage(nb, i, 160, pdf, env)
                        runOnUiThread { iv.setImageBitmap(bmp) }
                    } catch (t: Throwable) {
                    }
                }
                val name = label("Page ${i + 1}", 15f, 0xFF222222.toInt())
                name.setPadding(dp(10), 0, dp(6), 0)
                name.setOnClickListener {
                    view.goTo(i)
                    holder[0]?.dismiss()
                }
                row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                fun act(sym: String, a: () -> Unit) {
                    val b = label(sym, 20f, 0xFF3F51B5.toInt())
                    b.gravity = Gravity.CENTER
                    b.setOnClickListener {
                        a()
                        updateUndo()
                        fill()
                    }
                    row.addView(b, LinearLayout.LayoutParams(dp(38), dp(44)))
                }
                act("↑") { view.movePage(i, -1) }
                act("↓") { view.movePage(i, 1) }
                act("⧉") { view.duplicatePage(i) }
                act("🗑") { view.deletePage(i) }
                list.addView(row)
            }
        }
        fill()
        val d = AlertDialog.Builder(this)
            .setTitle("Pages")
            .setView(sv)
            .setPositiveButton("Close", null)
            .setNeutralButton("+ Page", null)
            .create()
        holder[0] = d
        d.show()
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            view.addPage(view.currentPage(), "blank")
            updateUndo()
            fill()
        }
    }

    // ============================ images ============================

    private fun openImagePicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        startActivityForResult(i, REQ_IMG)
    }

    private fun importImage(uri: Uri) {
        worker.execute {
            try {
                val o1 = BitmapFactory.Options()
                o1.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o1) }
                var sample = 1
                while (max(o1.outWidth, o1.outHeight) / sample > 1600) sample *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = sample
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                    ?: throw RuntimeException("decode failed")
                val name = "img_${System.currentTimeMillis()}.png"
                File(Store.dir(this, nb.id), name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val aspect = bmp.width.toFloat() / max(1, bmp.height)
                runOnUiThread { view.addImage(name, aspect) }
            } catch (t: Throwable) {
                runOnUiThread { toast("Could not load that image") }
            }
        }
    }

    // ============================ export ============================

    private fun safeName(): String = nb.title.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifBlank { "note" }

    private fun exportPdfSave() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/pdf"
        i.putExtra(Intent.EXTRA_TITLE, safeName() + ".pdf")
        startActivityForResult(i, REQ_PDF)
    }

    private fun exportPngSave() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_TITLE, safeName() + "_page${view.currentPage() + 1}.png")
        startActivityForResult(i, REQ_PNG)
    }

    private fun sharePdf() {
        toast("Preparing PDF…")
        worker.execute {
            try {
                val f = File(cacheDir, "exports/" + safeName() + ".pdf")
                f.parentFile?.mkdirs()
                f.outputStream().use { Exporter.exportPdf(nb, pdf, env, it) }
                runOnUiThread {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                    val s = Intent(Intent.ACTION_SEND)
                    s.type = "application/pdf"
                    s.putExtra(Intent.EXTRA_STREAM, uri)
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(s, "Share PDF"))
                }
            } catch (t: Throwable) {
                runOnUiThread { toast("Export failed") }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_IMG -> importImage(uri)
            REQ_PDF -> {
                toast("Exporting…")
                worker.execute {
                    try {
                        contentResolver.openOutputStream(uri)?.use { Exporter.exportPdf(nb, pdf, env, it) }
                        runOnUiThread { toast("PDF saved") }
                    } catch (t: Throwable) {
                        runOnUiThread { toast("Export failed") }
                    }
                }
            }
            REQ_PNG -> {
                val page = view.currentPage()
                worker.execute {
                    try {
                        val bmp = Exporter.renderPage(nb, page, 1600, pdf, env)
                        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        runOnUiThread { toast("Image saved") }
                    } catch (t: Throwable) {
                        runOnUiThread { toast("Export failed") }
                    }
                }
            }
        }
    }

    // ============================ audio ============================

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun toggleRecord() {
        if (recorder != null) {
            stopRecord()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5)
            return
        }
        startRecord()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 5 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startRecord()
    }

    private fun startRecord() {
        try {
            val name = "rec_${System.currentTimeMillis()}.m4a"
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(File(Store.dir(this, nb.id), name).path)
            r.prepare()
            r.start()
            recorder = r
            recName = name
            toast("Recording… (⋮ → Stop recording)")
        } catch (t: Throwable) {
            recorder = null
            toast("Could not start recording")
        }
    }

    private fun stopRecord() {
        val r = recorder ?: return
        try {
            r.stop()
        } catch (t: RuntimeException) {
        }
        r.release()
        recorder = null
        val n = recName
        if (n != null) {
            nb.recordings.add(n)
            scheduleSave()
            toast("Recording saved")
        }
        recName = null
    }

    private fun showRecordings() {
        if (nb.recordings.isEmpty()) {
            toast("No recordings yet")
            return
        }
        val fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        val names = nb.recordings.mapIndexed { i, f ->
            val ts = f.removePrefix("rec_").removeSuffix(".m4a").toLongOrNull() ?: 0L
            "Recording ${i + 1} — ${fmt.format(Date(ts))}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Recordings")
            .setItems(names) { _, which ->
                AlertDialog.Builder(this)
                    .setTitle(names[which])
                    .setItems(arrayOf("Play", "Delete")) { _, a ->
                        val f = nb.recordings[which]
                        if (a == 0) {
                            try {
                                player?.release()
                                val p = MediaPlayer()
                                p.setDataSource(File(Store.dir(this, nb.id), f).path)
                                p.prepare()
                                p.start()
                                p.setOnCompletionListener { it.release() }
                                player = p
                            } catch (t: Throwable) {
                                toast("Could not play recording")
                            }
                        } else {
                            player?.release()
                            player = null
                            File(Store.dir(this, nb.id), f).delete()
                            nb.recordings.remove(f)
                            scheduleSave()
                        }
                    }
                    .show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ============================ lifecycle ============================

    private fun scheduleSave() {
        handler.removeCallbacks(saveRun)
        handler.postDelayed(saveRun, 2000)
    }

    private fun saveNow(thumb: Boolean) {
        if (!ready) return
        handler.removeCallbacks(saveRun)
        try {
            Store.save(this, nb)
        } catch (t: Throwable) {
        }
        if (thumb) worker.execute { Exporter.writeThumb(this, nb, pdf, env) }
    }

    override fun onPause() {
        super.onPause()
        saveNow(true)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!ready) return
        handler.removeCallbacks(saveRun)
        try {
            recorder?.stop()
        } catch (t: Throwable) {
        }
        recorder?.release()
        recorder = null
        player?.release()
        player = null
        view.release()
        worker.execute { pdf?.close() }
        worker.shutdown()
    }
}
