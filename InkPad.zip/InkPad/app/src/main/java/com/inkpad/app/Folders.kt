package com.inkpad.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Folder(val id: String, var name: String, var parent: String?)

object Folders {
    private var cache: MutableList<Folder>? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "folders.json")

    @Synchronized
    fun all(ctx: Context): List<Folder> {
        val c = cache
        if (c != null) return ArrayList(c)
        val out = ArrayList<Folder>()
        try {
            val f = file(ctx)
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Folder(o.getString("id"), o.optString("name"), o.optString("parent").ifEmpty { null }))
                }
            }
        } catch (t: Throwable) {
        }
        cache = out
        return ArrayList(out)
    }

    @Synchronized
    private fun save(ctx: Context, list: List<Folder>) {
        val a = JSONArray()
        for (f in list) {
            val o = JSONObject()
            o.put("id", f.id)
            o.put("name", f.name)
            o.put("parent", f.parent ?: "")
            a.put(o)
        }
        file(ctx).writeText(a.toString())
        cache = ArrayList(list)
    }

    fun get(ctx: Context, id: String?): Folder? = if (id == null) null else all(ctx).firstOrNull { it.id == id }

    fun children(ctx: Context, parent: String?): List<Folder> =
        all(ctx).filter { it.parent == parent }.sortedBy { it.name.lowercase() }

    fun create(ctx: Context, name: String, parent: String?): Folder {
        val list = ArrayList(all(ctx))
        val f = Folder(Store.newId(), name.trim().ifEmpty { "Folder" }, parent)
        list.add(f)
        save(ctx, list)
        return f
    }

    fun rename(ctx: Context, id: String, name: String) {
        val list = ArrayList(all(ctx))
        val f = list.firstOrNull { it.id == id } ?: return
        f.name = name.trim().ifEmpty { f.name }
        save(ctx, list)
    }

    // Deleting a folder keeps its contents: they move up one level.
    fun delete(ctx: Context, id: String) {
        val list = ArrayList(all(ctx))
        val f = list.firstOrNull { it.id == id } ?: return
        for (c in list) if (c.parent == id) c.parent = f.parent
        list.remove(f)
        save(ctx, list)
        for (m in Store.list(ctx)) if (m.folder == id) Store.setFolder(ctx, m.id, f.parent)
    }

    fun tree(ctx: Context): List<Pair<Folder, Int>> {
        val list = all(ctx)
        val out = ArrayList<Pair<Folder, Int>>()
        fun walk(parent: String?, depth: Int) {
            for (f in list.filter { it.parent == parent }.sortedBy { it.name.lowercase() }) {
                out.add(Pair(f, depth))
                walk(f.id, depth + 1)
            }
        }
        walk(null, 0)
        return out
    }
}
