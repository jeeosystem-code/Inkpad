package com.inkpad.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import androidx.core.graphics.PathParser
import kotlin.math.min

object Ic {
    const val PEN = 1
    const val HL = 2
    const val ERASER = 3
    const val LASSO = 4
    const val SHAPES = 5
    const val TEXT = 6
    const val STICKY = 7
    const val IMAGE = 8
    const val TABLE = 9
    const val TAPE = 10
    const val RULER = 11
    const val LASER = 12
    const val HAND = 13
    const val UNDO = 14
    const val REDO = 15
    const val PAGES = 16
    const val MORE = 17
    const val BACK = 18
    const val PLUS = 19
    const val SEARCH = 20
    const val STAR = 21
    const val TRASH = 22
    const val COPY = 23
    const val CHECK = 24
    const val CLOSE = 25
    const val MIC = 26
    const val SHARE = 27
    const val DOWNLOAD = 28
    const val SETTINGS = 29
    const val FILE = 30
    const val FOCUS = 31
    const val CLIPBOARD = 32
    const val MOON = 33
    const val DROP = 34
    const val SORT = 35
    const val EDIT = 36
    const val CHEV_UP = 37
    const val CHEV_DOWN = 38
    const val PLAY = 39
    const val ZOOM = 40
    const val SUN = 41
    const val NOTE = 42
    const val CHECK_CIRCLE = 43
    const val SECTION = 44
    const val REVIEW = 45
    const val CHART = 46
    const val MINUS = 47
    const val FOLDER = 48
    const val FOLDER_PLUS = 49
    const val FOLDER_IMPORT = 50
    const val LIST = 51
    const val INFO = 52
    const val PHONE = 53
    const val BOLT = 54
    const val ALIGN_L = 55
    const val ALIGN_C = 56
    const val ALIGN_R = 57
    const val L_SOLID = 58
    const val L_DASH = 59
    const val L_DOT = 60
    const val TIP_FLAT = 61
    const val TIP_ROUND = 62
    const val SCROLL = 63
    const val CLOCK = 64
}

class Seg(val d: String, val fill: Boolean = false, val dashed: Boolean = false)

object Icons {
    private val defs = HashMap<Int, List<Seg>>()
    private val paths = HashMap<String, Path?>()

    private fun s(vararg d: String): List<Seg> = d.map { Seg(it) }

    init {
        defs[Ic.PEN] = s("M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z")
        defs[Ic.HL] = s("M9 11l-6 6v3h9l3-3", "M22 12l-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4")
        defs[Ic.ERASER] = s(
            "M7 21l-4.3-4.3a2 2 0 0 1 0-2.8l9.6-9.6a2 2 0 0 1 2.8 0l5.6 5.6a2 2 0 0 1 0 2.8L13 21",
            "M22 21H7", "M5 11l9 9"
        )
        defs[Ic.LASSO] = listOf(
            Seg("M12 4c5 0 9 2.2 9 5s-4 5-9 5-9-2.2-9-5 4-5 9-5z", dashed = true),
            Seg("M10 14c-1 2 0 4 2 5")
        )
        defs[Ic.SHAPES] = s(
            "M3 8.5a5.5 5.5 0 1 0 11 0 5.5 5.5 0 1 0-11 0",
            "M17.5 12l4.5 9h-9z", "M3 15h6v6H3z"
        )
        defs[Ic.TEXT] = s("M4 7V4h16v3", "M9 20h6", "M12 4v16")
        defs[Ic.STICKY] = s(
            "M15.5 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5L15.5 3z",
            "M15 3v6h6"
        )
        defs[Ic.IMAGE] = s(
            "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
            "M10 8.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z", "M21 15l-5-5L5 21"
        )
        defs[Ic.TABLE] = s(
            "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
            "M3 9h18", "M3 15h18", "M9 3v18", "M15 3v18"
        )
        defs[Ic.TAPE] = s("M3 7h18v10H3z", "M7 7v3", "M11 7v3", "M15 7v3", "M19 7v3")
        defs[Ic.RULER] = s(
            "M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0z",
            "M14.5 12.5l2-2", "M11.5 9.5l2-2", "M8.5 6.5l2-2", "M17.5 15.5l2-2"
        )
        defs[Ic.LASER] = listOf(
            Seg("M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z"),
            Seg("M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0z"),
            Seg("M12.8 12a.8.8 0 1 1-1.6 0 .8.8 0 0 1 1.6 0z", fill = true)
        )
        defs[Ic.HAND] = s(
            "M5 9l-3 3 3 3", "M9 5l3-3 3 3", "M15 19l-3 3-3-3", "M19 9l3 3-3 3", "M2 12h20", "M12 2v20"
        )
        defs[Ic.UNDO] = s("M9 14L4 9l5-5", "M20 20v-7a4 4 0 0 0-4-4H4")
        defs[Ic.REDO] = s("M15 14l5-5-5-5", "M4 20v-7a4 4 0 0 1 4-4h12")
        defs[Ic.PAGES] = s(
            "M4 3h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z",
            "M15 3h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z",
            "M4 14h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1z",
            "M15 14h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1z"
        )
        defs[Ic.MORE] = listOf(
            Seg("M13.2 5a1.2 1.2 0 1 1-2.4 0 1.2 1.2 0 0 1 2.4 0z", fill = true),
            Seg("M13.2 12a1.2 1.2 0 1 1-2.4 0 1.2 1.2 0 0 1 2.4 0z", fill = true),
            Seg("M13.2 19a1.2 1.2 0 1 1-2.4 0 1.2 1.2 0 0 1 2.4 0z", fill = true)
        )
        defs[Ic.BACK] = s("M15 18l-6-6 6-6")
        defs[Ic.PLUS] = s("M12 5v14", "M5 12h14")
        defs[Ic.SEARCH] = s("M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0z", "M21 21l-4.35-4.35")
        defs[Ic.STAR] = s("M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z")
        defs[Ic.TRASH] = s(
            "M3 6h18", "M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6",
            "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", "M10 11v6", "M14 11v6"
        )
        defs[Ic.COPY] = s(
            "M11 9h9a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-9a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2z",
            "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
        )
        defs[Ic.CHECK] = s("M20 6L9 17l-5-5")
        defs[Ic.CLOSE] = s("M18 6L6 18", "M6 6l12 12")
        defs[Ic.MIC] = s(
            "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z",
            "M19 10v2a7 7 0 0 1-14 0v-2", "M12 19v4"
        )
        defs[Ic.SHARE] = s("M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8", "M16 6l-4-4-4 4", "M12 2v13")
        defs[Ic.DOWNLOAD] = s("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", "M7 10l5 5 5-5", "M12 15V3")
        defs[Ic.SETTINGS] = s(
            "M4 21v-7", "M4 10V3", "M12 21v-9", "M12 8V3", "M20 21v-5", "M20 12V3",
            "M1 14h6", "M9 8h6", "M17 16h6"
        )
        defs[Ic.FILE] = s("M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z", "M13 2v7h7")
        defs[Ic.FOCUS] = s(
            "M8 3H5a2 2 0 0 0-2 2v3", "M21 8V5a2 2 0 0 0-2-2h-3",
            "M3 16v3a2 2 0 0 0 2 2h3", "M16 21h3a2 2 0 0 0 2-2v-3"
        )
        defs[Ic.CLIPBOARD] = s(
            "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
            "M10 2h4a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z"
        )
        defs[Ic.MOON] = s("M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z")
        defs[Ic.DROP] = s("M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z")
        defs[Ic.SORT] = s("M3 6h18", "M6 12h12", "M10 18h4")
        defs[Ic.EDIT] = s("M12 20h9", "M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z")
        defs[Ic.CHEV_UP] = s("M18 15l-6-6-6 6")
        defs[Ic.CHEV_DOWN] = s("M6 9l6 6 6-6")
        defs[Ic.PLAY] = s("M6 4l14 8-14 8z")
        defs[Ic.ZOOM] = s("M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0z", "M21 21l-4.35-4.35", "M11 8v6", "M8 11h6")
        defs[Ic.SUN] = s(
            "M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0z", "M12 1v2", "M12 21v2", "M4.22 4.22l1.42 1.42",
            "M18.36 18.36l1.42 1.42", "M1 12h2", "M21 12h2", "M4.22 19.78l1.42-1.42", "M18.36 5.64l1.42-1.42"
        )
        defs[Ic.NOTE] = s(
            "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
            "M7 9h10", "M7 13h10", "M7 17h6"
        )
        defs[Ic.CHECK_CIRCLE] = s("M22 11.08V12a10 10 0 1 1-5.93-9.14", "M22 4L12 14.01l-3-3")
        defs[Ic.SECTION] = listOf(
            Seg("M4 4h16v5H4z"),
            Seg("M3 12h18", dashed = true),
            Seg("M4 15h16v5H4z")
        )
        defs[Ic.REVIEW] = s(
            "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
            "M10 2h4a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z",
            "M9 14l2 2 4-4"
        )
        defs[Ic.CHART] = s("M18 20V10", "M12 20V4", "M6 20v-6")
        defs[Ic.MINUS] = s("M5 12h14")
        val folder = "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"
        defs[Ic.FOLDER] = s(folder)
        defs[Ic.FOLDER_PLUS] = s(folder, "M12 11v6", "M9 14h6")
        defs[Ic.FOLDER_IMPORT] = s(folder, "M12 10.5v6", "M9.5 14l2.5 2.5 2.5-2.5")
        defs[Ic.LIST] = s("M8 6h13", "M8 12h13", "M8 18h13", "M3 6h.01", "M3 12h.01", "M3 18h.01")
        defs[Ic.INFO] = s("M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0z", "M12 16v-4", "M12 8h.01")
        defs[Ic.BOLT] = s("M13 2L3 14h9l-1 8 10-12h-9l1-8z")
        defs[Ic.ALIGN_L] = s("M3 6h18", "M3 12h12", "M3 18h16")
        defs[Ic.ALIGN_C] = s("M3 6h18", "M6 12h12", "M4 18h16")
        defs[Ic.ALIGN_R] = s("M3 6h18", "M9 12h12", "M5 18h16")
        defs[Ic.L_SOLID] = s("M3 12h18")
        defs[Ic.L_DASH] = s("M3 12h4", "M10 12h4", "M17 12h4")
        defs[Ic.L_DOT] = s("M4 12h.01", "M9 12h.01", "M14 12h.01", "M19 12h.01")
        defs[Ic.TIP_FLAT] = s("M7 6h10v12H7z")
        defs[Ic.TIP_ROUND] = s("M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16z")
        defs[Ic.SCROLL] = s("M12 3v18", "M8 7l4-4 4 4", "M8 17l4 4 4-4")
        defs[Ic.CLOCK] = s("M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0z", "M12 6v6l4 2")
        defs[Ic.PHONE] = s("M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z", "M12 18h.01")
    }

    private fun path(d: String): Path? {
        if (paths.containsKey(d)) return paths[d]
        val p: Path? = try {
            PathParser.createPathFromPathData(d)
        } catch (t: Throwable) {
            null
        }
        paths[d] = p
        return p
    }

    fun draw(c: Canvas, id: Int, p: Paint, filled: Boolean) {
        val segs = defs[id] ?: return
        for (sg in segs) {
            val path = path(sg.d) ?: continue
            if (sg.fill || filled) p.style = Paint.Style.FILL_AND_STROKE else p.style = Paint.Style.STROKE
            p.pathEffect = if (sg.dashed) DashPathEffect(floatArrayOf(2.4f, 2.4f), 0f) else null
            c.drawPath(path, p)
        }
        p.pathEffect = null
        p.style = Paint.Style.STROKE
    }
}

class IconView(ctx: Context, var icon: Int, var tint: Int, private val ratio: Float = 0.58f) : View(ctx) {
    var filled = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
    }

    fun set(i: Int, t: Int) {
        icon = i
        tint = t
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val raw = min(width, height) * ratio
        if (raw <= 0f) return
        val s = raw.coerceIn(context.dpf(12f), context.dpf(30f))
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        val k = s / 24f
        c.scale(k, k)
        p.color = tint
        p.strokeWidth = context.dpf(1.8f) / k
        Icons.draw(c, icon, p, filled)
        c.restore()
    }
}
