package com.inkpad.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.math.min

class MainActivity : Activity() {

    private val REQ_PDF = 21
    private lateinit var grid: GridView
    private lateinit var emptyBox: LinearLayout
    private lateinit var subtitle: TextView
    private lateinit var column: LinearLayout
    private lateinit var actionDock: LinearLayout
    private var all: List<Meta> = emptyList()
    private var shown: List<Meta> = emptyList()
    private var query = ""
    private var filter = 0
    private var topI = 0
    private var botI = 0
    private val animated = HashSet<String>()
    private val thumbs = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            return makeCard(shown[position], position)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.apply(this)
        edgeToEdge()
        buildUi()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_VIEW && i.data != null) {
            val u = i.data!!
            i.data = null
            importPdf(u)
        }
    }

    // ============================ UI ============================

    private fun buildUi() {
        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        // header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(22), 0, dp(16), 0)
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = label("InkPad", 34f, Theme.text(), Fonts.medium)
        title.letterSpacing = -0.02f
        subtitle = label("", 13f, Theme.sub())
        titles.addView(title)
        titles.addView(subtitle)
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val settings = FrameLayout(this)
        settings.background = glass(22f)
        settings.addView(IconView(this, Ic.SETTINGS, Theme.text(), 0.5f), FrameLayout.LayoutParams(dp(44), dp(44)))
        settings.isClickable = true
        settings.pressable()
        settings.setOnClickListener {
            it.tick()
            settingsSheet { }
        }
        header.addView(settings, LinearLayout.LayoutParams(dp(44), dp(44)))
        column.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // search
        val search = LinearLayout(this)
        search.orientation = LinearLayout.HORIZONTAL
        search.gravity = Gravity.CENTER_VERTICAL
        search.background = glass(20f)
        search.setPadding(dp(8), 0, dp(4), 0)
        search.addView(IconView(this, Ic.SEARCH, Theme.sub(), 0.5f), LinearLayout.LayoutParams(dp(36), dp(46)))
        val et = EditText(this)
        et.hint = "Search notebooks"
        et.setHintTextColor(Theme.sub())
        et.setTextColor(Theme.text())
        et.typeface = Fonts.regular
        et.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
        et.background = null
        et.maxLines = 1
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                applyFilter()
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        search.addView(et, LinearLayout.LayoutParams(0, dp(46), 1f))
        val sort = IconView(this, Ic.SORT, Theme.sub(), 0.5f)
        sort.isClickable = true
        sort.pressable()
        sort.setOnClickListener {
            it.tick()
            chooseSheet(
                "Sort by", listOf("Recently edited", "Name", "Most pages"),
                listOf(Ic.EDIT, Ic.TEXT, Ic.PAGES), Prefs.intOf(this, "sort", 0)
            ) { i ->
                Prefs.setInt(this, "sort", i)
                reload()
            }
        }
        search.addView(sort, LinearLayout.LayoutParams(dp(44), dp(46)))
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.setMargins(dp(16), dp(16), dp(16), dp(10))
        column.addView(search, slp)

        // filter chips
        val chips = chipRow(listOf("All", "Starred", "Notes", "PDFs"), 0) { i ->
            filter = i
            applyFilter()
        }
        chips.setPadding(dp(16), 0, dp(16), dp(6))
        chips.clipToPadding = false
        column.addView(chips, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // grid
        grid = GridView(this)
        grid.numColumns = GridView.AUTO_FIT
        grid.columnWidth = dp(160)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.horizontalSpacing = dp(14)
        grid.verticalSpacing = dp(14)
        grid.setPadding(dp(16), dp(10), dp(16), dp(120))
        grid.clipToPadding = false
        grid.selector = ColorDrawable(Color.TRANSPARENT)
        grid.isVerticalScrollBarEnabled = false
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> openNote(shown[pos].id) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            showItemSheet(shown[pos])
            true
        }
        column.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // empty state
        emptyBox = LinearLayout(this)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        val badge = FrameLayout(this)
        badge.background = accentFill(40f)
        badge.addView(IconView(this, Ic.PEN, Color.WHITE, 0.5f), FrameLayout.LayoutParams(dp(80), dp(80)))
        emptyBox.addView(badge, LinearLayout.LayoutParams(dp(80), dp(80)))
        val e1 = label("Start your first note", 20f, Theme.text(), Fonts.medium)
        e1.gravity = Gravity.CENTER
        e1.setPadding(0, dp(18), 0, dp(4))
        val e2 = label("Write by hand, or import a PDF to annotate it.", 14f, Theme.sub())
        e2.gravity = Gravity.CENTER
        emptyBox.addView(e1)
        emptyBox.addView(e2)
        emptyBox.visibility = View.GONE
        root.addView(emptyBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // floating action dock
        actionDock = LinearLayout(this)
        actionDock.orientation = LinearLayout.HORIZONTAL
        actionDock.gravity = Gravity.CENTER_VERTICAL
        actionDock.background = glass(32f)
        actionDock.elevation = dpf(10f)
        actionDock.setPadding(dp(8), dp(8), dp(8), dp(8))
        val importBtn = actionButton(Ic.FILE, "Import PDF", false) { pickPdf() }
        val newBtn = actionButton(Ic.PLUS, "New note", true) { askNew() }
        actionDock.addView(importBtn)
        val nlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        nlp.leftMargin = dp(8)
        actionDock.addView(newBtn, nlp)
        root.addView(actionDock, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        setContentView(root)

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, ins ->
            topI = ins.systemWindowInsetTop
            botI = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        root.requestApplyInsets()
        applyInsets()
    }

    private fun applyInsets() {
        column.setPadding(0, topI + dp(16), 0, 0)
        val lp = actionDock.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = botI + dp(18)
        actionDock.layoutParams = lp
    }

    private fun actionButton(icon: Int, text: String, primary: Boolean, onClick: () -> Unit): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER
        b.setPadding(dp(18), dp(12), dp(20), dp(12))
        val fg = if (primary) Color.WHITE else Theme.text()
        b.background = if (primary) accentFill(24f) else fieldBg(24f)
        b.addView(IconView(this, icon, fg, 0.85f), LinearLayout.LayoutParams(dp(22), dp(22)))
        val t = label(text, 15f, fg, Fonts.medium)
        t.setPadding(dp(8), 0, 0, 0)
        b.addView(t)
        b.isClickable = true
        b.pressable()
        b.setOnClickListener {
            it.tick()
            onClick()
        }
        return b
    }

    private fun makeCard(m: Meta, position: Int): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = glass(22f)
        card.setPadding(dp(10), dp(10), dp(10), dp(12))

        val thumbBox = FrameLayout(this)
        val ph = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x33FFFFFF, 0x14000000))
        ph.cornerRadius = dpf(14f)
        thumbBox.background = if (Theme.dark) fieldBg(14f) else ph
        thumbBox.clipToOutline = true
        thumbBox.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dpf(14f))
            }
        }
        val key = m.id + "@" + m.modified
        var bmp = thumbs.get(key)
        if (bmp == null) {
            val f = File(Store.dir(this, m.id), "thumb.png")
            if (f.exists()) {
                bmp = try {
                    BitmapFactory.decodeFile(f.path)
                } catch (t: Throwable) {
                    null
                }
                if (bmp != null) thumbs.put(key, bmp)
            }
        }
        if (bmp != null) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
            thumbBox.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            thumbBox.addView(
                IconView(this, if (m.hasPdf) Ic.FILE else Ic.NOTE, Theme.sub(), 0.4f),
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        if (m.hasPdf) {
            val badge = label("PDF", 10.5f, Color.WHITE, Fonts.medium)
            badge.background = accentFill(8f)
            badge.setPadding(dp(8), dp(3), dp(8), dp(3))
            val blp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
            blp.setMargins(dp(8), 0, 0, dp(8))
            thumbBox.addView(badge, blp)
        }
        val starred = Prefs.starred(this).contains(m.id)
        val star = IconView(this, Ic.STAR, if (starred) 0xFFFFC53D.toInt() else Theme.sub(), 0.52f)
        star.filled = starred
        star.isClickable = true
        star.pressable()
        star.setOnClickListener {
            it.tick()
            Prefs.toggleStar(this, m.id)
            applyFilter()
        }
        thumbBox.addView(star, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.TOP or Gravity.END))
        card.addView(thumbBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(176)))

        val t = label(m.title, 14.5f, Theme.text(), Fonts.medium)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(2), dp(8), 0, 0)
        card.addView(t)
        val d = label(
            "${m.pages} page${if (m.pages == 1) "" else "s"} · " +
                DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(m.modified)),
            11.5f, Theme.sub()
        )
        d.setPadding(dp(2), 0, 0, 0)
        card.addView(d)

        if (animated.add(m.id)) {
            card.alpha = 0f
            card.translationY = dp(18).toFloat()
            card.animate().alpha(1f).translationY(0f).setStartDelay(min(position, 8) * 35L).setDuration(280).start()
        }
        return card
    }

    // ============================ data ============================

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        val l = Store.list(this)
        all = when (Prefs.intOf(this, "sort", 0)) {
            1 -> l.sortedBy { it.title.lowercase() }
            2 -> l.sortedByDescending { it.pages }
            else -> l
        }
        applyFilter()
    }

    private fun applyFilter() {
        val stars = Prefs.starred(this)
        shown = all.filter { m ->
            val okF = when (filter) {
                1 -> stars.contains(m.id)
                2 -> !m.hasPdf
                3 -> m.hasPdf
                else -> true
            }
            okF && (query.isEmpty() || m.title.contains(query, true))
        }
        adapter.notifyDataSetChanged()
        emptyBox.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
        val n = all.size
        subtitle.text = if (n == 0) "Your notes and PDFs, in one place" else "$n notebook${if (n == 1) "" else "s"}"
    }

    private fun openNote(id: String) {
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra("id", id)
        startActivity(i)
    }

    private fun showItemSheet(m: Meta) {
        val starred = Prefs.starred(this).contains(m.id)
        chooseSheet(
            m.title,
            listOf("Open", "Rename", "Duplicate", if (starred) "Remove star" else "Add star", "Delete"),
            listOf(Ic.PEN, Ic.EDIT, Ic.COPY, Ic.STAR, Ic.TRASH)
        ) { i ->
            when (i) {
                0 -> openNote(m.id)
                1 -> rename(m)
                2 -> {
                    Store.duplicate(this, m.id)
                    reload()
                }
                3 -> {
                    Prefs.toggleStar(this, m.id)
                    applyFilter()
                }
                4 -> confirmSheet("Delete “${m.title}”?", "This can't be undone.", "Delete", true) {
                    Store.delete(this, m.id)
                    reload()
                }
            }
        }
    }

    private fun rename(m: Meta) {
        inputSheet("Rename notebook", m.title, "Title") { s ->
            val nb = Store.load(this, m.id)
            if (nb != null && s.isNotEmpty()) {
                nb.title = s
                Store.save(this, nb)
                reload()
            }
        }
    }

    // ============================ new notebook ============================

    private val noEnv = object : Env {
        override fun image(name: String): Bitmap? = null
    }

    private fun askNew() {
        val sizes = listOf(
            Pair("A4", floatArrayOf(595f, 842f)),
            Pair("A5", floatArrayOf(420f, 595f)),
            Pair("Letter", floatArrayOf(612f, 792f)),
            Pair("Slide 16:9", floatArrayOf(960f, 540f))
        )
        var sizeIdx = 0
        var tplIdx = 0
        var colIdx = 0

        val name = EditText(this)
        name.setText("Untitled")
        name.setSelection(name.text.length)
        name.hint = "Title"
        name.setTextColor(Theme.text())
        name.setHintTextColor(Theme.sub())
        name.background = fieldBg(14f)
        name.setPadding(dp(14), dp(12), dp(14), dp(12))
        name.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
        name.maxLines = 1
        name.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES

        val sh = Sheet(this).title("New notebook")
        sh.view(name)

        // template previews
        val frames = ArrayList<FrameLayout>()
        val images = ArrayList<ImageView>()
        fun renderPreviews() {
            for (i in TEMPLATE_IDS.indices) {
                val tmp = Notebook("tmp", "")
                tmp.pageColor = colIdx
                val pg = Page(sizes[sizeIdx].second[0], sizes[sizeIdx].second[1])
                pg.template = TEMPLATE_IDS[i]
                tmp.pages.add(pg)
                try {
                    images[i].setImageBitmap(Exporter.renderPage(tmp, 0, dp(84), null, noEnv))
                } catch (t: Throwable) {
                }
                val sel = i == tplIdx
                frames[i].background = roundBg(Color.TRANSPARENT, 14, if (sel) Theme.accent else Theme.field(), if (sel) 3 else 1)
            }
        }

        fun sectionLp(): LinearLayout.LayoutParams {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(14)
            lp.bottomMargin = dp(6)
            return lp
        }
        sh.view(label("Template", 12f, Theme.sub(), Fonts.medium), sectionLp())
        val tsv = HorizontalScrollView(this)
        tsv.isHorizontalScrollBarEnabled = false
        val trow = LinearLayout(this)
        trow.orientation = LinearLayout.HORIZONTAL
        for (i in TEMPLATE_IDS.indices) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val fr = FrameLayout(this)
            fr.setPadding(dp(4), dp(4), dp(4), dp(4))
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
            fr.addView(iv, FrameLayout.LayoutParams(dp(84), dp(108)))
            frames.add(fr)
            images.add(iv)
            col.addView(fr)
            val tv = label(TEMPLATE_NAMES[i], 11f, Theme.text(), Fonts.medium)
            tv.gravity = Gravity.CENTER
            col.addView(tv)
            col.isClickable = true
            col.pressable()
            col.setOnClickListener {
                tplIdx = i
                renderPreviews()
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            trow.addView(col, lp)
        }
        tsv.addView(trow)
        sh.view(tsv)

        sh.view(label("Page size", 12f, Theme.sub(), Fonts.medium), sectionLp())
        sh.view(chipRow(sizes.map { it.first }, 0) { i ->
            sizeIdx = i
            renderPreviews()
        })
        sh.view(label("Paper", 12f, Theme.sub(), Fonts.medium), sectionLp())
        sh.view(chipRow(PAGE_COLOR_NAMES.toList(), 0) { i ->
            colIdx = i
            renderPreviews()
        })
        renderPreviews()

        sh.secondary("Cancel").primary("Create") {
            val id = Store.newId()
            val nb = Notebook(id, name.text.toString().trim().ifEmpty { "Untitled" })
            nb.pageColor = colIdx
            val p = Page(sizes[sizeIdx].second[0], sizes[sizeIdx].second[1])
            p.template = TEMPLATE_IDS[tplIdx]
            nb.pages.add(p)
            Store.save(this, nb)
            Exporter.writeThumb(this, nb, null, ImgEnv(Store.dir(this, id)))
            openNote(id)
        }.show()
    }

    // ============================ import ============================

    private fun pickPdf() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/pdf"
        startActivityForResult(i, REQ_PDF)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == REQ_PDF && resultCode == RESULT_OK && uri != null) importPdf(uri)
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) return c.getString(i).removeSuffix(".pdf").removeSuffix(".PDF")
                }
            }
        } catch (t: Throwable) {
        }
        return "Imported PDF"
    }

    private fun importPdf(uri: Uri) {
        toast("Importing PDF…")
        val title = displayName(uri)
        Thread {
            var src: PdfSource? = null
            try {
                val id = Store.newId()
                val d = Store.dir(this, id)
                val f = File(d, "doc.pdf")
                val ins = contentResolver.openInputStream(uri) ?: throw RuntimeException("no stream")
                ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                src = PdfSource(f)
                val nb = Notebook(id, title)
                nb.hasPdf = true
                for (k in 0 until src.count) {
                    val sz = src.pageSize(k)
                    val p = Page(sz.first, sz.second)
                    p.pdfIndex = k
                    nb.pages.add(p)
                }
                if (nb.pages.isEmpty()) throw RuntimeException("empty pdf")
                Store.save(this, nb)
                Exporter.writeThumb(this, nb, src, ImgEnv(d))
                runOnUiThread { openNote(id) }
            } catch (t: Throwable) {
                runOnUiThread { toast("Could not import this PDF (it may be password-protected)") }
            } finally {
                src?.close()
            }
        }.start()
    }
}
