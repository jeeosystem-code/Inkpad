package com.inkpad.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Spinner
import android.widget.TextView
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {

    private val REQ_PDF = 21
    private lateinit var grid: GridView
    private lateinit var empty: TextView
    private var all: List<Meta> = emptyList()
    private var shown: List<Meta> = emptyList()
    private var query = ""
    private val thumbs = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val m = shown[position]
            val card = LinearLayout(this@MainActivity)
            card.orientation = LinearLayout.VERTICAL
            card.background = roundBg(Color.WHITE, 10, 0xFFDDDDDD.toInt(), 1)
            card.setPadding(dp(8), dp(8), dp(8), dp(8))
            val iv = ImageView(this@MainActivity)
            iv.setBackgroundColor(0xFFF1F1F1.toInt())
            iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
            val key = m.id + "@" + m.modified
            var bmp = thumbs.get(key)
            if (bmp == null) {
                val f = File(Store.dir(this@MainActivity, m.id), "thumb.png")
                if (f.exists()) {
                    bmp = try {
                        BitmapFactory.decodeFile(f.path)
                    } catch (t: Throwable) {
                        null
                    }
                    if (bmp != null) thumbs.put(key, bmp)
                }
            }
            if (bmp != null) iv.setImageBitmap(bmp)
            card.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)))
            val t = label(m.title, 14f, 0xFF202124.toInt())
            t.maxLines = 1
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            t.setPadding(0, dp(6), 0, 0)
            card.addView(t)
            val d = label(
                "${m.pages} page${if (m.pages == 1) "" else "s"} · " +
                    DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(m.modified)),
                11f, 0xFF70757A.toInt()
            )
            card.addView(d)
            return card
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF3F51B5.toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFFF5F6FA.toInt())

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xFF3F51B5.toInt())
        bar.setPadding(dp(16), dp(8), dp(8), dp(8))
        val title = label("InkPad", 22f)
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val imp = Button(this)
        imp.text = "Import PDF"
        imp.setOnClickListener { pickPdf() }
        val add = Button(this)
        add.text = "+ New"
        add.setOnClickListener { askNew() }
        bar.addView(imp)
        bar.addView(add)

        val search = EditText(this)
        search.hint = "Search notebooks"
        search.maxLines = 1
        search.inputType = android.text.InputType.TYPE_CLASS_TEXT
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                applyFilter()
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })

        grid = GridView(this)
        grid.numColumns = GridView.AUTO_FIT
        grid.columnWidth = dp(150)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.horizontalSpacing = dp(10)
        grid.verticalSpacing = dp(10)
        grid.setPadding(dp(10), dp(10), dp(10), dp(10))
        grid.clipToPadding = false
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> openNote(shown[pos].id) }
        grid.setOnItemLongClickListener { _, v, pos, _ ->
            showItemMenu(v, shown[pos])
            true
        }

        empty = label("No notebooks yet.\nTap “+ New” to start writing, or “Import PDF” to annotate a PDF.", 15f, 0xFF70757A.toInt())
        empty.gravity = Gravity.CENTER
        empty.setPadding(dp(24), dp(48), dp(24), dp(24))

        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(empty, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_VIEW && i.data != null) {
            val u = i.data!!
            i.data = null
            importPdf(u)
        }
    }

    override fun onResume() {
        super.onResume()
        all = Store.list(this)
        applyFilter()
    }

    private fun applyFilter() {
        shown = if (query.isEmpty()) all else all.filter { it.title.contains(query, true) }
        adapter.notifyDataSetChanged()
        empty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openNote(id: String) {
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra("id", id)
        startActivity(i)
    }

    private fun showItemMenu(anchor: View, m: Meta) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Rename")
        pm.menu.add(0, 2, 0, "Duplicate")
        pm.menu.add(0, 3, 0, "Delete")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> rename(m)
                2 -> {
                    Store.duplicate(this, m.id)
                    onResume()
                }
                3 -> AlertDialog.Builder(this)
                    .setTitle("Delete “${m.title}”?")
                    .setMessage("This cannot be undone.")
                    .setPositiveButton("Delete") { _, _ ->
                        Store.delete(this, m.id)
                        onResume()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun rename(m: Meta) {
        val et = EditText(this)
        et.setText(m.title)
        et.setSelection(et.text.length)
        AlertDialog.Builder(this)
            .setTitle("Rename")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val nb = Store.load(this, m.id)
                val s = et.text.toString().trim()
                if (nb != null && s.isNotEmpty()) {
                    nb.title = s
                    Store.save(this, nb)
                    onResume()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askNew() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = EditText(this)
        name.hint = "Title"
        name.setText("Untitled")
        name.setSelection(name.text.length)
        val tpl = Spinner(this)
        tpl.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, TEMPLATE_NAMES)
        val col = Spinner(this)
        col.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, PAGE_COLOR_NAMES)
        box.addView(name)
        box.addView(label("Template", 12f, 0xFF70757A.toInt()))
        box.addView(tpl)
        box.addView(label("Page color", 12f, 0xFF70757A.toInt()))
        box.addView(col)
        AlertDialog.Builder(this)
            .setTitle("New notebook")
            .setView(box)
            .setPositiveButton("Create") { _, _ ->
                val id = Store.newId()
                val nb = Notebook(id, name.text.toString().trim().ifEmpty { "Untitled" })
                nb.pageColor = col.selectedItemPosition
                val p = Page(595f, 842f)
                p.template = TEMPLATE_IDS[tpl.selectedItemPosition]
                nb.pages.add(p)
                Store.save(this, nb)
                openNote(id)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickPdf() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/pdf"
        startActivityForResult(i, REQ_PDF)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == REQ_PDF && resultCode == RESULT_OK && uri != null) importPdf(uri)
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) return c.getString(i).removeSuffix(".pdf").removeSuffix(".PDF")
                }
            }
        } catch (t: Throwable) {
        }
        return "Imported PDF"
    }

    private fun importPdf(uri: Uri) {
        toast("Importing PDF…")
        val title = displayName(uri)
        Thread {
            var src: PdfSource? = null
            try {
                val id = Store.newId()
                val d = Store.dir(this, id)
                val f = File(d, "doc.pdf")
                val ins = contentResolver.openInputStream(uri) ?: throw RuntimeException("no stream")
                ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                src = PdfSource(f)
                val nb = Notebook(id, title)
                nb.hasPdf = true
                for (k in 0 until src.count) {
                    val sz = src.pageSize(k)
                    val p = Page(sz.first, sz.second)
                    p.pdfIndex = k
                    nb.pages.add(p)
                }
                if (nb.pages.isEmpty()) throw RuntimeException("empty pdf")
                Store.save(this, nb)
                Exporter.writeThumb(this, nb, src, ImgEnv(d))
                runOnUiThread { openNote(id) }
            } catch (t: Throwable) {
                runOnUiThread { toast("Could not import this PDF (it may be password-protected)") }
            } finally {
                src?.close()
            }
        }.start()
    }
}
