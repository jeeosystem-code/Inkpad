package com.inkpad.app

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors
import kotlin.math.max

sealed class Row
class FolderRow(val folder: Folder, val count: Int) : Row()
class NoteRow(val meta: Meta) : Row()

class MainActivity : Activity() {

    private val REQ_PDF = 21
    private val REQ_REVIEW = 22
    private val REQ_TREE = 23
    private val REQ_IMAGES = 24

    private lateinit var root: FrameLayout
    private lateinit var column: LinearLayout
    private lateinit var rv: RecyclerView
    private lateinit var lm: GridLayoutManager
    private lateinit var titleTv: TextView
    private lateinit var subtitle: TextView
    private lateinit var backBtn: IconView
    private lateinit var viewBtn: IconView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyIcon: IconView
    private lateinit var emptyTitle: TextView
    private lateinit var scrim: View
    private lateinit var dialScroll: ScrollView
    private lateinit var dialCol: LinearLayout
    private lateinit var fab: FrameLayout
    private lateinit var fabIcon: IconView
    private lateinit var fabRing: View
    private var dialOpen = false
    private var ringAnim: ValueAnimator? = null

    private class DialDef(val icon: Int, val label: String, val action: () -> Unit)
    private lateinit var searchEt: EditText

    private var allNotes: List<Meta> = emptyList()
    private var rows: List<Row> = emptyList()
    private var curFolder: String? = null
    private var query = ""
    private var filter = 0
    private var topI = 0
    private var botI = 0
    private val io = Executors.newFixedThreadPool(2)
    private val thumbs = object : LruCache<String, Bitmap>(10 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val adapter = LibAdapter()

    private class Holder(v: View, val bind: (Row) -> Unit) : RecyclerView.ViewHolder(v)

    private class ThumbParts(
        val box: FrameLayout,
        val iv: ImageView,
        val ph: IconView,
        val badges: FrameLayout,
        val star: IconView
    )

    private inner class LibAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int = rows.size

        override fun getItemViewType(position: Int): Int {
            val list = Prefs.intOf(this@MainActivity, "view_mode", 0) == 1
            val isFolder = rows[position] is FolderRow
            return (if (list) 2 else 0) + (if (isFolder) 0 else 1)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return when (viewType) {
                0 -> buildFolderCard()
                1 -> buildNoteCard()
                2 -> buildFolderRow()
                else -> buildNoteRow()
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            (holder as Holder).bind(rows[position])
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.apply(this)
        edgeToEdge()
        buildUi()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_VIEW && i.data != null) {
            val u = i.data!!
            i.data = null
            importPdf(u, false)
        }
    }

    // ============================ UI ============================

    private fun buildUi() {
        root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        // header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(12), 0, dp(16), 0)
        backBtn = IconView(this, Ic.BACK, Theme.text(), 0.6f)
        backBtn.visibility = View.GONE
        backBtn.isClickable = true
        backBtn.pressable()
        backBtn.setOnClickListener { goUp() }
        header.addView(backBtn, LinearLayout.LayoutParams(dp(44), dp(48)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(8), 0, 0, 0)
        titleTv = label("InkPad", 32f, Theme.text(), Fonts.medium)
        titleTv.letterSpacing = -0.02f
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        subtitle = label("", 13f, Theme.sub())
        titles.addView(titleTv)
        titles.addView(subtitle)
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val settings = FrameLayout(this)
        settings.background = glass(24f)
        settings.addView(IconView(this, Ic.SETTINGS, Theme.text(), 0.5f), FrameLayout.LayoutParams(dp(48), dp(48)))
        settings.isClickable = true
        settings.contentDescription = "Settings"
        settings.pressable()
        settings.setOnClickListener {
            it.tick()
            settingsSheet { }
        }
        header.addView(settings, LinearLayout.LayoutParams(dp(48), dp(48)))
        column.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // search + view/sort
        val search = LinearLayout(this)
        search.orientation = LinearLayout.HORIZONTAL
        search.gravity = Gravity.CENTER_VERTICAL
        search.background = glass(22f)
        search.setPadding(dp(8), 0, dp(4), 0)
        search.addView(IconView(this, Ic.SEARCH, Theme.sub(), 0.5f), LinearLayout.LayoutParams(dp(36), dp(50)))
        searchEt = EditText(this)
        searchEt.hint = "Search"
        searchEt.setHintTextColor(Theme.sub())
        searchEt.setTextColor(Theme.text())
        searchEt.typeface = Fonts.regular
        searchEt.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f * UiScale.factor(this))
        searchEt.background = null
        searchEt.maxLines = 1
        searchEt.inputType = InputType.TYPE_CLASS_TEXT
        searchEt.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                rebuildRows()
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        search.addView(searchEt, LinearLayout.LayoutParams(0, dp(50), 1f))
        viewBtn = IconView(this, Ic.LIST, Theme.sub(), 0.5f)
        viewBtn.isClickable = true
        viewBtn.contentDescription = "View"
        viewBtn.pressable()
        viewBtn.setOnClickListener {
            it.tick()
            val cur = Prefs.intOf(this, "view_mode", 0)
            Prefs.setInt(this, "view_mode", if (cur == 0) 1 else 0)
            applyViewMode()
        }
        search.addView(viewBtn, LinearLayout.LayoutParams(dp(48), dp(50)))
        val sort = IconView(this, Ic.SORT, Theme.sub(), 0.5f)
        sort.isClickable = true
        sort.contentDescription = "Sort"
        sort.pressable()
        sort.setOnClickListener {
            it.tick()
            chooseSheet(
                "Sort", listOf("Recent", "Name A–Z", "Most pages", "Oldest", "Name Z–A"),
                listOf(Ic.EDIT, Ic.TEXT, Ic.FILE, Ic.EDIT, Ic.TEXT), Prefs.intOf(this, "sort", 0)
            ) { i ->
                Prefs.setInt(this, "sort", i)
                reload()
            }
        }
        search.addView(sort, LinearLayout.LayoutParams(dp(48), dp(50)))
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.setMargins(dp(16), dp(14), dp(16), dp(8))
        column.addView(search, slp)

        // chips
        val chips = chipRow(listOf("All", "Starred", "Notes", "PDFs", "Review"), 0) { i ->
            filter = i
            rebuildRows()
        }
        chips.setPadding(dp(16), 0, dp(16), dp(6))
        chips.clipToPadding = false
        column.addView(chips, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // list
        rv = RecyclerView(this)
        lm = GridLayoutManager(this, 2)
        rv.layoutManager = lm
        rv.adapter = adapter
        rv.itemAnimator = null
        rv.clipToPadding = false
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        rv.isVerticalScrollBarEnabled = false
        rv.setItemViewCacheSize(10)
        rv.setPadding(dp(9), dp(6), dp(9), dp(120))
        column.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // empty state
        emptyBox = LinearLayout(this)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        val badge = FrameLayout(this)
        badge.background = accentFill(40f)
        emptyIcon = IconView(this, Ic.PEN, Color.WHITE, 0.5f)
        badge.addView(emptyIcon, FrameLayout.LayoutParams(dp(80), dp(80)))
        emptyBox.addView(badge, LinearLayout.LayoutParams(dp(80), dp(80)))
        emptyTitle = label("", 19f, Theme.text(), Fonts.medium)
        emptyTitle.gravity = Gravity.CENTER
        emptyTitle.setPadding(0, dp(16), 0, 0)
        emptyBox.addView(emptyTitle)
        emptyBox.visibility = View.GONE
        root.addView(emptyBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        buildDial()

        setContentView(root)

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, ins: WindowInsets ->
            topI = ins.systemWindowInsetTop
            botI = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        root.requestApplyInsets()
        applyInsets()
        applyViewMode()
    }

    private fun roundIcon(icon: Int, desc: String, onClick: () -> Unit): FrameLayout {
        val b = FrameLayout(this)
        b.background = fieldBg(26f)
        b.addView(IconView(this, icon, Theme.text(), 0.5f), FrameLayout.LayoutParams(dp(52), dp(52)))
        b.isClickable = true
        b.contentDescription = desc
        b.pressable()
        b.setOnClickListener {
            it.tick()
            onClick()
        }
        val lp = LinearLayout.LayoutParams(dp(52), dp(52))
        lp.rightMargin = dp(4)
        b.layoutParams = lp
        return b
    }

    private fun applyInsets() {
        column.setPadding(0, topI + dp(10), 0, 0)
        val m = botI + dp(20)
        for (v in listOf<View>(fab, fabRing)) {
            val lp = v.layoutParams as FrameLayout.LayoutParams
            lp.bottomMargin = m
            lp.rightMargin = dp(20)
            v.layoutParams = lp
        }
        val dl = dialScroll.layoutParams as FrameLayout.LayoutParams
        dl.bottomMargin = m + dp(60) + dp(16)
        dl.rightMargin = dp(20)
        dialScroll.layoutParams = dl
    }

    private fun spanCount(): Int {
        val w = resources.displayMetrics.widthPixels
        val list = Prefs.intOf(this, "view_mode", 0) == 1
        val cell = when (Prefs.intOf(this, "grid_size", 1)) {
            0 -> 132
            2 -> 212
            else -> 172
        }
        return if (list) (if (w >= dp(900)) 2 else 1) else max(2, w / dp(cell))
    }

    private fun applyViewMode() {
        val list = Prefs.intOf(this, "view_mode", 0) == 1
        viewBtn.set(if (list) Ic.PAGES else Ic.LIST, Theme.sub())
        lm.spanCount = spanCount()
        adapter.notifyDataSetChanged()
    }

    // ============================ cards ============================

    private fun metaLine(m: Meta): String =
        "${m.pages} page${if (m.pages == 1) "" else "s"} · " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(m.modified))

    private fun noteBadge(m: Meta): View? {
        if (m.review) {
            val badge = LinearLayout(this)
            badge.orientation = LinearLayout.HORIZONTAL
            badge.gravity = Gravity.CENTER_VERTICAL
            badge.background = roundBg(Review.tone(m.score), 11)
            badge.setPadding(dp(8), dp(3), dp(10), dp(3))
            badge.addView(IconView(this, Ic.CHECK_CIRCLE, Color.WHITE, 0.9f), LinearLayout.LayoutParams(dp(16), dp(16)))
            val st = label(Review.fmt(m.score), 12f, Color.WHITE, Fonts.medium)
            st.setPadding(dp(4), 0, 0, 0)
            badge.addView(st)
            return badge
        }
        if (m.hasPdf) {
            val badge = label("PDF", 10.5f, Color.WHITE, Fonts.medium)
            badge.background = accentFill(8f)
            badge.setPadding(dp(8), dp(3), dp(8), dp(3))
            return badge
        }
        return null
    }

    private fun makeThumb(withStar: Boolean): ThumbParts {
        val box = FrameLayout(this)
        box.background = fieldBg(14f)
        box.clipToOutline = true
        val rad = dpf(14f)
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, rad)
            }
        }
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        box.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val ph = IconView(this, Ic.NOTE, Theme.sub(), 0.4f)
        box.addView(ph, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val badges = FrameLayout(this)
        val blp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
        blp.setMargins(dp(6), 0, 0, dp(6))
        box.addView(badges, blp)
        val star = IconView(this, Ic.STAR, Theme.sub(), 0.52f)
        star.isClickable = true
        star.pressable()
        if (withStar) box.addView(star, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END))
        return ThumbParts(box, iv, ph, badges, star)
    }

    private fun loadThumb(iv: ImageView, ph: View, m: Meta) {
        val key = m.id + "@" + m.modified
        iv.tag = key
        val cached = thumbs.get(key)
        if (cached != null) {
            iv.setImageBitmap(cached)
            ph.visibility = View.GONE
            return
        }
        iv.setImageDrawable(null)
        ph.visibility = View.VISIBLE
        io.execute {
            val f = File(Store.dir(this, m.id), "thumb.png")
            if (!f.exists()) return@execute
            val b = try {
                BitmapFactory.decodeFile(f.path)
            } catch (t: Throwable) {
                null
            }
            if (b != null) {
                thumbs.put(key, b)
                runOnUiThread {
                    if (iv.tag == key) {
                        iv.setImageBitmap(b)
                        ph.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun bindThumb(t: ThumbParts, m: Meta) {
        loadThumb(t.iv, t.ph, m)
        t.ph.set(if (m.hasPdf) Ic.FILE else Ic.NOTE, Theme.sub())
        t.badges.removeAllViews()
        val b = noteBadge(m)
        if (b != null) t.badges.addView(b)
        val starred = Prefs.starred(this).contains(m.id)
        t.star.set(Ic.STAR, if (starred) 0xFFFFC53D.toInt() else Theme.sub())
        t.star.filled = starred
        t.star.setOnClickListener {
            it.tick()
            Prefs.toggleStar(this, m.id)
            rebuildRows()
        }
    }

    private fun itemRoot(hPad: Int, vPad: Int): FrameLayout {
        val outer = FrameLayout(this)
        outer.setPadding(dp(hPad), dp(vPad), dp(hPad), dp(vPad))
        outer.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return outer
    }

    private fun buildNoteCard(): Holder {
        val outer = itemRoot(7, 7)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = glass(22f)
        card.setPadding(dp(10), dp(10), dp(10), dp(12))
        val th = makeThumb(true)
        card.addView(th.box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(176)))
        val t = label("", 14.5f, Theme.text(), Fonts.medium)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(2), dp(8), 0, 0)
        val d = label("", 11.5f, Theme.sub())
        d.setPadding(dp(2), 0, 0, 0)
        card.addView(t)
        card.addView(d)
        card.isClickable = true
        card.pressable(0.97f)
        outer.addView(card)
        return Holder(outer) { row ->
            val m = (row as NoteRow).meta
            bindThumb(th, m)
            t.text = m.title
            d.text = metaLine(m)
            card.setOnClickListener { openNote(m.id) }
            card.setOnLongClickListener {
                showItemSheet(m)
                true
            }
        }
    }

    private fun buildNoteRow(): Holder {
        val outer = itemRoot(5, 5)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = glass(20f)
        card.setPadding(dp(10), dp(10), dp(6), dp(10))
        val th = makeThumb(false)
        card.addView(th.box, LinearLayout.LayoutParams(dp(58), dp(78)))
        val txt = LinearLayout(this)
        txt.orientation = LinearLayout.VERTICAL
        txt.setPadding(dp(14), 0, dp(6), 0)
        val t = label("", 15.5f, Theme.text(), Fonts.medium)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val d = label("", 12f, Theme.sub())
        txt.addView(t)
        txt.addView(d)
        card.addView(txt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(th.star, LinearLayout.LayoutParams(dp(46), dp(46)))
        val more = IconView(this, Ic.MORE, Theme.sub(), 0.5f)
        more.isClickable = true
        more.pressable()
        card.addView(more, LinearLayout.LayoutParams(dp(46), dp(46)))
        card.isClickable = true
        card.pressable(0.98f)
        outer.addView(card)
        return Holder(outer) { row ->
            val m = (row as NoteRow).meta
            bindThumb(th, m)
            t.text = m.title
            d.text = metaLine(m)
            card.setOnClickListener { openNote(m.id) }
            card.setOnLongClickListener {
                showItemSheet(m)
                true
            }
            more.setOnClickListener {
                it.tick()
                showItemSheet(m)
            }
        }
    }

    private fun folderTint(): Int = (Theme.accent and 0x00FFFFFF) or 0x26000000

    private fun buildFolderCard(): Holder {
        val outer = itemRoot(7, 7)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = glass(22f)
        card.setPadding(dp(10), dp(10), dp(10), dp(12))
        val box = FrameLayout(this)
        box.background = roundBg(folderTint(), 14)
        box.addView(IconView(this, Ic.FOLDER, Theme.accent, 0.42f), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        card.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(112)))
        val t = label("", 14.5f, Theme.text(), Fonts.medium)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(2), dp(8), 0, 0)
        val d = label("", 11.5f, Theme.sub())
        d.setPadding(dp(2), 0, 0, 0)
        card.addView(t)
        card.addView(d)
        card.isClickable = true
        card.pressable(0.97f)
        outer.addView(card)
        return Holder(outer) { row ->
            val f = (row as FolderRow).folder
            t.text = f.name
            d.text = row.count.toString()
            card.setOnClickListener { openFolder(f.id) }
            card.setOnLongClickListener {
                showFolderSheet(f)
                true
            }
        }
    }

    private fun buildFolderRow(): Holder {
        val outer = itemRoot(5, 5)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = glass(20f)
        card.setPadding(dp(10), dp(10), dp(6), dp(10))
        val box = FrameLayout(this)
        box.background = roundBg(folderTint(), 14)
        box.addView(IconView(this, Ic.FOLDER, Theme.accent, 0.55f), FrameLayout.LayoutParams(dp(58), dp(58)))
        card.addView(box, LinearLayout.LayoutParams(dp(58), dp(58)))
        val txt = LinearLayout(this)
        txt.orientation = LinearLayout.VERTICAL
        txt.setPadding(dp(14), 0, dp(6), 0)
        val t = label("", 15.5f, Theme.text(), Fonts.medium)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val d = label("", 12f, Theme.sub())
        txt.addView(t)
        txt.addView(d)
        card.addView(txt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val more = IconView(this, Ic.MORE, Theme.sub(), 0.5f)
        more.isClickable = true
        more.pressable()
        card.addView(more, LinearLayout.LayoutParams(dp(46), dp(46)))
        card.isClickable = true
        card.pressable(0.98f)
        outer.addView(card)
        return Holder(outer) { row ->
            val f = (row as FolderRow).folder
            t.text = f.name
            d.text = row.count.toString()
            card.setOnClickListener { openFolder(f.id) }
            card.setOnLongClickListener {
                showFolderSheet(f)
                true
            }
            more.setOnClickListener {
                it.tick()
                showFolderSheet(f)
            }
        }
    }

    // ============================ data ============================

    override fun onResume() {
        super.onResume()
        val d = Theme.dark
        Theme.apply(this)
        if (d != Theme.dark) {
            recreate()
            return
        }
        applyViewMode()
        reload()
        if (!dialOpen) startRing()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (dialOpen) closeDial() else if (curFolder != null) goUp() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        ringAnim?.cancel()
        fabRing.alpha = 0f
    }

    private fun goUp() {
        curFolder = Folders.get(this, curFolder)?.parent
        rebuildRows()
    }

    private fun openFolder(id: String) {
        curFolder = id
        if (query.isNotEmpty()) searchEt.setText("")
        rebuildRows()
        rv.scrollToPosition(0)
    }

    private fun reload() {
        val l = Store.list(this)
        allNotes = when (Prefs.intOf(this, "sort", 0)) {
            1 -> l.sortedBy { it.title.lowercase() }
            2 -> l.sortedByDescending { it.pages }
            3 -> l.sortedBy { it.modified }
            4 -> l.sortedByDescending { it.title.lowercase() }
            else -> l
        }
        rebuildRows()
    }

    private fun countIn(folderId: String): Int =
        allNotes.count { it.folder == folderId } + Folders.children(this, folderId).size

    private fun rebuildRows() {
        val flat = query.isNotEmpty() || filter != 0
        val stars = Prefs.starred(this)
        val out = ArrayList<Row>()
        if (!flat) {
            for (f in Folders.children(this, curFolder)) out.add(FolderRow(f, countIn(f.id)))
            for (m in allNotes) if (m.folder == curFolder) out.add(NoteRow(m))
        } else {
            if (filter == 0) {
                for (f in Folders.all(this)) if (f.name.contains(query, true)) out.add(FolderRow(f, countIn(f.id)))
            }
            for (m in allNotes) {
                val ok = when (filter) {
                    1 -> stars.contains(m.id)
                    2 -> !m.hasPdf
                    3 -> m.hasPdf && !m.review
                    4 -> m.review
                    else -> true
                }
                if (ok && (query.isEmpty() || m.title.contains(query, true))) out.add(NoteRow(m))
            }
        }
        rows = out
        adapter.notifyDataSetChanged()

        val inFolder = curFolder != null && !flat
        val fname = Folders.get(this, curFolder)?.name
        titleTv.text = if (inFolder && fname != null) fname else "InkPad"
        backBtn.visibility = if (curFolder != null) View.VISIBLE else View.GONE
        val notes = out.count { it is NoteRow }
        subtitle.text = if (inFolder) "${out.size}" else "$notes notebook${if (notes == 1) "" else "s"}"

        if (out.isEmpty()) {
            emptyBox.visibility = View.VISIBLE
            if (flat) {
                emptyIcon.set(Ic.SEARCH, Color.WHITE)
                emptyTitle.text = "No results"
            } else if (curFolder != null) {
                emptyIcon.set(Ic.FOLDER, Color.WHITE)
                emptyTitle.text = "Empty folder"
            } else {
                emptyIcon.set(Ic.PEN, Color.WHITE)
                emptyTitle.text = "Start your first note"
            }
        } else {
            emptyBox.visibility = View.GONE
        }
    }

    private fun openNote(id: String) {
        val i = Intent(this, EditorActivity::class.java)
        i.putExtra("id", id)
        startActivity(i)
    }

    // ============================ sheets ============================

    private fun showItemSheet(m: Meta) {
        val starred = Prefs.starred(this).contains(m.id)
        chooseSheet(
            m.title,
            listOf("Open", "Rename", "Move", "Duplicate", if (starred) "Unstar" else "Star", "Delete"),
            listOf(Ic.PEN, Ic.EDIT, Ic.FOLDER, Ic.COPY, Ic.STAR, Ic.TRASH)
        ) { i ->
            when (i) {
                0 -> openNote(m.id)
                1 -> rename(m)
                2 -> moveSheet(m)
                3 -> {
                    Store.duplicate(this, m.id)
                    reload()
                }
                4 -> {
                    Prefs.toggleStar(this, m.id)
                    rebuildRows()
                }
                5 -> confirmSheet(m.title, "", "Delete", true) {
                    Store.delete(this, m.id)
                    reload()
                }
            }
        }
    }

    private fun showFolderSheet(f: Folder) {
        chooseSheet(f.name, listOf("Open", "Rename", "Delete"), listOf(Ic.FOLDER, Ic.EDIT, Ic.TRASH)) { i ->
            when (i) {
                0 -> openFolder(f.id)
                1 -> inputSheet("Rename", f.name, "Name") { s ->
                    if (s.isNotEmpty()) {
                        Folders.rename(this, f.id, s)
                        rebuildRows()
                    }
                }
                2 -> confirmSheet(f.name, "", "Delete", true) {
                    Folders.delete(this, f.id)
                    reload()
                }
            }
        }
    }

    private fun moveSheet(m: Meta) {
        val names = ArrayList<String>()
        val ids = ArrayList<String?>()
        val icons = ArrayList<Int>()
        names.add("InkPad")
        ids.add(null)
        icons.add(Ic.PAGES)
        for ((f, depth) in Folders.tree(this)) {
            names.add("      ".repeat(depth) + f.name)
            ids.add(f.id)
            icons.add(Ic.FOLDER)
        }
        chooseSheet("Move", names, icons, ids.indexOf(m.folder)) { i ->
            Store.setFolder(this, m.id, ids[i])
            reload()
        }
    }

    private fun rename(m: Meta) {
        inputSheet("Rename", m.title, "Title") { s ->
            val nb = Store.load(this, m.id)
            if (nb != null && s.isNotEmpty()) {
                nb.title = s
                Store.save(this, nb)
                reload()
            }
        }
    }

    private fun folderMenu() {
        chooseSheet("Folder", listOf("New folder", "From files"), listOf(Ic.FOLDER_PLUS, Ic.FOLDER_IMPORT)) { i ->
            if (i == 0) {
                inputSheet("New folder", "", "Name") { s ->
                    if (s.isNotEmpty()) {
                        Folders.create(this, s, curFolder)
                        reload()
                    }
                }
            } else {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
            }
        }
    }

    // ============================ new notebook ============================

    private val noEnv = object : Env {
        override fun image(name: String): Bitmap? = null
    }

    private fun askNew() {
        val sizes = listOf(
            Pair("A4", floatArrayOf(595f, 842f)),
            Pair("A5", floatArrayOf(420f, 595f)),
            Pair("Letter", floatArrayOf(612f, 792f)),
            Pair("16:9", floatArrayOf(960f, 540f))
        )
        var sizeIdx = 0
        var tplIdx = 0
        var colIdx = 0

        val name = EditText(this)
        name.setText("Untitled")
        name.setSelection(name.text.length)
        name.hint = "Title"
        name.setTextColor(Theme.text())
        name.setHintTextColor(Theme.sub())
        name.background = fieldBg(14f)
        name.setPadding(dp(14), dp(12), dp(14), dp(12))
        name.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f * UiScale.factor(this))
        name.maxLines = 1
        name.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES

        val sh = Sheet(this).title("New")
        sh.view(name)

        val frames = ArrayList<FrameLayout>()
        val images = ArrayList<ImageView>()
        fun renderPreviews() {
            for (i in TEMPLATE_IDS.indices) {
                val tmp = Notebook("tmp", "")
                tmp.pageColor = colIdx
                val pg = Page(sizes[sizeIdx].second[0], sizes[sizeIdx].second[1])
                pg.template = TEMPLATE_IDS[i]
                tmp.pages.add(pg)
                try {
                    images[i].setImageBitmap(Exporter.renderPage(tmp, 0, dp(84), null, noEnv))
                } catch (t: Throwable) {
                }
                val sel = i == tplIdx
                frames[i].background = roundBg(Color.TRANSPARENT, 14, if (sel) Theme.accent else Theme.field(), if (sel) 3 else 1)
            }
        }

        fun sectionLp(): LinearLayout.LayoutParams {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(14)
            lp.bottomMargin = dp(6)
            return lp
        }

        val tsv = android.widget.HorizontalScrollView(this)
        tsv.isHorizontalScrollBarEnabled = false
        val trow = LinearLayout(this)
        trow.orientation = LinearLayout.HORIZONTAL
        for (i in TEMPLATE_IDS.indices) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val fr = FrameLayout(this)
            fr.setPadding(dp(4), dp(4), dp(4), dp(4))
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
            fr.addView(iv, FrameLayout.LayoutParams(dp(84), dp(108)))
            frames.add(fr)
            images.add(iv)
            col.addView(fr)
            val tv = label(TEMPLATE_NAMES[i], 11f, Theme.text(), Fonts.medium)
            tv.gravity = Gravity.CENTER
            col.addView(tv)
            col.isClickable = true
            col.pressable()
            col.setOnClickListener {
                tplIdx = i
                renderPreviews()
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            trow.addView(col, lp)
        }
        tsv.addView(trow)
        sh.view(tsv, sectionLp())

        sh.view(chipRow(sizes.map { it.first }, 0) { i ->
            sizeIdx = i
            renderPreviews()
        }, sectionLp())
        sh.view(chipRow(PAGE_COLOR_NAMES.toList(), 0) { i ->
            colIdx = i
            renderPreviews()
        })
        renderPreviews()

        sh.iconBtn(Ic.CLOSE, false).iconBtn(Ic.CHECK, true) {
            val id = Store.newId()
            val nb = Notebook(id, name.text.toString().trim().ifEmpty { "Untitled" })
            nb.pageColor = colIdx
            nb.folder = curFolder
            val p = Page(sizes[sizeIdx].second[0], sizes[sizeIdx].second[1])
            p.template = TEMPLATE_IDS[tplIdx]
            nb.pages.add(p)
            Store.save(this, nb)
            Exporter.writeThumb(this, nb, null, ImgEnv(Store.dir(this, id)))
            openNote(id)
        }.show()
    }

    // ============================ speed dial ============================

    private fun buildDial() {
        scrim = View(this)
        scrim.setBackgroundColor(if (Theme.dark) 0xB3000000.toInt() else 0x80171A2C.toInt())
        scrim.visibility = View.GONE
        scrim.isClickable = true
        scrim.setOnClickListener { closeDial() }
        root.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        dialScroll = ScrollView(this)
        dialScroll.isVerticalScrollBarEnabled = false
        dialScroll.visibility = View.GONE
        dialScroll.clipToPadding = false
        dialCol = LinearLayout(this)
        dialCol.orientation = LinearLayout.VERTICAL
        dialCol.gravity = Gravity.END
        dialScroll.addView(dialCol, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(
            dialScroll,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
        )

        val defs = listOf(
            DialDef(Ic.FOLDER_IMPORT, "Import folder") { importFolder() },
            DialDef(Ic.FOLDER_PLUS, "New folder") { newFolder() },
            DialDef(Ic.IMAGE, "From images") { pickImages() },
            DialDef(Ic.REVIEW, "Review test") { pickPdf(true) },
            DialDef(Ic.FILE, "Import PDF") { pickPdf(false) },
            DialDef(Ic.BOLT, "Quick note") { quickNote() },
            DialDef(Ic.NOTE, "New note") { askNew() }
        )
        for (d in defs) dialCol.addView(dialItem(d))

        fabRing = View(this)
        val rg = GradientDrawable()
        rg.shape = GradientDrawable.OVAL
        rg.setStroke(dp(3), Theme.accent)
        rg.setColor(Color.TRANSPARENT)
        fabRing.background = rg
        fabRing.alpha = 0f
        root.addView(fabRing, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END))

        fab = FrameLayout(this)
        val fg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Theme.accent, Theme.accent2))
        fg.shape = GradientDrawable.OVAL
        fab.background = fg
        fab.elevation = dpf(12f)
        fabIcon = IconView(this, Ic.PLUS, Color.WHITE, 0.52f)
        fab.addView(fabIcon, FrameLayout.LayoutParams(dp(60), dp(60)))
        fab.isClickable = true
        fab.contentDescription = "Create"
        fab.pressable(0.9f)
        fab.setOnClickListener {
            it.tick()
            if (dialOpen) closeDial() else openDial()
        }
        fab.setOnLongClickListener {
            it.tick()
            quickNote()
            true
        }
        root.addView(fab, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END))
        fab.scaleX = 0f
        fab.scaleY = 0f
        fab.animate().scaleX(1f).scaleY(1f).setStartDelay(250).setDuration(420).setInterpolator(OvershootInterpolator(2f)).start()
    }

    private fun dialItem(d: DialDef): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val tv = label(d.label, 14f, Theme.text(), Fonts.medium)
        tv.background = glass(20f, true)
        tv.setPadding(dp(14), dp(9), dp(14), dp(9))
        tv.elevation = dpf(4f)
        row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val btn = FrameLayout(this)
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Theme.accent, Theme.accent2))
        g.shape = GradientDrawable.OVAL
        btn.background = g
        btn.elevation = dpf(6f)
        btn.addView(IconView(this, d.icon, Color.WHITE, 0.5f), FrameLayout.LayoutParams(dp(48), dp(48)))
        val blp = LinearLayout.LayoutParams(dp(48), dp(48))
        blp.leftMargin = dp(12)
        row.addView(btn, blp)
        row.isClickable = true
        row.contentDescription = d.label
        row.pressable(0.96f)
        row.setOnClickListener {
            it.tick()
            closeDial()
            d.action()
        }
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.bottomMargin = dp(12)
        rlp.gravity = Gravity.END
        row.layoutParams = rlp
        return row
    }

    private fun openDial() {
        if (dialOpen) return
        dialOpen = true
        ringAnim?.cancel()
        fabRing.alpha = 0f
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(200).start()
        dialScroll.visibility = View.VISIBLE
        dialScroll.scrollTo(0, 0)
        fabIcon.animate().rotation(135f).setDuration(280).setInterpolator(OvershootInterpolator(1.3f)).start()
        val n = dialCol.childCount
        for (i in 0 until n) {
            val v = dialCol.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(26).toFloat()
            v.scaleX = 0.85f
            v.scaleY = 0.85f
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(((n - 1 - i) * 38).toLong()).setDuration(240)
                .setInterpolator(OvershootInterpolator(1.1f)).start()
        }
    }

    private fun closeDial() {
        if (!dialOpen) return
        dialOpen = false
        scrim.animate().alpha(0f).setDuration(170).withEndAction { scrim.visibility = View.GONE }.start()
        fabIcon.animate().rotation(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        val n = dialCol.childCount
        for (i in 0 until n) {
            val v = dialCol.getChildAt(i)
            v.animate().alpha(0f).translationY(dp(16).toFloat()).setStartDelay((i * 18).toLong()).setDuration(150).start()
        }
        dialScroll.postDelayed({
            if (!dialOpen) dialScroll.visibility = View.GONE
        }, 300)
        startRing()
    }

    private fun startRing() {
        ringAnim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 2400
        a.repeatCount = ValueAnimator.INFINITE
        a.addUpdateListener { v ->
            val t = v.animatedValue as Float
            fabRing.scaleX = 1f + 0.5f * t
            fabRing.scaleY = 1f + 0.5f * t
            fabRing.alpha = 0.5f * (1f - t)
        }
        ringAnim = a
        a.start()
    }

    private fun newFolder() {
        inputSheet("New folder", "", "Name") { s ->
            if (s.isNotEmpty()) {
                Folders.create(this, s, curFolder)
                reload()
            }
        }
    }

    private fun importFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
    }

    private fun quickNote() {
        val id = Store.newId()
        val stamp = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
        val nb = Notebook(id, "Quick note $stamp")
        nb.folder = curFolder
        nb.pages.add(Page(595f, 842f))
        Store.save(this, nb)
        Exporter.writeThumb(this, nb, null, ImgEnv(Store.dir(this, id)))
        openNote(id)
    }

    private fun pickImages() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, REQ_IMAGES)
    }

    // One page per picture, sized to the picture's shape.
    private fun importImages(list: List<Uri>) {
        toast("Importing…")
        val folder = curFolder
        Thread {
            try {
                val id = Store.newId()
                val d = Store.dir(this, id)
                val nb = Notebook(id, "Images " + DateFormat.getDateInstance(DateFormat.SHORT).format(Date()))
                nb.folder = folder
                var k = 0
                for (u in list) {
                    try {
                        val o1 = BitmapFactory.Options()
                        o1.inJustDecodeBounds = true
                        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o1) }
                        var sample = 1
                        while (max(o1.outWidth, o1.outHeight) / sample > 2000) sample *= 2
                        val o2 = BitmapFactory.Options()
                        o2.inSampleSize = sample
                        val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: continue
                        val name = "img_$k.jpg"
                        File(d, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                        val pw = 595f
                        val ph = max(120f, pw * bmp.height / max(1, bmp.width))
                        val page = Page(pw, ph)
                        val im = ImageItem()
                        im.file = name
                        im.r.set(0f, 0f, pw, ph)
                        page.items.add(im)
                        nb.pages.add(page)
                        k++
                    } catch (t: Throwable) {
                    }
                }
                if (nb.pages.isEmpty()) throw RuntimeException("no images")
                Store.save(this, nb)
                Exporter.writeThumb(this, nb, null, ImgEnv(d))
                runOnUiThread { openNote(id) }
            } catch (t: Throwable) {
                runOnUiThread { toast("Could not import images") }
            }
        }.start()
    }

    // ============================ import ============================

    private fun pickPdf(review: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/pdf"
        startActivityForResult(i, if (review) REQ_REVIEW else REQ_PDF)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == REQ_IMAGES) {
            val list = ArrayList<Uri>()
            val cd = data?.clipData
            if (cd != null) {
                for (k in 0 until cd.itemCount) list.add(cd.getItemAt(k).uri)
            } else {
                val one = data?.data
                if (one != null) list.add(one)
            }
            if (list.isNotEmpty()) importImages(list)
            return
        }
        val uri = data?.data ?: return
        if (requestCode == REQ_PDF) importPdf(uri, false)
        if (requestCode == REQ_REVIEW) importPdf(uri, true)
        if (requestCode == REQ_TREE) importTree(uri)
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) return c.getString(i).removeSuffix(".pdf").removeSuffix(".PDF")
                }
            }
        } catch (t: Throwable) {
        }
        return "Imported PDF"
    }

    // Copies a PDF into a new notebook. Runs on a background thread. Returns the notebook id.
    private fun doImport(uri: Uri, title: String, review: Boolean, folder: String?): String {
        var src: PdfSource? = null
        try {
            val id = Store.newId()
            val d = Store.dir(this, id)
            val f = File(d, "doc.pdf")
            val ins = contentResolver.openInputStream(uri) ?: throw RuntimeException("no stream")
            ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            src = PdfSource(f)
            val nb = Notebook(id, title)
            nb.hasPdf = true
            nb.review = review
            nb.folder = folder
            for (k in 0 until src.count) {
                val sz = src.pageSize(k)
                val p = Page(sz.first, sz.second)
                p.pdfIndex = k
                nb.pages.add(p)
            }
            if (nb.pages.isEmpty()) throw RuntimeException("empty pdf")
            Store.save(this, nb)
            Exporter.writeThumb(this, nb, src, ImgEnv(d))
            return id
        } finally {
            src?.close()
        }
    }

    private fun importPdf(uri: Uri, review: Boolean) {
        toast("Importing…")
        val title = displayName(uri)
        val folder = curFolder
        Thread {
            try {
                val id = doImport(uri, title, review, folder)
                runOnUiThread { openNote(id) }
            } catch (t: Throwable) {
                runOnUiThread { toast("Could not import this PDF") }
            }
        }.start()
    }

    private fun docName(tree: Uri, docId: String): String {
        try {
            val u = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
            contentResolver.query(u, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "Imported"
            }
        } catch (t: Throwable) {
        }
        return "Imported"
    }

    // Imports every PDF inside a folder picked from the file manager (sub-folders are kept as sub-folders).
    private fun importTree(tree: Uri) {
        toast("Importing folder…")
        val parent = curFolder
        Thread {
            var count = 0
            var failed = 0
            try {
                val rootDoc = DocumentsContract.getTreeDocumentId(tree)
                val top = Folders.create(this, docName(tree, rootDoc), parent)

                fun walk(docId: String, folderId: String) {
                    val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
                    val cols = arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE
                    )
                    val list = ArrayList<Triple<String, String, String>>()
                    contentResolver.query(kids, cols, null, null, null)?.use { c ->
                        while (c.moveToNext()) list.add(Triple(c.getString(0) ?: "", c.getString(1) ?: "", c.getString(2) ?: ""))
                    }
                    for ((id, name, mime) in list) {
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            val sub = Folders.create(this, name, folderId)
                            walk(id, sub.id)
                        } else if (mime == "application/pdf" || name.lowercase().endsWith(".pdf")) {
                            try {
                                val u = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                                doImport(u, name.removeSuffix(".pdf").removeSuffix(".PDF"), false, folderId)
                                count++
                                runOnUiThread { subtitle.text = "+$count" }
                            } catch (t: Throwable) {
                                failed++
                            }
                        }
                    }
                }
                walk(rootDoc, top.id)
            } catch (t: Throwable) {
                failed++
            }
            runOnUiThread {
                toast(if (failed > 0) "$count imported, $failed failed" else "$count imported")
                reload()
            }
        }.start()
    }
}
