package com.inkpad.app

import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

const val K_LINE = 0
const val K_ARROW = 1
const val K_RECT = 2
const val K_ELLIPSE = 3
const val K_TRI = 4
const val K_DIAMOND = 5
const val K_STAR = 6
val SHAPE_NAMES = arrayOf("Line", "Arrow", "Rectangle", "Ellipse", "Triangle", "Diamond", "Star")
val TEMPLATE_IDS = arrayOf("blank", "lined", "grid", "dotted", "cornell", "eng", "music", "todo", "weekly")
val TEMPLATE_NAMES = arrayOf("Blank", "Lined", "Grid", "Dotted", "Cornell", "Engineering", "Music", "To-do", "Weekly")
val PAGE_COLOR_NAMES = arrayOf("White", "Cream", "Dark")

interface Env {
    fun image(name: String): Bitmap?
}

fun distSeg(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
    val dx = bx - ax
    val dy = by - ay
    val l2 = dx * dx + dy * dy
    if (l2 < 1e-6f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * dx + (py - ay) * dy) / l2).coerceIn(0f, 1f)
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
}

abstract class Item {
    var color: Int = Color.BLACK
    var width: Float = 3f
    abstract val type: String
    abstract fun bounds(): RectF
    abstract fun applyMatrix(m: Matrix)
    abstract fun hit(x: Float, y: Float, r: Float): Boolean
    abstract fun draw(c: Canvas, env: Env)
    abstract fun copyItem(): Item
    protected open fun writeExtra(o: JSONObject) {}
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("t", type)
        o.put("c", color)
        o.put("w", width.toDouble())
        writeExtra(o)
        return o
    }
}

class Stroke(val hl: Boolean) : Item() {
    override val type: String get() = "s"
    var pts = FloatArray(128)
    var n = 0
    private var cached: Path? = null
    private var pCached: Path? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    var pr: FloatArray? = null

    fun enablePressure() {
        pr = FloatArray(max(16, pts.size))
    }

    fun add(x: Float, y: Float) = addP(x, y, 1f)

    fun addP(x: Float, y: Float, p: Float) {
        if (n * 2 + 2 > pts.size) pts = pts.copyOf(pts.size * 2)
        val a = pr
        if (a != null) {
            val b = if (n >= a.size) a.copyOf(max(16, a.size * 2)) else a
            val pv = p.coerceIn(0.05f, 1f)
            b[n] = if (n > 0) b[n - 1] * 0.6f + pv * 0.4f else pv
            pr = b
        }
        pts[n * 2] = x
        pts[n * 2 + 1] = y
        n++
        cached = null
        pCached = null
    }

    fun path(): Path {
        cached?.let { return it }
        val p = Path()
        if (n > 0) {
            p.moveTo(pts[0], pts[1])
            if (n == 1) {
                p.lineTo(pts[0] + 0.01f, pts[1])
            } else {
                for (i in 1 until n) {
                    val px = pts[(i - 1) * 2]
                    val py = pts[(i - 1) * 2 + 1]
                    val cx = pts[i * 2]
                    val cy = pts[i * 2 + 1]
                    p.quadTo(px, py, (px + cx) / 2f, (py + cy) / 2f)
                }
                p.lineTo(pts[(n - 1) * 2], pts[(n - 1) * 2 + 1])
            }
        }
        cached = p
        return p
    }

    override fun draw(c: Canvas, env: Env) {
        paint.style = Paint.Style.STROKE
        paint.strokeCap = if (hl) Paint.Cap.SQUARE else Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = width
        paint.color = if (hl) ((color and 0x00FFFFFF) or (0x66 shl 24)) else color
        val a = pr
        if (a != null && n > 1 && !hl) {
            paint.style = Paint.Style.FILL
            c.drawPath(pressurePath(a), paint)
            val r0 = width * (0.3f + 0.9f * a[0]) / 2f
            val r1 = width * (0.3f + 0.9f * a[n - 1]) / 2f
            c.drawCircle(pts[0], pts[1], r0, paint)
            c.drawCircle(pts[(n - 1) * 2], pts[(n - 1) * 2 + 1], r1, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width * 0.35f
            c.drawPath(path(), paint)
        } else {
            c.drawPath(path(), paint)
        }
    }

    private fun pressurePath(a: FloatArray): Path {
        val ex = pCached
        if (ex != null) return ex
        val left = FloatArray(n * 2)
        val right = FloatArray(n * 2)
        for (i in 0 until n) {
            val x = pts[i * 2]
            val y = pts[i * 2 + 1]
            val p0 = if (i > 0) i - 1 else i
            val p1 = if (i < n - 1) i + 1 else i
            var dx = pts[p1 * 2] - pts[p0 * 2]
            var dy = pts[p1 * 2 + 1] - pts[p0 * 2 + 1]
            val len = hypot(dx, dy)
            if (len < 1e-4f) {
                dx = 1f
                dy = 0f
            } else {
                dx /= len
                dy /= len
            }
            val hw = width * (0.3f + 0.9f * a[i]) / 2f
            left[i * 2] = x - dy * hw
            left[i * 2 + 1] = y + dx * hw
            right[i * 2] = x + dy * hw
            right[i * 2 + 1] = y - dx * hw
        }
        val path = Path()
        path.moveTo(left[0], left[1])
        for (i in 1 until n) path.lineTo(left[i * 2], left[i * 2 + 1])
        for (i in n - 1 downTo 0) path.lineTo(right[i * 2], right[i * 2 + 1])
        path.close()
        pCached = path
        return path
    }

    override fun bounds(): RectF {
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        for (i in 0 until n) {
            val x = pts[i * 2]
            val y = pts[i * 2 + 1]
            if (x < l) l = x
            if (x > r) r = x
            if (y < t) t = y
            if (y > b) b = y
        }
        if (n == 0) return RectF(0f, 0f, 0f, 0f)
        val h = width / 2f
        return RectF(l - h, t - h, r + h, b + h)
    }

    override fun applyMatrix(m: Matrix) {
        val src = pts.copyOf()
        m.mapPoints(pts, 0, src, 0, n)
        width *= m.mapRadius(1f)
        cached = null
        pCached = null
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean {
        val rr = r + width / 2f
        if (n == 0) return false
        if (n == 1) return hypot(x - pts[0], y - pts[1]) <= rr
        for (i in 1 until n) {
            if (distSeg(x, y, pts[(i - 1) * 2], pts[(i - 1) * 2 + 1], pts[i * 2], pts[i * 2 + 1]) <= rr) return true
        }
        return false
    }

    override fun copyItem(): Item {
        val s = Stroke(hl)
        s.color = color
        s.width = width
        s.pts = pts.copyOf()
        s.n = n
        s.pr = pr?.copyOf()
        return s
    }

    override fun writeExtra(o: JSONObject) {
        o.put("hl", hl)
        val a = JSONArray()
        for (i in 0 until n * 2) a.put(Math.round(pts[i] * 10f) / 10.0)
        o.put("p", a)
        val pa = pr
        if (pa != null) {
            val ja = JSONArray()
            for (i in 0 until n) ja.put(Math.round(pa[i] * 100f) / 100.0)
            o.put("pr", ja)
        }
    }
}

class ShapeItem(var kind: Int) : Item() {
    override val type: String get() = "h"
    var x1 = 0f
    var y1 = 0f
    var x2 = 0f
    var y2 = 0f
    var fill = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun outline(): Path {
        val p = Path()
        val l = min(x1, x2)
        val r = max(x1, x2)
        val t = min(y1, y2)
        val b = max(y1, y2)
        val cx = (l + r) / 2f
        val cy = (t + b) / 2f
        when (kind) {
            K_LINE -> {
                p.moveTo(x1, y1)
                p.lineTo(x2, y2)
            }
            K_ARROW -> {
                p.moveTo(x1, y1)
                p.lineTo(x2, y2)
                val ang = atan2((y2 - y1).toDouble(), (x2 - x1).toDouble())
                val len = 12f + width * 2.5f
                for (s in intArrayOf(-1, 1)) {
                    val a = ang + PI + s * 0.5
                    p.moveTo(x2, y2)
                    p.lineTo(x2 + (len * cos(a)).toFloat(), y2 + (len * sin(a)).toFloat())
                }
            }
            K_RECT -> p.addRect(l, t, r, b, Path.Direction.CW)
            K_ELLIPSE -> p.addOval(RectF(l, t, r, b), Path.Direction.CW)
            K_TRI -> {
                p.moveTo(cx, t)
                p.lineTo(r, b)
                p.lineTo(l, b)
                p.close()
            }
            K_DIAMOND -> {
                p.moveTo(cx, t)
                p.lineTo(r, cy)
                p.lineTo(cx, b)
                p.lineTo(l, cy)
                p.close()
            }
            K_STAR -> {
                val rx = (r - l) / 2f
                val ry = (b - t) / 2f
                for (i in 0 until 10) {
                    val a = -PI / 2 + i * PI / 5
                    val k = if (i % 2 == 0) 1.0 else 0.42
                    val px = cx + (rx * k * cos(a)).toFloat()
                    val py = cy + (ry * k * sin(a)).toFloat()
                    if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
                }
                p.close()
            }
        }
        return p
    }

    override fun draw(c: Canvas, env: Env) {
        if (fill && kind >= K_RECT) {
            paint.style = Paint.Style.FILL
            paint.color = (color and 0x00FFFFFF) or (0x40 shl 24)
            c.drawPath(outline(), paint)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = width
        paint.color = color
        c.drawPath(outline(), paint)
    }

    override fun bounds(): RectF {
        val h = width / 2f + 1f
        return RectF(min(x1, x2) - h, min(y1, y2) - h, max(x1, x2) + h, max(y1, y2) + h)
    }

    override fun applyMatrix(m: Matrix) {
        val a = floatArrayOf(x1, y1, x2, y2)
        m.mapPoints(a)
        x1 = a[0]
        y1 = a[1]
        x2 = a[2]
        y2 = a[3]
        width *= m.mapRadius(1f)
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean {
        val pm = PathMeasure(outline(), false)
        val pos = FloatArray(2)
        val rr = r + width / 2f + 2f
        val step = max(3f, rr / 2f)
        do {
            val len = pm.length
            var d = 0f
            while (d <= len) {
                pm.getPosTan(d, pos, null)
                if (hypot(x - pos[0], y - pos[1]) <= rr) return true
                d += step
            }
        } while (pm.nextContour())
        return false
    }

    override fun copyItem(): Item {
        val s = ShapeItem(kind)
        s.color = color
        s.width = width
        s.x1 = x1
        s.y1 = y1
        s.x2 = x2
        s.y2 = y2
        s.fill = fill
        return s
    }

    override fun writeExtra(o: JSONObject) {
        o.put("k", kind)
        o.put("x1", x1.toDouble())
        o.put("y1", y1.toDouble())
        o.put("x2", x2.toDouble())
        o.put("y2", y2.toDouble())
        o.put("fl", fill)
    }
}

class TextItem : Item() {
    override val type: String get() = "x"
    var text = ""
    var x = 0f
    var y = 0f
    var size = 18f
    var boxW = 240f
    var sticky = false
    var bg: Int = 0xFFFFF59D.toInt()
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lay: StaticLayout? = null
    private var lk = ""

    private fun pad(): Float = if (sticky) 10f else 0f

    fun layout(): StaticLayout {
        tp.textSize = size
        tp.color = if (sticky) Color.BLACK else color
        val key = "$text|$size|$boxW"
        var l = lay
        if (l == null || key != lk) {
            l = StaticLayout.Builder.obtain(text, 0, text.length, tp, max(20, boxW.toInt()))
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()
            lay = l
            lk = key
        }
        return l!!
    }

    override fun bounds(): RectF {
        val p = pad()
        return RectF(x, y, x + boxW + 2 * p, y + layout().height + 2 * p)
    }

    override fun draw(c: Canvas, env: Env) {
        val l = layout()
        val p = pad()
        if (sticky) {
            bgPaint.color = bg
            c.drawRoundRect(bounds(), 6f, 6f, bgPaint)
        }
        c.save()
        c.translate(x + p, y + p)
        l.draw(c)
        c.restore()
    }

    override fun applyMatrix(m: Matrix) {
        val pt = floatArrayOf(x, y)
        m.mapPoints(pt)
        x = pt[0]
        y = pt[1]
        val s = m.mapRadius(1f)
        size *= s
        boxW *= s
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean {
        val b = bounds()
        b.inset(-r, -r)
        return b.contains(x, y)
    }

    override fun copyItem(): Item {
        val t = TextItem()
        t.color = color
        t.width = width
        t.text = text
        t.x = x
        t.y = y
        t.size = size
        t.boxW = boxW
        t.sticky = sticky
        t.bg = bg
        return t
    }

    override fun writeExtra(o: JSONObject) {
        o.put("tx", text)
        o.put("x", x.toDouble())
        o.put("y", y.toDouble())
        o.put("sz", size.toDouble())
        o.put("bw", boxW.toDouble())
        o.put("st", sticky)
        o.put("bg", bg)
    }
}

class ImageItem : Item() {
    override val type: String get() = "i"
    var file = ""
    val r = RectF()
    var alpha = 255
    private val ip = Paint(Paint.FILTER_BITMAP_FLAG)
    private val gp = Paint()

    override fun bounds(): RectF = RectF(r)

    override fun draw(c: Canvas, env: Env) {
        val b = env.image(file)
        if (b != null) {
            ip.alpha = alpha
            c.drawBitmap(b, null, r, ip)
        } else {
            gp.color = 0xFFCCCCCC.toInt()
            c.drawRect(r, gp)
        }
    }

    override fun applyMatrix(m: Matrix) {
        m.mapRect(r)
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean {
        val b = RectF(this.r)
        b.inset(-r, -r)
        return b.contains(x, y)
    }

    override fun copyItem(): Item {
        val i = ImageItem()
        i.color = color
        i.width = width
        i.file = file
        i.r.set(r)
        i.alpha = alpha
        return i
    }

    override fun writeExtra(o: JSONObject) {
        o.put("f", file)
        o.put("l", r.left.toDouble())
        o.put("tp", r.top.toDouble())
        o.put("rt", r.right.toDouble())
        o.put("bt", r.bottom.toDouble())
        o.put("al", alpha)
    }
}

class TapeItem : Item() {
    override val type: String get() = "p"
    val r = RectF()
    var hidden = true
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun bounds(): RectF = RectF(r)

    override fun draw(c: Canvas, env: Env) {
        paint.style = Paint.Style.FILL
        paint.color = if (hidden) (color or (0xFF shl 24)) else ((color and 0x00FFFFFF) or (0x44 shl 24))
        c.drawRect(r, paint)
        if (!hidden) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.2f
            paint.color = color or (0xFF shl 24)
            c.drawRect(r, paint)
        }
    }

    override fun applyMatrix(m: Matrix) {
        m.mapRect(r)
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean {
        val b = RectF(this.r)
        b.inset(-r, -r)
        return b.contains(x, y)
    }

    override fun copyItem(): Item {
        val t = TapeItem()
        t.color = color
        t.width = width
        t.r.set(r)
        t.hidden = hidden
        return t
    }

    override fun writeExtra(o: JSONObject) {
        o.put("l", r.left.toDouble())
        o.put("tp", r.top.toDouble())
        o.put("rt", r.right.toDouble())
        o.put("bt", r.bottom.toDouble())
        o.put("hd", hidden)
    }
}

class TableItem : Item() {
    override val type: String get() = "b"
    val r = RectF()
    var rows = 3
    var cols = 3
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun bounds(): RectF = RectF(r)

    override fun draw(c: Canvas, env: Env) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = color
        c.drawRect(r, paint)
        for (i in 1 until rows) {
            val y = r.top + r.height() * i / rows
            c.drawLine(r.left, y, r.right, y, paint)
        }
        for (j in 1 until cols) {
            val x = r.left + r.width() * j / cols
            c.drawLine(x, r.top, x, r.bottom, paint)
        }
    }

    override fun applyMatrix(m: Matrix) {
        m.mapRect(r)
        width *= m.mapRadius(1f)
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean {
        val b = RectF(this.r)
        b.inset(-r, -r)
        return b.contains(x, y)
    }

    override fun copyItem(): Item {
        val t = TableItem()
        t.color = color
        t.width = width
        t.r.set(r)
        t.rows = rows
        t.cols = cols
        return t
    }

    override fun writeExtra(o: JSONObject) {
        o.put("l", r.left.toDouble())
        o.put("tp", r.top.toDouble())
        o.put("rt", r.right.toDouble())
        o.put("bt", r.bottom.toDouble())
        o.put("rows", rows)
        o.put("cols", cols)
    }
}

class MarkItem : Item() {
    override val type: String get() = "m"
    var value = 1
    var x = 0f
    var y = 0f
    var r = 20f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun bounds(): RectF = RectF(x - r, y - r, x + r, y + r)

    override fun draw(c: Canvas, env: Env) {
        bg.style = Paint.Style.FILL
        bg.color = Review.tone(value)
        c.drawCircle(x, y, r, bg)
        bg.style = Paint.Style.STROKE
        bg.strokeWidth = max(1.5f, r * 0.1f)
        bg.color = Color.WHITE
        c.drawCircle(x, y, r, bg)
        val s = if (value > 0) "+$value" else value.toString()
        tp.color = Color.WHITE
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = r * (if (s.length >= 3) 0.75f else 0.95f)
        val fm = tp.fontMetrics
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, tp)
    }

    override fun applyMatrix(m: Matrix) {
        val pt = floatArrayOf(x, y)
        m.mapPoints(pt)
        x = pt[0]
        y = pt[1]
        r *= m.mapRadius(1f)
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean = hypot(x - this.x, y - this.y) <= this.r + r

    override fun copyItem(): Item {
        val m = MarkItem()
        m.color = color
        m.width = width
        m.value = value
        m.x = x
        m.y = y
        m.r = r
        return m
    }

    override fun writeExtra(o: JSONObject) {
        o.put("v", value)
        o.put("x", x.toDouble())
        o.put("y", y.toDouble())
        o.put("r", r.toDouble())
    }
}

class DividerItem : Item() {
    override val type: String get() = "d"
    var name = ""
    var y = 0f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tab = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        color = Theme.accent
    }

    override fun bounds(): RectF = RectF(0f, y - 16f, 170f, y + 16f)

    override fun draw(c: Canvas, env: Env) {
        line.style = Paint.Style.STROKE
        line.strokeWidth = 2.4f
        line.color = (color and 0x00FFFFFF) or (0xCC shl 24)
        line.pathEffect = DashPathEffect(floatArrayOf(10f, 7f), 0f)
        c.drawLine(-100f, y, 5000f, y, line)
        tp.textSize = 19f
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.color = Color.WHITE
        val tw = tp.measureText(name)
        tab.style = Paint.Style.FILL
        tab.color = color or (0xFF shl 24)
        c.drawRoundRect(RectF(0f, y - 15f, tw + 28f, y + 15f), 15f, 15f, tab)
        val fm = tp.fontMetrics
        c.drawText(name, 14f, y - (fm.ascent + fm.descent) / 2f, tp)
    }

    override fun applyMatrix(m: Matrix) {
        val pt = floatArrayOf(0f, y)
        m.mapPoints(pt)
        y = pt[1]
    }

    override fun hit(x: Float, y: Float, r: Float): Boolean = abs(y - this.y) <= 14f + r

    override fun copyItem(): Item {
        val d = DividerItem()
        d.color = color
        d.width = width
        d.name = name
        d.y = y
        return d
    }

    override fun writeExtra(o: JSONObject) {
        o.put("nm", name)
        o.put("y", y.toDouble())
    }
}

fun itemFromJson(o: JSONObject): Item? {
    val item: Item = when (o.optString("t")) {
        "s" -> {
            val s = Stroke(o.optBoolean("hl"))
            val a = o.getJSONArray("p")
            val pa = o.optJSONArray("pr")
            if (pa != null) s.enablePressure()
            for (i in 0 until a.length() / 2) {
                val pv = if (pa != null && i < pa.length()) pa.getDouble(i).toFloat() else 1f
                s.addP(a.getDouble(i * 2).toFloat(), a.getDouble(i * 2 + 1).toFloat(), pv)
            }
            s
        }
        "h" -> {
            val s = ShapeItem(o.optInt("k"))
            s.x1 = o.optDouble("x1").toFloat()
            s.y1 = o.optDouble("y1").toFloat()
            s.x2 = o.optDouble("x2").toFloat()
            s.y2 = o.optDouble("y2").toFloat()
            s.fill = o.optBoolean("fl")
            s
        }
        "x" -> {
            val t = TextItem()
            t.text = o.optString("tx")
            t.x = o.optDouble("x").toFloat()
            t.y = o.optDouble("y").toFloat()
            t.size = o.optDouble("sz", 18.0).toFloat()
            t.boxW = o.optDouble("bw", 240.0).toFloat()
            t.sticky = o.optBoolean("st")
            t.bg = o.optInt("bg", 0xFFFFF59D.toInt())
            t
        }
        "i" -> {
            val i = ImageItem()
            i.file = o.optString("f")
            i.r.set(
                o.optDouble("l").toFloat(), o.optDouble("tp").toFloat(),
                o.optDouble("rt").toFloat(), o.optDouble("bt").toFloat()
            )
            i.alpha = o.optInt("al", 255)
            i
        }
        "p" -> {
            val t = TapeItem()
            t.r.set(
                o.optDouble("l").toFloat(), o.optDouble("tp").toFloat(),
                o.optDouble("rt").toFloat(), o.optDouble("bt").toFloat()
            )
            t.hidden = o.optBoolean("hd", true)
            t
        }
        "b" -> {
            val t = TableItem()
            t.r.set(
                o.optDouble("l").toFloat(), o.optDouble("tp").toFloat(),
                o.optDouble("rt").toFloat(), o.optDouble("bt").toFloat()
            )
            t.rows = o.optInt("rows", 3)
            t.cols = o.optInt("cols", 3)
            t
        }
        "m" -> {
            val m = MarkItem()
            m.value = o.optInt("v")
            m.x = o.optDouble("x").toFloat()
            m.y = o.optDouble("y").toFloat()
            m.r = o.optDouble("r", 20.0).toFloat()
            m
        }
        "d" -> {
            val d = DividerItem()
            d.name = o.optString("nm")
            d.y = o.optDouble("y").toFloat()
            d
        }
        else -> return null
    }
    item.color = o.optInt("c", Color.BLACK)
    item.width = o.optDouble("w", 3.0).toFloat()
    return item
}

class Page(var w: Float, var h: Float) {
    var template = "blank"
    var pdfIndex = -1
    val items = ArrayList<Item>()
}

class Notebook(val id: String, var title: String) {
    var pageColor = 0
    var invertPdf = false
    var hasPdf = false
    var review = false
    var folder: String? = null
    var modified = System.currentTimeMillis()
    val pages = ArrayList<Page>()
    val recordings = ArrayList<String>()
}

interface Cmd {
    fun undo()
    fun redo()
}

class AddCmd(private val page: Page, private val items: List<Item>) : Cmd {
    override fun undo() {
        page.items.removeAll(items.toSet())
    }

    override fun redo() {
        page.items.addAll(items)
    }
}

class RemoveCmd(private val page: Page, private val removed: List<Pair<Int, Item>>) : Cmd {
    override fun undo() {
        for (pr in removed.sortedBy { it.first }) {
            page.items.add(min(pr.first, page.items.size), pr.second)
        }
    }

    override fun redo() {
        page.items.removeAll(removed.map { it.second }.toSet())
    }
}

class MatrixCmd(private val items: List<Item>, private val m: Matrix) : Cmd {
    override fun undo() {
        val inv = Matrix()
        m.invert(inv)
        for (i in items) i.applyMatrix(inv)
    }

    override fun redo() {
        for (i in items) i.applyMatrix(m)
    }
}

class ColorCmd(private val items: List<Item>, private val old: List<Int>, private val new: Int) : Cmd {
    override fun undo() {
        for ((k, i) in items.withIndex()) i.color = old[k]
    }

    override fun redo() {
        for (i in items) i.color = new
    }
}

class TextEditCmd(private val item: TextItem, private val old: String, private val new: String) : Cmd {
    override fun undo() {
        item.text = old
    }

    override fun redo() {
        item.text = new
    }
}

class GroupCmd(private val cmds: List<Cmd>) : Cmd {
    override fun undo() {
        for (c in cmds.reversed()) c.undo()
    }

    override fun redo() {
        for (c in cmds) c.redo()
    }
}

class NameEditCmd(private val item: DividerItem, private val old: String, private val new: String) : Cmd {
    private val oldColor = item.color

    override fun undo() {
        item.name = old
        item.color = oldColor
    }

    override fun redo() {
        item.name = new
        item.color = Review.colorFor(new)
    }
}
