package com.inkpad.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.util.LruCache
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import java.util.concurrent.Executors
import kotlin.math.*

class NoteView(ctx: Context, val nb: Notebook, private val pdf: PdfSource?, val env: Env) : View(ctx) {

    companion object {
        const val HAND = 0
        const val PEN = 1
        const val HL = 2
        const val ERASER = 3
        const val LASSO = 4
        const val SHAPE = 5
        const val TEXT = 6
        const val STICKY = 7
        const val TABLE = 8
        const val TAPE = 9
        const val LASER = 10
        const val RULER = 11
        const val MARK = 12
        const val SECTION = 13
        var clip: List<Item> = emptyList()
    }

    // ---- public settings ----
    var tool = PEN
        private set
    var penColor = Color.BLACK
    var hlColor = 0xFFFFEB3B.toInt()
    var penW = 3f
    var hlW = 16f
    var eraserW = 12f
    var textSize = 18f
    var shapeKind = K_RECT
    var fingerDraw = true
    var pressure = true
    var shapeFill = false
    var currentMark = 1
    var surround = 0xFF8A8F98.toInt()

    var onChanged: (() -> Unit)? = null
    var onSelection: ((Boolean) -> Unit)? = null
    var onPage: ((Int) -> Unit)? = null
    var onToolChanged: (() -> Unit)? = null
    var onText: ((TextItem?, Page, Float, Float, Boolean) -> Unit)? = null
    var onTable: ((Page, RectF) -> Unit)? = null
    var onInteract: ((Boolean) -> Unit)? = null
    var onGesture: ((String) -> Unit)? = null
    var onSection: ((Page, Float) -> Unit)? = null
    var onDividerTap: ((DividerItem, Page) -> Unit)? = null

    // ---- layout / transform ----
    private val gap = 24f
    private var tops = FloatArray(0)
    private var worldW = 1f
    private var worldH = 1f
    private var scale = 0f
    private var fit = 1f
    private var tx = 0f
    private var ty = 0f

    // ---- pdf cache ----
    private class Ent(val bmp: Bitmap, val w: Int)

    private val pdfCache = object : LruCache<Int, Ent>(max(16 * 1024 * 1024, (Runtime.getRuntime().maxMemory() / 5).toInt())) {
        override fun sizeOf(key: Int, value: Ent): Int = value.bmp.byteCount
    }
    private val pending = HashSet<Long>()
    private val exec = Executors.newSingleThreadExecutor()
    private var zooming = false
    private var insetTop = 0f
    private var insetBottom = 0f
    private var insetInit = false
    private var secStartY = 0f
    private var secY = -1f
    private var twoStart = 0L
    private var twoMoved = 0f
    private var lastTapT = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f

    // ---- gesture state ----
    private var mode = 0 // 0 none, 1 pan, 2 zoom, 3 tool, 4 ignore
    private var lastX = 0f
    private var lastY = 0f
    private var lastDist = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var activePage = -1

    private var curStroke: Stroke? = null
    private var snapped: ShapeItem? = null
    private var curShape: ShapeItem? = null
    private var curRect: RectF? = null
    private var lassoPath: Path? = null
    private var lassoMoved = false
    private var holdX = 0f
    private var holdY = 0f
    private val holdRun = Runnable { snapStroke() }

    private var selection = ArrayList<Item>()
    private var selPage = -1
    private var selMode = 0 // 1 move, 2 scale
    private var lastLx = 0f
    private var lastLy = 0f
    private var accDx = 0f
    private var accDy = 0f
    private var scaleStart = RectF()
    private var scaleF = 1f

    private var erased = ArrayList<Pair<Int, Item>>()
    private var eraserTouch: PointF? = null

    private class LPt(val x: Float, val y: Float, val t: Long)

    private val laser = ArrayList<LPt>()
    private var laserDown = false

    private val undoStack = ArrayList<Cmd>()
    private val redoStack = ArrayList<Cmd>()
    private var lastReportedPage = -1

    private val ovPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint()

    init {
        shadow.color = 0x33000000
        relayout()
    }

    // ======================= layout =======================

    fun relayout() {
        val n = nb.pages.size
        tops = FloatArray(n)
        var y = gap
        var mw = 0f
        for (i in 0 until n) {
            tops[i] = y
            y += nb.pages[i].h + gap
            mw = max(mw, nb.pages[i].w)
        }
        worldW = mw + 2 * gap
        worldH = y
        if (width > 0) {
            fit = width / worldW
            if (scale == 0f) scale = fit
        }
        clampPan()
        invalidate()
    }

    private fun pageX(p: Page): Float = (worldW - p.w) / 2f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val oldFit = fit
        fit = w / worldW
        if (scale == 0f) {
            scale = fit
            tx = 0f
            ty = insetTop + 16f
        } else if (oldFit > 0f) {
            scale *= fit / oldFit
        }
        clampPan()
    }

    private fun clampPan() {
        if (width == 0) return
        val cw = worldW * scale
        val ch = worldH * scale
        tx = if (cw <= width) (width - cw) / 2f else tx.coerceIn(width - cw - 40f, 40f)
        val hi = insetTop + 16f
        val lo = min(height - ch - insetBottom - 16f, hi)
        ty = ty.coerceIn(lo, hi)
    }

    private fun zoomAt(fx: Float, fy: Float, f: Float) {
        val ns = (scale * f).coerceIn(fit * 0.4f, fit * 10f)
        val r = ns / scale
        tx = fx - (fx - tx) * r
        ty = fy - (fy - ty) * r
        scale = ns
        clampPan()
    }

    fun currentPage(): Int {
        if (nb.pages.isEmpty() || scale == 0f) return 0
        val wy = (insetTop + (height - insetTop - insetBottom) * 0.4f - ty) / scale
        var best = 0
        for (i in nb.pages.indices) if (tops[i] - gap / 2f <= wy) best = i
        return best
    }

    fun goTo(i: Int) {
        if (i !in nb.pages.indices) return
        ty = -(tops[i] - gap / 2f) * scale + insetTop
        clampPan()
        invalidate()
    }

    private fun pageIndexAt(wy: Float): Int {
        for (i in nb.pages.indices) {
            if (wy >= tops[i] - gap / 2f && wy <= tops[i] + nb.pages[i].h + gap / 2f) return i
        }
        return -1
    }

    private fun lx(sx: Float, p: Page): Float = (sx - tx) / scale - pageX(p)
    private fun ly(sy: Float, i: Int): Float = (sy - ty) / scale - tops[i]

    // ======================= pdf bitmaps =======================

    private fun pdfBitmap(p: Page): Bitmap? {
        if (pdf == null) return null
        val needF = (p.w * scale).coerceIn(300f, 1800f)
        val need = (ceil(needF / 200f) * 200f).toInt()
        val e = pdfCache.get(p.pdfIndex)
        if ((e == null || e.w < need) && !zooming) request(p.pdfIndex, need, p)
        return e?.bmp
    }

    private fun request(idx: Int, wPx: Int, p: Page) {
        val key = idx * 100000L + wPx
        if (!pending.add(key)) return
        val hPx = max(1, (wPx * p.h / p.w).toInt())
        try {
            exec.execute {
                val bmp = try {
                    pdf?.render(idx, wPx, hPx)
                } catch (t: Throwable) {
                    null
                }
                post {
                    pending.remove(key)
                    if (bmp != null) {
                        pdfCache.put(idx, Ent(bmp, wPx))
                        invalidate()
                    }
                }
            }
        } catch (t: Throwable) {
            pending.remove(key)
        }
    }

    fun release() {
        exec.shutdownNow()
        pdfCache.evictAll()
    }

    // ======================= drawing =======================

    override fun onDraw(c: Canvas) {
        c.drawColor(surround)
        if (scale == 0f) return
        c.save()
        c.translate(tx, ty)
        c.scale(scale, scale)
        val top = -ty / scale
        val bottom = (height - ty) / scale
        for (i in nb.pages.indices) {
            val p = nb.pages[i]
            val py = tops[i]
            if (py + p.h < top || py > bottom) continue
            val px = pageX(p)
            c.save()
            c.translate(px, py)
            c.drawRect(3f, 3f, p.w + 3f, p.h + 3f, shadow)
            c.clipRect(0f, 0f, p.w, p.h)
            val bmp = if (p.pdfIndex >= 0) pdfBitmap(p) else null
            Draw.content(c, nb, p, bmp, env)
            drawOverlays(c, i)
            c.restore()
        }
        c.restore()
        drawScreenOverlays(c)
        val cp = currentPage()
        if (cp != lastReportedPage) {
            lastReportedPage = cp
            post { onPage?.invoke(cp) }
        }
    }

    private fun dash(on: Float): DashPathEffect = DashPathEffect(floatArrayOf(on / scale, on / scale), 0f)

    private fun drawOverlays(c: Canvas, i: Int) {
        if (i == activePage) {
            if (snapped != null) {
                snapped!!.draw(c, env)
            } else {
                curStroke?.draw(c, env)
            }
            curShape?.draw(c, env)
            val r = curRect
            if (r != null) {
                ovPaint.style = Paint.Style.STROKE
                ovPaint.strokeWidth = 1.5f / scale
                ovPaint.color = Theme.accent
                ovPaint.pathEffect = dash(8f)
                c.drawRect(r, ovPaint)
                ovPaint.pathEffect = null
            }
            val lp = lassoPath
            if (lp != null) {
                ovPaint.style = Paint.Style.STROKE
                ovPaint.strokeWidth = 1.5f / scale
                ovPaint.color = Theme.accent
                ovPaint.pathEffect = dash(6f)
                c.drawPath(lp, ovPaint)
                ovPaint.pathEffect = null
            }
        }
        if (i == activePage && secY >= 0f) {
            ovPaint.style = Paint.Style.STROKE
            ovPaint.strokeWidth = 2.2f / scale
            ovPaint.color = Theme.accent
            ovPaint.pathEffect = dash(8f)
            c.drawLine(0f, secY, nb.pages[i].w, secY, ovPaint)
            ovPaint.pathEffect = null
        }
        if (i == selPage && selection.isNotEmpty()) {
            val b = selBounds() ?: return
            val pad = 4f / scale
            b.inset(-pad, -pad)
            ovPaint.style = Paint.Style.STROKE
            ovPaint.strokeWidth = 1.5f / scale
            ovPaint.color = Theme.accent
            ovPaint.pathEffect = dash(6f)
            c.drawRect(b, ovPaint)
            ovPaint.pathEffect = null
            ovPaint.style = Paint.Style.FILL
            ovPaint.color = Color.WHITE
            c.drawCircle(b.right, b.bottom, 9f / scale, ovPaint)
            ovPaint.style = Paint.Style.STROKE
            ovPaint.color = Theme.accent
            c.drawCircle(b.right, b.bottom, 9f / scale, ovPaint)
        }
    }

    private fun drawScreenOverlays(c: Canvas) {
        val et = eraserTouch
        if (tool == ERASER && et != null) {
            ovPaint.style = Paint.Style.STROKE
            ovPaint.strokeWidth = 2f
            ovPaint.color = Theme.accent
            c.drawCircle(et.x, et.y, max(4f, eraserW * scale), ovPaint)
        }
        if (laser.isNotEmpty()) {
            val now = SystemClock.uptimeMillis()
            while (laser.isNotEmpty() && !laserDown && now - laser[0].t > 700) laser.removeAt(0)
            while (laser.size > 1 && now - laser[0].t > 700) laser.removeAt(0)
            if (laser.isNotEmpty()) {
                ovPaint.style = Paint.Style.STROKE
                ovPaint.strokeCap = Paint.Cap.ROUND
                ovPaint.strokeWidth = 7f
                for (k in 1 until laser.size) {
                    val a = (255 * (1f - (now - laser[k].t) / 700f)).toInt().coerceIn(0, 255)
                    ovPaint.color = Color.argb(a, 255, 40, 40)
                    c.drawLine(laser[k - 1].x, laser[k - 1].y, laser[k].x, laser[k].y, ovPaint)
                }
                val last = laser[laser.size - 1]
                ovPaint.style = Paint.Style.FILL
                ovPaint.color = Color.argb(90, 255, 40, 40)
                c.drawCircle(last.x, last.y, 18f, ovPaint)
                ovPaint.color = Color.argb(255, 255, 20, 20)
                c.drawCircle(last.x, last.y, 9f, ovPaint)
                ovPaint.strokeCap = Paint.Cap.BUTT
                postInvalidateOnAnimation()
            }
        }
    }

    // ======================= tools & settings =======================

    fun selectTool(t: Int) {
        cancelGesture()
        tool = t
        clearSelection()
        invalidate()
        onToolChanged?.invoke()
    }

    fun toolColor(): Int = if (tool == HL) hlColor else penColor

    fun toolWidth(): Float = if (tool == HL) hlW else penW

    // ======================= undo / redo =======================

    private fun push(cmd: Cmd) {
        undoStack.add(cmd)
        redoStack.clear()
        if (undoStack.size > 300) undoStack.removeAt(0)
    }

    private fun changed() {
        invalidate()
        onChanged?.invoke()
    }

    fun canUndo() = undoStack.isNotEmpty()
    fun canRedo() = redoStack.isNotEmpty()

    fun undo() {
        if (undoStack.isEmpty()) return
        val c = undoStack.removeAt(undoStack.size - 1)
        c.undo()
        redoStack.add(c)
        clearSelection()
        changed()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val c = redoStack.removeAt(redoStack.size - 1)
        c.redo()
        undoStack.add(c)
        clearSelection()
        changed()
    }

    private fun commitAdd(pg: Page, item: Item) {
        pg.items.add(item)
        push(AddCmd(pg, listOf(item)))
        changed()
    }

    // ======================= touch =======================

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val r = handleTouch(e)
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN) onInteract?.invoke(true)
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) onInteract?.invoke(false)
        return r
    }

    private fun handleTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                removeCallbacks(holdRun)
                downX = e.x
                downY = e.y
                lastX = e.x
                lastY = e.y
                moved = false
                val finger = e.getToolType(0) == MotionEvent.TOOL_TYPE_FINGER
                if (tool == HAND || tool == MARK || (finger && !fingerDraw && tool != LASER)) {
                    mode = 1
                } else {
                    mode = 3
                    toolDown(e)
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (mode == 3) cancelGesture()
                if (e.pointerCount >= 2) {
                    mode = 2
                    zooming = true
                    if (e.pointerCount == 2) {
                        twoStart = e.eventTime
                        twoMoved = 0f
                    }
                    lastX = (e.getX(0) + e.getX(1)) / 2f
                    lastY = (e.getY(0) + e.getY(1)) / 2f
                    lastDist = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                }
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    1 -> {
                        tx += e.x - lastX
                        ty += e.y - lastY
                        lastX = e.x
                        lastY = e.y
                        if (hypot(e.x - downX, e.y - downY) > 12f) moved = true
                        clampPan()
                        invalidate()
                    }
                    2 -> {
                        if (e.pointerCount >= 2) {
                            val cx = (e.getX(0) + e.getX(1)) / 2f
                            val cy = (e.getY(0) + e.getY(1)) / 2f
                            val d = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                            twoMoved += hypot(cx - lastX, cy - lastY) + abs(d - lastDist)
                            if (lastDist > 8f && d > 8f) zoomAt(lastX, lastY, d / lastDist)
                            tx += cx - lastX
                            ty += cy - lastY
                            lastX = cx
                            lastY = cy
                            lastDist = d
                            clampPan()
                            invalidate()
                        }
                    }
                    3 -> {
                        if (hypot(e.x - downX, e.y - downY) > 10f) moved = true
                        toolMove(e)
                    }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == 2) {
                    val quick = e.pointerCount == 2 && e.eventTime - twoStart < 300 && twoMoved < 28f
                    mode = 4
                    zooming = false
                    if (quick && canUndo()) {
                        undo()
                        onGesture?.invoke("undo")
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                when (mode) {
                    3 -> toolUp(e)
                    1 -> if (!moved) tapAt(e.x, e.y)
                }
                mode = 0
                zooming = false
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                if (mode == 3) cancelGesture()
                mode = 0
                zooming = false
                invalidate()
            }
        }
        return true
    }

    private fun toolDown(e: MotionEvent) {
        val wy = (e.y - ty) / scale
        if (tool == LASER) {
            laserDown = true
            laser.add(LPt(e.x, e.y, SystemClock.uptimeMillis()))
            invalidate()
            return
        }
        val pi = pageIndexAt(wy)
        if (pi < 0) {
            mode = 4
            return
        }
        activePage = pi
        val pg = nb.pages[pi]
        val x = lx(e.x, pg)
        val y = ly(e.y, pi)
        when (tool) {
            PEN, HL -> {
                val s = Stroke(tool == HL)
                s.color = toolColor()
                s.width = toolWidth()
                if (pressure && tool == PEN && e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) s.enablePressure()
                s.addP(x, y, e.pressure)
                curStroke = s
                snapped = null
                holdX = e.x
                holdY = e.y
                postDelayed(holdRun, 550)
            }
            RULER -> {
                val sh = ShapeItem(K_LINE)
                sh.color = penColor
                sh.width = penW
                sh.x1 = x
                sh.y1 = y
                sh.x2 = x
                sh.y2 = y
                curShape = sh
            }
            SHAPE -> {
                val sh = ShapeItem(shapeKind)
                sh.color = penColor
                sh.width = penW
                sh.fill = shapeFill
                sh.x1 = x
                sh.y1 = y
                sh.x2 = x
                sh.y2 = y
                curShape = sh
            }
            ERASER -> {
                erased = ArrayList()
                eraserTouch = PointF(e.x, e.y)
                eraseAt(x, y)
            }
            LASSO -> lassoDown(x, y, pi)
            SECTION -> {
                secStartY = y
                secY = y
            }
            TABLE, TAPE -> curRect = RectF(x, y, x, y)
            else -> {
            }
        }
        invalidate()
    }

    private fun toolMove(e: MotionEvent) {
        if (tool == LASER) {
            laser.add(LPt(e.x, e.y, SystemClock.uptimeMillis()))
            invalidate()
            return
        }
        if (activePage !in nb.pages.indices) return
        val pg = nb.pages[activePage]
        val x = lx(e.x, pg)
        val y = ly(e.y, activePage)
        when (tool) {
            PEN, HL -> {
                val sn = snapped
                if (sn != null) {
                    if (sn.kind == K_LINE) {
                        sn.x2 = x
                        sn.y2 = y
                    }
                } else {
                    val s = curStroke ?: return
                    for (h in 0 until e.historySize) addPt(s, e.getHistoricalX(h), e.getHistoricalY(h), e.getHistoricalPressure(h))
                    addPt(s, e.x, e.y, e.pressure)
                    if (hypot(e.x - holdX, e.y - holdY) > 6f) {
                        holdX = e.x
                        holdY = e.y
                        removeCallbacks(holdRun)
                        postDelayed(holdRun, 550)
                    }
                }
            }
            RULER -> {
                val sh = curShape ?: return
                var ex = x
                var ey = y
                val dx = x - sh.x1
                val dy = y - sh.y1
                val len = hypot(dx, dy)
                if (len > 4f) {
                    val ang = atan2(dy.toDouble(), dx.toDouble())
                    val step = PI / 12.0
                    val snap = Math.round(ang / step) * step
                    if (abs(ang - snap) < 0.06) {
                        ex = sh.x1 + (len * cos(snap)).toFloat()
                        ey = sh.y1 + (len * sin(snap)).toFloat()
                    }
                }
                sh.x2 = ex
                sh.y2 = ey
            }
            SHAPE -> {
                val sh = curShape ?: return
                sh.x2 = x
                sh.y2 = y
            }
            ERASER -> {
                eraserTouch = PointF(e.x, e.y)
                for (h in 0 until e.historySize) eraseAt(lx(e.getHistoricalX(h), pg), ly(e.getHistoricalY(h), activePage))
                eraseAt(x, y)
            }
            LASSO -> lassoMove(x, y)
            SECTION -> secY = y
            TABLE, TAPE -> {
                val r = curRect ?: return
                r.right = x
                r.bottom = y
            }
        }
        invalidate()
    }

    private fun toolUp(e: MotionEvent) {
        removeCallbacks(holdRun)
        if (tool == LASER) {
            laserDown = false
            invalidate()
            return
        }
        if (activePage !in nb.pages.indices) {
            cancelGesture()
            return
        }
        val pg = nb.pages[activePage]
        val x = lx(e.x, pg)
        val y = ly(e.y, activePage)
        when (tool) {
            PEN, HL -> {
                val item: Item? = snapped ?: curStroke
                if (item != null) commitAdd(pg, item)
            }
            RULER, SHAPE -> {
                val sh = curShape
                if (sh != null && hypot(sh.x2 - sh.x1, sh.y2 - sh.y1) > 3f) commitAdd(pg, sh)
            }
            ERASER -> {
                if (erased.isNotEmpty()) {
                    push(RemoveCmd(pg, ArrayList(erased)))
                    changed()
                }
                erased = ArrayList()
                eraserTouch = null
            }
            LASSO -> lassoUp(pg, x, y)
            SECTION -> {
                val yy = if (moved) ((secStartY + y) / 2f).coerceIn(0f, pg.h) else y
                secY = -1f
                sectionAt(pg, yy)
            }
            TEXT, STICKY -> {
                if (!moved) requestText(pg, x, y)
            }
            TABLE -> {
                val r = curRect
                if (r != null) {
                    val n = RectF(min(r.left, r.right), min(r.top, r.bottom), max(r.left, r.right), max(r.top, r.bottom))
                    if (n.width() > 24f && n.height() > 24f) onTable?.invoke(pg, n)
                }
            }
            TAPE -> {
                val r = curRect
                if (r != null) {
                    val n = RectF(min(r.left, r.right), min(r.top, r.bottom), max(r.left, r.right), max(r.top, r.bottom))
                    if (n.width() > 12f && n.height() > 8f) {
                        val t = TapeItem()
                        t.color = penColor
                        t.r.set(n)
                        commitAdd(pg, t)
                    } else {
                        toggleTapeAt(pg, x, y)
                    }
                }
            }
        }
        curStroke = null
        snapped = null
        curShape = null
        curRect = null
        lassoPath = null
        activePage = if (selection.isNotEmpty()) selPage else -1
        invalidate()
    }

    private fun cancelGesture() {
        removeCallbacks(holdRun)
        if (erased.isNotEmpty() && activePage in nb.pages.indices) {
            push(RemoveCmd(nb.pages[activePage], ArrayList(erased)))
            changed()
        }
        erased = ArrayList()
        eraserTouch = null
        curStroke = null
        snapped = null
        curShape = null
        curRect = null
        lassoPath = null
        laserDown = false
        secY = -1f
        if (selMode != 0) finishSelectionTransform()
        selMode = 0
        activePage = if (selection.isNotEmpty()) selPage else -1
        invalidate()
    }

    private fun tapAt(sx: Float, sy: Float) {
        val now = SystemClock.uptimeMillis()
        if (tool != TEXT && tool != STICKY && tool != TAPE && tool != MARK && tool != SECTION) {
            if (now - lastTapT < 320L && hypot(sx - lastTapX, sy - lastTapY) < 70f) {
                lastTapT = 0L
                toggleZoom(sx, sy)
                return
            }
            lastTapT = now
            lastTapX = sx
            lastTapY = sy
        }
        val wy = (sy - ty) / scale
        val pi = pageIndexAt(wy)
        if (pi < 0) return
        val pg = nb.pages[pi]
        val x = lx(sx, pg)
        val y = ly(sy, pi)
        if (toggleTapeAt(pg, x, y)) return
        if (tool == MARK) {
            markTap(pg, x, y)
            return
        }
        if (tool == SECTION) {
            sectionAt(pg, y)
            return
        }
        if (tool == TEXT || tool == STICKY) requestText(pg, x, y)
    }

    private fun toggleTapeAt(pg: Page, x: Float, y: Float): Boolean {
        for (k in pg.items.indices.reversed()) {
            val it = pg.items[k]
            if (it is TapeItem && it.r.contains(x, y)) {
                it.hidden = !it.hidden
                changed()
                return true
            }
        }
        return false
    }

    private fun requestText(pg: Page, x: Float, y: Float) {
        var existing: TextItem? = null
        for (k in pg.items.indices.reversed()) {
            val it = pg.items[k]
            if (it is TextItem && it.hit(x, y, 4f)) {
                existing = it
                break
            }
        }
        onText?.invoke(existing, pg, x, y, tool == STICKY)
    }

    private fun addPt(s: Stroke, sx: Float, sy: Float, pv: Float) {
        val p = nb.pages[activePage]
        val x = lx(sx, p)
        val y = ly(sy, activePage)
        if (s.n > 0) {
            val dx = x - s.pts[(s.n - 1) * 2]
            val dy = y - s.pts[(s.n - 1) * 2 + 1]
            if (dx * dx + dy * dy < 0.09f) return
        }
        s.addP(x, y, pv)
    }

    // ---- hold to snap shape ----

    private fun snapStroke() {
        val s = curStroke ?: return
        if (mode != 3 || s.n < 4) return
        val sh = recognize(s) ?: return
        snapped = sh
        invalidate()
    }

    private fun recognize(s: Stroke): ShapeItem? {
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        for (i in 0 until s.n) {
            val x = s.pts[i * 2]
            val y = s.pts[i * 2 + 1]
            l = min(l, x); r = max(r, x); t = min(t, y); b = max(b, y)
        }
        val diag = hypot(r - l, b - t)
        if (diag < 12f) return null
        val x0 = s.pts[0]
        val y0 = s.pts[1]
        val xe = s.pts[(s.n - 1) * 2]
        val ye = s.pts[(s.n - 1) * 2 + 1]
        val closed = hypot(xe - x0, ye - y0) < diag * 0.25f && s.n > 8
        val out: ShapeItem
        if (!closed) {
            out = ShapeItem(K_LINE)
            out.x1 = x0
            out.y1 = y0
            out.x2 = xe
            out.y2 = ye
        } else {
            val cx = (l + r) / 2f
            val cy = (t + b) / 2f
            val rx = max(1f, (r - l) / 2f)
            val ry = max(1f, (b - t) / 2f)
            val w = max(1f, r - l)
            val h = max(1f, b - t)
            var errE = 0f
            var errR = 0f
            for (i in 0 until s.n) {
                val x = s.pts[i * 2]
                val y = s.pts[i * 2 + 1]
                val nx = (x - cx) / rx
                val ny = (y - cy) / ry
                errE += abs(sqrt(nx * nx + ny * ny) - 1f)
                val u = (x - l) / w
                val v = (y - t) / h
                errR += min(min(u, 1f - u), min(v, 1f - v))
            }
            errE /= s.n
            errR /= s.n
            out = ShapeItem(if (errE < errR) K_ELLIPSE else K_RECT)
            out.x1 = l
            out.y1 = t
            out.x2 = r
            out.y2 = b
        }
        out.color = s.color
        out.width = s.width
        return out
    }

    // ---- eraser ----

    private fun eraseAt(x: Float, y: Float) {
        val pg = nb.pages[activePage]
        var any = false
        var i = pg.items.size - 1
        while (i >= 0) {
            val it = pg.items[i]
            if (it.hit(x, y, eraserW)) {
                erased.add(Pair(i, it))
                pg.items.removeAt(i)
                any = true
            }
            i--
        }
        if (any) invalidate()
    }

    // ---- lasso / selection ----

    private fun selBounds(): RectF? {
        if (selection.isEmpty()) return null
        val r = RectF(selection[0].bounds())
        for (k in 1 until selection.size) r.union(selection[k].bounds())
        return r
    }

    fun hasSelection() = selection.isNotEmpty()

    fun clearSelection() {
        if (selection.isNotEmpty()) {
            selection = ArrayList()
            selPage = -1
            onSelection?.invoke(false)
        }
        selMode = 0
        invalidate()
    }

    private fun lassoDown(x: Float, y: Float, pi: Int) {
        if (selection.isNotEmpty() && selPage == pi) {
            val b = selBounds()
            if (b != null) {
                val hr = 24f / scale
                if (hypot(x - b.right, y - b.bottom) < hr) {
                    selMode = 2
                    scaleStart = RectF(b)
                    scaleF = 1f
                    return
                }
                b.inset(-6f / scale, -6f / scale)
                if (b.contains(x, y)) {
                    selMode = 1
                    lastLx = x
                    lastLy = y
                    accDx = 0f
                    accDy = 0f
                    return
                }
            }
        }
        clearSelection()
        activePage = pi
        lassoMoved = false
        val p = Path()
        p.moveTo(x, y)
        lassoPath = p
    }

    private fun lassoMove(x: Float, y: Float) {
        when (selMode) {
            1 -> {
                val dx = x - lastLx
                val dy = y - lastLy
                val m = Matrix()
                m.setTranslate(dx, dy)
                for (it in selection) it.applyMatrix(m)
                accDx += dx
                accDy += dy
                lastLx = x
                lastLy = y
            }
            2 -> {
                val bw = scaleStart.right - scaleStart.left
                if (bw > 1f) {
                    val f = ((x - scaleStart.left) / bw).coerceIn(0.1f, 8f)
                    val g = f / scaleF
                    val m = Matrix()
                    m.setScale(g, g, scaleStart.left, scaleStart.top)
                    for (it in selection) it.applyMatrix(m)
                    scaleF = f
                }
            }
            else -> {
                lassoPath?.lineTo(x, y)
                lassoMoved = true
            }
        }
    }

    private fun finishSelectionTransform() {
        if (selMode == 1 && (accDx != 0f || accDy != 0f)) {
            val m = Matrix()
            m.setTranslate(accDx, accDy)
            push(MatrixCmd(ArrayList(selection), m))
            changed()
        } else if (selMode == 2 && scaleF != 1f) {
            val m = Matrix()
            m.setScale(scaleF, scaleF, scaleStart.left, scaleStart.top)
            push(MatrixCmd(ArrayList(selection), m))
            changed()
        }
        accDx = 0f
        accDy = 0f
        scaleF = 1f
    }

    private fun lassoUp(pg: Page, x: Float, y: Float) {
        if (selMode != 0) {
            finishSelectionTransform()
            selMode = 0
            return
        }
        val lp = lassoPath ?: return
        val found = ArrayList<Item>()
        if (!lassoMoved || !moved) {
            for (k in pg.items.indices.reversed()) {
                if (pg.items[k].hit(x, y, 6f / scale)) {
                    found.add(pg.items[k])
                    break
                }
            }
        } else {
            lp.close()
            val rb = RectF()
            lp.computeBounds(rb, true)
            val clip = Region(rb.left.toInt() - 1, rb.top.toInt() - 1, rb.right.toInt() + 2, rb.bottom.toInt() + 2)
            val reg = Region()
            reg.setPath(lp, clip)
            for (it in pg.items) {
                val inside = if (it is Stroke) {
                    var cnt = 0
                    for (i in 0 until it.n) if (reg.contains(it.pts[i * 2].toInt(), it.pts[i * 2 + 1].toInt())) cnt++
                    it.n > 0 && cnt * 2 >= it.n
                } else {
                    val bb = it.bounds()
                    reg.contains(bb.centerX().toInt(), bb.centerY().toInt())
                }
                if (inside) found.add(it)
            }
        }
        if (found.isNotEmpty()) {
            selection = found
            selPage = activePage
            onSelection?.invoke(true)
        }
    }

    fun deleteSelection() {
        if (selection.isEmpty() || selPage !in nb.pages.indices) return
        val pg = nb.pages[selPage]
        val rem = ArrayList<Pair<Int, Item>>()
        for (it in selection) {
            val i = pg.items.indexOf(it)
            if (i >= 0) rem.add(Pair(i, it))
        }
        pg.items.removeAll(selection.toSet())
        push(RemoveCmd(pg, rem))
        clearSelection()
        changed()
    }

    fun duplicateSelection() {
        if (selection.isEmpty() || selPage !in nb.pages.indices) return
        val pg = nb.pages[selPage]
        val copies = ArrayList<Item>()
        val m = Matrix()
        m.setTranslate(18f, 18f)
        for (it in selection) {
            val c = it.copyItem()
            c.applyMatrix(m)
            copies.add(c)
        }
        pg.items.addAll(copies)
        push(AddCmd(pg, copies))
        selection = copies
        changed()
    }

    fun recolorSelection(color: Int) {
        if (selection.isEmpty()) return
        val items = ArrayList(selection)
        val old = items.map { it.color }
        for (it in items) it.color = color
        push(ColorCmd(items, old, color))
        changed()
    }

    // ======================= content insertion =======================

    fun applyText(existing: TextItem?, pg: Page, x: Float, y: Float, sticky: Boolean, text: String) {
        if (existing != null) {
            if (text.isEmpty()) {
                val idx = pg.items.indexOf(existing)
                if (idx >= 0) {
                    pg.items.removeAt(idx)
                    push(RemoveCmd(pg, listOf(Pair(idx, existing as Item))))
                }
            } else if (text != existing.text) {
                val old = existing.text
                existing.text = text
                push(TextEditCmd(existing, old, text))
            }
        } else if (text.isNotEmpty()) {
            val t = TextItem()
            t.text = text
            t.x = x
            t.y = y
            t.size = textSize
            t.color = penColor
            t.sticky = sticky
            t.boxW = if (sticky) 160f else min(260f, max(60f, pg.w - x - 10f))
            pg.items.add(t)
            push(AddCmd(pg, listOf(t)))
        }
        changed()
    }

    fun addTable(pg: Page, r: RectF, rows: Int, cols: Int) {
        val t = TableItem()
        t.color = penColor
        t.width = max(1f, min(penW, 3f))
        t.r.set(r)
        t.rows = rows.coerceIn(1, 30)
        t.cols = cols.coerceIn(1, 30)
        commitAdd(pg, t)
    }

    fun addImage(file: String, aspect: Float) {
        val pi = currentPage()
        val p = nb.pages[pi]
        var w = min(240f, p.w * 0.6f)
        var h = w / aspect
        if (h > p.h * 0.8f) {
            h = p.h * 0.8f
            w = h * aspect
        }
        val cx = lx(width / 2f, p).coerceIn(w / 2f, max(w / 2f, p.w - w / 2f))
        val cy = ly(height / 2f, pi).coerceIn(h / 2f, max(h / 2f, p.h - h / 2f))
        val it = ImageItem()
        it.file = file
        it.r.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        commitAdd(p, it)
        selectTool(LASSO)
        selection = arrayListOf(it)
        selPage = pi
        onSelection?.invoke(true)
        invalidate()
    }

    // ======================= review test =======================

    private fun markTap(pg: Page, x: Float, y: Float) {
        for (k in pg.items.indices.reversed()) {
            val it = pg.items[k]
            if (it is MarkItem && it.hit(x, y, 2f)) {
                pg.items.removeAt(k)
                push(RemoveCmd(pg, listOf(Pair(k, it as Item))))
                changed()
                onGesture?.invoke("mark")
                return
            }
        }
        val m = MarkItem()
        m.value = currentMark
        m.x = x
        m.y = y
        m.r = 20f
        commitAdd(pg, m)
        onGesture?.invoke("mark")
    }

    private fun sectionAt(pg: Page, y: Float) {
        for (k in pg.items.indices.reversed()) {
            val it = pg.items[k]
            if (it is DividerItem && abs(it.y - y) < 18f) {
                onDividerTap?.invoke(it, pg)
                return
            }
        }
        onSection?.invoke(pg, y)
    }

    fun applySection(pg: Page, y: Float, existing: DividerItem?, name: String) {
        if (name.isEmpty()) return
        if (existing != null) {
            if (name != existing.name) {
                val old = existing.name
                val cmd = NameEditCmd(existing, old, name)
                cmd.redo()
                push(cmd)
                changed()
            }
        } else {
            val d = DividerItem()
            d.name = name
            d.y = y
            d.color = Review.colorFor(name)
            commitAdd(pg, d)
        }
    }

    fun removeItem(pg: Page, item: Item) {
        val idx = pg.items.indexOf(item)
        if (idx < 0) return
        pg.items.removeAt(idx)
        push(RemoveCmd(pg, listOf(Pair(idx, item))))
        changed()
    }

    // ======================= extras =======================

    fun hasClip(): Boolean = clip.isNotEmpty()

    fun copySelection() {
        if (selection.isEmpty()) return
        clip = selection.map { it.copyItem() }
    }

    fun paste() {
        if (clip.isEmpty() || nb.pages.isEmpty()) return
        val pi = currentPage()
        val pg = nb.pages[pi]
        val copies = ArrayList<Item>()
        for (it in clip) copies.add(it.copyItem())
        val b = RectF(copies[0].bounds())
        for (k in 1 until copies.size) b.union(copies[k].bounds())
        val cx = lx(width / 2f, pg)
        val cy = ly(insetTop + (height - insetTop - insetBottom) / 2f, pi)
        val m = Matrix()
        m.setTranslate(cx - b.centerX(), cy - b.centerY())
        for (it in copies) it.applyMatrix(m)
        pg.items.addAll(copies)
        push(AddCmd(pg, copies))
        selectTool(LASSO)
        selection = copies
        selPage = pi
        onSelection?.invoke(true)
        changed()
    }

    fun fitWidth() {
        scale = fit
        tx = 0f
        clampPan()
        invalidate()
    }

    fun setInsets(top: Float, bottom: Float) {
        insetTop = top
        insetBottom = bottom
        if (!insetInit) {
            insetInit = true
            if (scale != 0f) ty = top + 16f
        }
        clampPan()
        invalidate()
    }

    private fun toggleZoom(fx: Float, fy: Float) {
        if (scale == 0f) return
        val s0 = scale
        val tx0 = tx
        val ty0 = ty
        val s1 = if (scale > fit * 1.35f) fit else fit * 2.4f
        val r = s1 / s0
        val tx1 = fx - (fx - tx0) * r
        val ty1 = fy - (fy - ty0) * r
        zooming = true
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 240
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            val t = v.animatedValue as Float
            scale = s0 + (s1 - s0) * t
            tx = tx0 + (tx1 - tx0) * t
            ty = ty0 + (ty1 - ty0) * t
            clampPan()
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                zooming = false
                invalidate()
            }
        })
        a.start()
    }

    // ======================= page management =======================

    private fun structureChanged() {
        undoStack.clear()
        redoStack.clear()
        selection = ArrayList()
        selPage = -1
        activePage = -1
        onSelection?.invoke(false)
        relayout()
        changed()
    }

    fun addPage(after: Int, template: String) {
        val ref = nb.pages.getOrNull(after) ?: nb.pages.lastOrNull()
        val p = Page(ref?.w ?: 595f, ref?.h ?: 842f)
        p.template = template
        nb.pages.add((after + 1).coerceIn(0, nb.pages.size), p)
        structureChanged()
    }

    fun deletePage(i: Int) {
        if (nb.pages.size <= 1 || i !in nb.pages.indices) return
        nb.pages.removeAt(i)
        structureChanged()
    }

    fun duplicatePage(i: Int) {
        if (i !in nb.pages.indices) return
        val src = nb.pages[i]
        val p = Page(src.w, src.h)
        p.template = src.template
        p.pdfIndex = src.pdfIndex
        for (it in src.items) p.items.add(it.copyItem())
        nb.pages.add(i + 1, p)
        structureChanged()
    }

    fun movePage(i: Int, delta: Int) {
        val j = i + delta
        if (i !in nb.pages.indices || j !in nb.pages.indices) return
        val p = nb.pages.removeAt(i)
        nb.pages.add(j, p)
        structureChanged()
    }

    fun setTemplate(i: Int, template: String) {
        if (i !in nb.pages.indices) return
        if (nb.pages[i].pdfIndex >= 0) return
        nb.pages[i].template = template
        changed()
    }

    fun refreshAll() {
        invalidate()
    }
}
