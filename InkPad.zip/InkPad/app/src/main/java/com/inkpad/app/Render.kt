package com.inkpad.app

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import java.io.File
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.roundToInt

class PdfSource(file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    val count: Int get() = renderer.pageCount

    @Synchronized
    fun pageSize(i: Int): Pair<Float, Float> {
        val p = renderer.openPage(i)
        try {
            return Pair(p.width.toFloat(), p.height.toFloat())
        } finally {
            p.close()
        }
    }

    @Synchronized
    fun render(i: Int, wPx: Int, hPx: Int): Bitmap {
        val bmp = Bitmap.createBitmap(max(1, wPx), max(1, hPx), Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        val p = renderer.openPage(i)
        try {
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        } finally {
            p.close()
        }
        return bmp
    }

    @Synchronized
    fun close() {
        try {
            renderer.close()
            pfd.close()
        } catch (t: Throwable) {
        }
    }
}

class ImgEnv(private val dir: File) : Env {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    override fun image(name: String): Bitmap? {
        val c = cache.get(name)
        if (c != null) return c
        val f = File(dir, name)
        if (!f.exists()) return null
        val b = try {
            BitmapFactory.decodeFile(f.path)
        } catch (t: Throwable) {
            null
        } ?: return null
        cache.put(name, b)
        return b
    }
}

object Draw {
    val lock = Any()
    private val invFilter = ColorMatrixColorFilter(
        ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    fun bgColor(i: Int): Int = when (i) {
        1 -> 0xFFFBF3DC.toInt()
        2 -> 0xFF1E1F22.toInt()
        else -> Color.WHITE
    }

    fun content(c: Canvas, nb: Notebook, p: Page, pdfBmp: Bitmap?, env: Env) {
        synchronized(lock) {
            val fill = Paint()
            if (p.pdfIndex >= 0) {
                fill.color = Color.WHITE
                c.drawRect(0f, 0f, p.w, p.h, fill)
                if (pdfBmp != null) {
                    val bp = Paint(Paint.FILTER_BITMAP_FLAG)
                    if (nb.invertPdf) bp.colorFilter = invFilter
                    c.drawBitmap(pdfBmp, null, RectF(0f, 0f, p.w, p.h), bp)
                } else if (nb.invertPdf) {
                    fill.color = Color.BLACK
                    c.drawRect(0f, 0f, p.w, p.h, fill)
                }
            } else {
                fill.color = bgColor(nb.pageColor)
                c.drawRect(0f, 0f, p.w, p.h, fill)
                template(c, p, nb.pageColor)
            }
            for (item in p.items) item.draw(c, env)
        }
    }

    private fun template(c: Canvas, p: Page, pc: Int) {
        if (p.template == "blank") return
        val dark = pc == 2
        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.style = Paint.Style.STROKE
        line.strokeWidth = 0.8f
        line.color = if (dark) 0x40FFFFFF else 0x66799CC8
        val w = p.w
        val h = p.h
        when (p.template) {
            "lined" -> {
                var y = 70f
                while (y < h - 30f) {
                    c.drawLine(0f, y, w, y, line)
                    y += 28f
                }
                val m = Paint(line)
                m.color = if (dark) 0x55FF8A80 else 0x88E57373.toInt()
                c.drawLine(64f, 0f, 64f, h, m)
            }
            "grid" -> {
                var x = 24f
                while (x < w) {
                    c.drawLine(x, 0f, x, h, line)
                    x += 24f
                }
                var y = 24f
                while (y < h) {
                    c.drawLine(0f, y, w, y, line)
                    y += 24f
                }
            }
            "dotted" -> {
                val d = Paint(Paint.ANTI_ALIAS_FLAG)
                d.style = Paint.Style.FILL
                d.color = if (dark) 0x77FFFFFF else 0x99607D9B.toInt()
                var y = 24f
                while (y < h - 10f) {
                    var x = 24f
                    while (x < w - 10f) {
                        c.drawCircle(x, y, 1.1f, d)
                        x += 24f
                    }
                    y += 24f
                }
            }
            "cornell" -> {
                val strong = Paint(line)
                strong.strokeWidth = 1.2f
                strong.alpha = 200
                c.drawLine(0f, 70f, w, 70f, strong)
                c.drawLine(w * 0.28f, 70f, w * 0.28f, h - 150f, strong)
                c.drawLine(0f, h - 150f, w, h - 150f, strong)
                var y = 98f
                while (y < h - 150f) {
                    c.drawLine(w * 0.28f, y, w, y, line)
                    y += 28f
                }
            }
            "eng" -> {
                val thin = Paint(line)
                thin.strokeWidth = 0.4f
                val bold = Paint(line)
                bold.strokeWidth = 0.9f
                var i = 0
                var x = 0f
                while (x <= w) {
                    c.drawLine(x, 0f, x, h, if (i % 5 == 0) bold else thin)
                    x += 10f
                    i++
                }
                i = 0
                var y = 0f
                while (y <= h) {
                    c.drawLine(0f, y, w, y, if (i % 5 == 0) bold else thin)
                    y += 10f
                    i++
                }
            }
            "music" -> {
                var y = 70f
                val dk = Paint(line)
                dk.color = if (dark) 0x99FFFFFF.toInt() else 0xAA445566.toInt()
                while (y + 32f < h - 40f) {
                    for (k in 0 until 5) c.drawLine(36f, y + k * 8f, w - 36f, y + k * 8f, dk)
                    c.drawLine(36f, y, 36f, y + 32f, dk)
                    c.drawLine(w - 36f, y, w - 36f, y + 32f, dk)
                    y += 78f
                }
            }
        }
    }
}

object Exporter {
    fun renderPage(nb: Notebook, idx: Int, widthPx: Int, pdf: PdfSource?, env: Env): Bitmap {
        val p = nb.pages[idx]
        val s = widthPx / p.w
        val hPx = max(1, (p.h * s).roundToInt())
        val bmp = Bitmap.createBitmap(widthPx, hPx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(s, s)
        var bg: Bitmap? = null
        if (p.pdfIndex >= 0 && pdf != null) {
            bg = try {
                pdf.render(p.pdfIndex, widthPx, hPx)
            } catch (t: Throwable) {
                null
            }
        }
        Draw.content(c, nb, p, bg, env)
        bg?.recycle()
        return bmp
    }

    fun exportPdf(nb: Notebook, pdf: PdfSource?, env: Env, out: OutputStream) {
        val doc = PdfDocument()
        try {
            for ((i, p) in nb.pages.withIndex()) {
                val info = PdfDocument.PageInfo.Builder(max(1, p.w.roundToInt()), max(1, p.h.roundToInt()), i + 1).create()
                val page = doc.startPage(info)
                val c = page.canvas
                c.scale(info.pageWidth / p.w, info.pageHeight / p.h)
                var bg: Bitmap? = null
                if (p.pdfIndex >= 0 && pdf != null) {
                    bg = try {
                        pdf.render(p.pdfIndex, (p.w * 2f).toInt(), (p.h * 2f).toInt())
                    } catch (t: Throwable) {
                        null
                    }
                }
                Draw.content(c, nb, p, bg, env)
                doc.finishPage(page)
                bg?.recycle()
            }
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }

    fun writeThumb(ctx: Context, nb: Notebook, pdf: PdfSource?, env: Env) {
        try {
            val bmp = renderPage(nb, 0, 360, pdf, env)
            File(Store.dir(ctx, nb.id), "thumb.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
            bmp.recycle()
        } catch (t: Throwable) {
        }
    }
}
