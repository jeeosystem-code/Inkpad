package com.inkpad.app

import android.graphics.Color

class SecStat(val name: String, val page: Int) {
    var total = 0
    var pos = 0
    var neg = 0
    var zero = 0
}

object Review {
    val GREEN = 0xFF16A34A.toInt()
    val RED = 0xFFDC2626.toInt()
    val GRAY = 0xFF6B7280.toInt()

    fun tone(v: Int): Int = if (v > 0) GREEN else if (v < 0) RED else GRAY

    fun fmt(v: Int): String = if (v > 0) "+$v" else v.toString()

    fun colorFor(name: String): Int {
        val n = name.trim().lowercase()
        return when {
            n.startsWith("phy") -> 0xFF3B82F6.toInt()
            n.startsWith("chem") -> 0xFF10B981.toInt()
            n.startsWith("math") -> 0xFFF59E0B.toInt()
            else -> Theme.accent
        }
    }

    fun total(nb: Notebook): Int {
        var t = 0
        for (p in nb.pages) for (item in p.items) if (item is MarkItem) t += item.value
        return t
    }

    // Sections run from one divider line to the next, in reading order (page by page, top to bottom).
    fun sections(nb: Notebook): List<SecStat> {
        val map = LinkedHashMap<String, SecStat>()
        var cur: SecStat? = null
        for ((pi, p) in nb.pages.withIndex()) {
            val ev = ArrayList<Item>()
            for (item in p.items) if (item is DividerItem || item is MarkItem) ev.add(item)
            ev.sortBy { e -> if (e is DividerItem) e.y else (e as MarkItem).y }
            for (e in ev) {
                if (e is DividerItem) {
                    val key = e.name.trim().lowercase()
                    var s = map[key]
                    if (s == null) {
                        s = SecStat(e.name.trim(), pi)
                        map[key] = s
                    }
                    cur = s
                } else if (e is MarkItem) {
                    var c = cur
                    if (c == null) {
                        c = map[""]
                        if (c == null) {
                            c = SecStat("—", pi)
                            map[""] = c
                        }
                        cur = c
                    }
                    c.total += e.value
                    if (e.value > 0) c.pos++ else if (e.value < 0) c.neg++ else c.zero++
                }
            }
        }
        return ArrayList(map.values)
    }
}
