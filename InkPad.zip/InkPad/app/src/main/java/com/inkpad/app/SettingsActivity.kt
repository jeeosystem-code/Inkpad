package com.inkpad.app

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var preview: FlowLayout
    private var topI = 0
    private var botI = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.apply(this)
        edgeToEdge()
        build()
    }

    private fun build() {
        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipToPadding = false
        val wrapper = FrameLayout(this)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(14), 0, dp(14), 0)
        val w = minOf(resources.displayMetrics.widthPixels, dp(660))
        wrapper.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        scroll.addView(wrapper)
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val back = IconView(this, Ic.BACK, Theme.text(), 0.6f)
        back.isClickable = true
        back.pressable()
        back.setOnClickListener { finish() }
        header.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val title = label("Settings", 28f, Theme.text(), Fonts.medium)
        title.letterSpacing = -0.02f
        header.addView(title)
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // appearance
        content.addView(sectionTitle(Ic.DROP, "Look"))
        val look = card()
        addRow(
            look, Ic.DROP, "Theme", null,
            segmented(listOf(Ic.PHONE, Ic.SUN, Ic.MOON), Prefs.theme(this)) { i ->
                Prefs.setTheme(this, i)
                Theme.apply(this)
                recreate()
            }
        )
        content.addView(look, cardLp())

        // library
        content.addView(sectionTitle(Ic.FOLDER, "Library"))
        val lib = card()
        addRow(
            lib, Ic.PAGES, "View", null,
            segmented(listOf(Ic.PAGES, Ic.LIST), Prefs.intOf(this, "view_mode", 0)) { i -> Prefs.setInt(this, "view_mode", i) }
        )
        divider(lib)
        addRow(
            lib, Ic.SORT, "Sort", null,
            segmented(listOf(Ic.EDIT, Ic.TEXT, Ic.FILE), Prefs.intOf(this, "sort", 0)) { i -> Prefs.setInt(this, "sort", i) }
        )
        divider(lib)
        addRow(
            lib, Ic.FOLDER, "Size", null,
            chipRow(listOf("S", "M", "L"), Prefs.intOf(this, "grid_size", 1)) { i -> Prefs.setInt(this, "grid_size", i) }
        )
        content.addView(lib, cardLp())

        // writing
        content.addView(sectionTitle(Ic.PEN, "Writing"))
        val wr = card()
        switchRow(wr, Ic.HAND, "Finger", "Draw with finger", "finger", true)
        divider(wr)
        switchRow(wr, Ic.PEN, "Pressure", "Stylus thickness", "pressure", true)
        divider(wr)
        switchRow(wr, Ic.PHONE, "Haptics", null, "haptic", true)
        divider(wr)
        switchRow(wr, Ic.FOCUS, "Fade bars", "While writing", "autohide", true)
        divider(wr)
        switchRow(wr, Ic.SETTINGS, "Auto-hide tools", "After a few seconds", "panel_autohide", true)
        divider(wr)
        switchRow(wr, Ic.SCROLL, "Momentum", "Keep scrolling", "momentum", true)
        content.addView(wr, cardLp())

        // marks
        content.addView(sectionTitle(Ic.CHECK_CIRCLE, "Marks"))
        val mk = card()
        preview = FlowLayout(this)
        preview.hGap = dp(6)
        preview.vGap = dp(6)
        preview.setPadding(dp(14), dp(12), dp(14), dp(6))
        mk.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        divider(mk)
        addRow(mk, Ic.CHEV_DOWN, "Min", null, stepper("mark_min", -2, -30, 0))
        divider(mk)
        addRow(mk, Ic.CHEV_UP, "Max", null, stepper("mark_max", 4, 0, 60))
        divider(mk)
        addRow(
            mk, Ic.CHECK_CIRCLE, "Stamp", null,
            chipRow(listOf("S", "M", "L"), Prefs.intOf(this, "mark_size", 1)) { i -> Prefs.setInt(this, "mark_size", i) }
        )
        content.addView(mk, cardLp())
        refreshPreview()

        // gestures
        content.addView(sectionTitle(Ic.HAND, "Gestures"))
        val gs = card()
        addRow(gs, Ic.HAND, "2 fingers", "Pan · zoom", null)
        divider(gs)
        addRow(gs, Ic.UNDO, "2-finger tap", "Undo", null)
        divider(gs)
        addRow(gs, Ic.ZOOM, "Double tap", "Zoom in / out", null)
        divider(gs)
        addRow(gs, Ic.SHAPES, "Hold pen", "Snap shape", null)
        content.addView(gs, cardLp())

        // about
        content.addView(sectionTitle(Ic.INFO, "About"))
        val ab = card()
        addRow(ab, Ic.INFO, "InkPad", "1.0", null)
        content.addView(ab, cardLp())

        setContentView(root)

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, ins: WindowInsets ->
            topI = ins.systemWindowInsetTop
            botI = ins.systemWindowInsetBottom
            scroll.setPadding(0, topI + dp(6), 0, botI + dp(28))
            ins
        }
        root.requestApplyInsets()
        scroll.setPadding(0, topI + dp(6), 0, botI + dp(28))
    }

    // ============================ building blocks ============================

    private fun cardLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(6)
        return lp
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(22f)
        c.setPadding(0, dp(4), 0, dp(4))
        return c
    }

    private fun sectionTitle(icon: Int, text: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(18), 0, dp(8))
        row.addView(IconView(this, icon, Theme.sub(), 0.8f), LinearLayout.LayoutParams(dp(20), dp(20)))
        val t = label(text, 13f, Theme.sub(), Fonts.medium)
        t.setPadding(dp(8), 0, 0, 0)
        row.addView(t)
        return row
    }

    private fun divider(card: LinearLayout) {
        val v = View(this)
        v.setBackgroundColor(Theme.field())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        lp.leftMargin = dp(66)
        card.addView(v, lp)
    }

    private fun iconBox(icon: Int): FrameLayout {
        val box = FrameLayout(this)
        box.background = roundBg((Theme.accent and 0x00FFFFFF) or 0x26000000, 12)
        box.addView(IconView(this, icon, Theme.accent, 0.56f), FrameLayout.LayoutParams(dp(40), dp(40)))
        return box
    }

    private fun addRow(card: LinearLayout, icon: Int, title: String, sub: String?, trailing: View?) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(8), dp(12), dp(8))
        row.minimumHeight = dp(56)
        row.addView(iconBox(icon), LinearLayout.LayoutParams(dp(40), dp(40)))
        val txt = LinearLayout(this)
        txt.orientation = LinearLayout.VERTICAL
        txt.setPadding(dp(12), 0, dp(8), 0)
        txt.addView(label(title, 15.5f, Theme.text(), Fonts.medium))
        if (sub != null) txt.addView(label(sub, 12f, Theme.sub()))
        row.addView(txt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) row.addView(trailing)
        card.addView(row)
    }

    private fun switchRow(card: LinearLayout, icon: Int, title: String, sub: String?, key: String, def: Boolean) {
        val sw = Switch(this)
        sw.isChecked = Prefs.bool(this, key, def)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(Theme.accent, 0xFF8A93A6.toInt()))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, 0xFFE4E7EE.toInt()))
        sw.setOnCheckedChangeListener { _, on -> Prefs.setBool(this, key, on) }
        addRow(card, icon, title, sub, sw)
    }

    private fun segmented(icons: List<Int>, sel: Int, onSel: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.background = fieldBg(16f)
        box.setPadding(dp(3), dp(3), dp(3), dp(3))
        val cells = ArrayList<FrameLayout>()
        val ics = ArrayList<IconView>()
        var cur = sel
        fun paint() {
            for (i in cells.indices) {
                val on = i == cur
                cells[i].background = if (on) accentFill(13f) else null
                ics[i].set(icons[i], if (on) Color.WHITE else Theme.sub())
            }
        }
        for ((i, ic) in icons.withIndex()) {
            val cell = FrameLayout(this)
            val iv = IconView(this, ic, Theme.sub(), 0.55f)
            cell.addView(iv, FrameLayout.LayoutParams(dp(48), dp(40)))
            cell.isClickable = true
            cell.setOnClickListener {
                cur = i
                paint()
                onSel(i)
            }
            cells.add(cell)
            ics.add(iv)
            box.addView(cell, LinearLayout.LayoutParams(dp(48), dp(40)))
        }
        paint()
        return box
    }

    private fun stepper(key: String, def: Int, lo: Int, hi: Int): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        var v = Prefs.intOf(this, key, def).coerceIn(lo, hi)
        val value = label(Review.fmt(v), 18f, Theme.text(), Fonts.medium)
        value.gravity = Gravity.CENTER
        fun btn(sym: String, d: Int): TextView {
            val b = label(sym, 22f, Theme.text(), Fonts.medium)
            b.gravity = Gravity.CENTER
            b.background = fieldBg(14f)
            b.pressable()
            b.setOnClickListener {
                v = (v + d).coerceIn(lo, hi)
                value.text = Review.fmt(v)
                Prefs.setInt(this, key, v)
                refreshPreview()
            }
            return b
        }
        box.addView(btn("–", -1), LinearLayout.LayoutParams(dp(44), dp(44)))
        box.addView(value, LinearLayout.LayoutParams(dp(50), dp(44)))
        box.addView(btn("+", 1), LinearLayout.LayoutParams(dp(44), dp(44)))
        return box
    }

    private fun refreshPreview() {
        preview.removeAllViews()
        val lo = minOf(Prefs.intOf(this, "mark_min", -2), 0)
        val hi = maxOf(Prefs.intOf(this, "mark_max", 4), 0)
        for (v in lo..hi) {
            val tone = Review.tone(v)
            val chip = label(Review.fmt(v), 12.5f, tone, Fonts.medium)
            chip.gravity = Gravity.CENTER
            val g = android.graphics.drawable.GradientDrawable()
            g.shape = android.graphics.drawable.GradientDrawable.OVAL
            g.setColor((tone and 0x00FFFFFF) or 0x26000000)
            chip.background = g
            preview.addView(chip, ViewGroup.LayoutParams(dp(38), dp(38)))
        }
    }
}
