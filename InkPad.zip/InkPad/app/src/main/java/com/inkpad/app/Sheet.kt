package com.inkpad.app

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import kotlin.math.min

class Sheet(private val act: Activity) {
    private val dlg = Dialog(act)
    private val wrap = FrameLayout(act)
    private val root = LinearLayout(act)
    private val titleTv = TextView(act)
    private val body = LinearLayout(act)
    private val scroll = ScrollView(act)
    private val actions = LinearLayout(act)
    private var dismissCb: (() -> Unit)? = null
    private var kb = false

    init {
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        wrap.setPadding(act.dp(10), act.dp(10), act.dp(10), act.dp(14))
        root.orientation = LinearLayout.VERTICAL
        root.background = act.glass(28f, true)
        root.setPadding(act.dp(18), act.dp(10), act.dp(18), act.dp(12))
        val handle = View(act)
        handle.background = act.roundBg(Theme.field(), 3)
        val hl = LinearLayout.LayoutParams(act.dp(36), act.dp(5))
        hl.gravity = Gravity.CENTER_HORIZONTAL
        hl.bottomMargin = act.dp(10)
        root.addView(handle, hl)
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
        titleTv.setTextColor(Theme.text())
        titleTv.typeface = Fonts.medium
        titleTv.visibility = View.GONE
        titleTv.setPadding(0, 0, 0, act.dp(8))
        root.addView(titleTv)
        body.orientation = LinearLayout.VERTICAL
        scroll.addView(body)
        scroll.isVerticalScrollBarEnabled = false
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        actions.orientation = LinearLayout.HORIZONTAL
        actions.gravity = Gravity.END or Gravity.CENTER_VERTICAL
    }

    fun title(t: String): Sheet {
        titleTv.text = t
        titleTv.visibility = View.VISIBLE
        return this
    }

    fun view(v: View): Sheet {
        body.addView(v)
        return this
    }

    fun view(v: View, lp: LinearLayout.LayoutParams): Sheet {
        body.addView(v, lp)
        return this
    }

    fun message(t: String): Sheet {
        val tv = act.label(t, 14f, Theme.sub())
        tv.setPadding(0, act.dp(2), 0, act.dp(8))
        body.addView(tv)
        return this
    }

    fun keyboard(): Sheet {
        kb = true
        return this
    }

    fun onDismiss(cb: () -> Unit): Sheet {
        dismissCb = cb
        return this
    }

    private fun btn(t: String, kind: Int, close: Boolean, cb: (() -> Unit)?): Sheet {
        val color = when (kind) {
            1 -> Color.WHITE
            2 -> Theme.danger
            else -> Theme.accent
        }
        val b = act.label(t, 15f, color, Fonts.medium)
        b.setPadding(act.dp(20), act.dp(11), act.dp(20), act.dp(11))
        b.gravity = Gravity.CENTER
        if (kind == 1) b.background = act.accentFill(14f)
        b.pressable()
        b.setOnClickListener {
            if (close) dismiss()
            if (cb != null) cb()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = act.dp(6)
        actions.addView(b, lp)
        return this
    }

    fun primary(t: String, close: Boolean = true, cb: () -> Unit): Sheet = btn(t, 1, close, cb)
    fun secondary(t: String, cb: (() -> Unit)? = null): Sheet = btn(t, 0, true, cb)
    fun danger(t: String, cb: () -> Unit): Sheet = btn(t, 2, true, cb)

    fun iconBtn(icon: Int, primary: Boolean, close: Boolean = true, danger: Boolean = false, cb: (() -> Unit)? = null): Sheet {
        val box = FrameLayout(act)
        box.background = if (primary && danger) act.roundBg(Theme.danger, 24) else if (primary) act.accentFill(24f) else act.fieldBg(24f)
        val tint = if (primary) Color.WHITE else (if (danger) Theme.danger else Theme.text())
        box.addView(IconView(act, icon, tint, 0.5f), FrameLayout.LayoutParams(act.dp(48), act.dp(48)))
        box.isClickable = true
        box.pressable()
        box.setOnClickListener {
            if (close) dismiss()
            if (cb != null) cb()
        }
        val lp = LinearLayout.LayoutParams(act.dp(48), act.dp(48))
        lp.leftMargin = act.dp(8)
        actions.addView(box, lp)
        return this
    }

    fun dismiss() {
        try {
            dlg.dismiss()
        } catch (t: Throwable) {
        }
    }

    fun show(): Sheet {
        if (actions.childCount > 0) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = act.dp(6)
            root.addView(actions, lp)
        }
        wrap.addView(root)
        dlg.setContentView(wrap)
        val w = dlg.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            val dm = act.resources.displayMetrics
            w.setLayout(min(dm.widthPixels, act.dp(580)), ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setDimAmount(0.42f)
            if (kb) {
                w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
            } else {
                w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    val a = w.attributes
                    a.blurBehindRadius = 28
                    w.attributes = a
                } catch (t: Throwable) {
                }
            }
        }
        dlg.setOnDismissListener { dismissCb?.invoke() }
        wrap.alpha = 0f
        wrap.translationY = act.dp(36).toFloat()
        dlg.show()
        wrap.animate().alpha(1f).translationY(0f).setDuration(200).start()
        return this
    }
}

class Tile(val icon: Int, val label: String, val active: Boolean = false, val action: () -> Unit)

fun Activity.chipView(text: String, selected: Boolean): TextView {
    val t = label(text, 13f, if (selected) Color.WHITE else Theme.text(), Fonts.medium)
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    t.gravity = Gravity.CENTER
    t.background = if (selected) accentFill(999f) else fieldBg(999f)
    t.pressable()
    return t
}

fun Activity.chipRow(opts: List<String>, sel: Int, onSel: (Int) -> Unit): HorizontalScrollView {
    val sv = HorizontalScrollView(this)
    sv.isHorizontalScrollBarEnabled = false
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    val chips = ArrayList<TextView>()
    var cur = sel
    for ((i, name) in opts.withIndex()) {
        val c = chipView(name, i == cur)
        chips.add(c)
        c.setOnClickListener {
            cur = i
            for ((k, ch) in chips.withIndex()) {
                val on = k == cur
                ch.background = if (on) accentFill(999f) else fieldBg(999f)
                ch.setTextColor(if (on) Color.WHITE else Theme.text())
            }
            onSel(i)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = dp(8)
        row.addView(c, lp)
    }
    sv.addView(row)
    return sv
}

fun Activity.chooseSheet(title: String, items: List<String>, icons: List<Int>? = null, selected: Int = -1, onPick: (Int) -> Unit) {
    val sh = Sheet(this).title(title)
    for ((i, name) in items.withIndex()) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(2), dp(12), dp(2))
        if (i == selected) row.background = fieldBg(14f)
        if (icons != null && i < icons.size) {
            row.addView(IconView(this, icons[i], if (i == selected) Theme.accent else Theme.sub()), LinearLayout.LayoutParams(dp(34), dp(34)))
        }
        val t = label(name, 16f, Theme.text(), if (i == selected) Fonts.medium else Fonts.regular)
        t.setPadding(dp(10), dp(12), dp(6), dp(12))
        row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (i == selected) row.addView(IconView(this, Ic.CHECK, Theme.accent), LinearLayout.LayoutParams(dp(28), dp(28)))
        row.isClickable = true
        row.pressable(0.97f)
        row.setOnClickListener {
            sh.dismiss()
            onPick(i)
        }
        sh.view(row)
    }
    sh.iconBtn(Ic.CLOSE, false).show()
}

fun Activity.tileSheet(title: String, tiles: List<Tile>) {
    val sh = Sheet(this).title(title)
    var i = 0
    while (i < tiles.size) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (k in 0 until 3) {
            val idx = i + k
            val cell: View
            if (idx < tiles.size) {
                val t = tiles[idx]
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.gravity = Gravity.CENTER
                box.background = if (t.active) accentFill(18f) else fieldBg(18f)
                val fg = if (t.active) Color.WHITE else Theme.text()
                box.addView(IconView(this, t.icon, fg, 0.62f), LinearLayout.LayoutParams(dp(40), dp(32)))
                val lb = label(t.label, 11.5f, fg, Fonts.medium)
                lb.gravity = Gravity.CENTER
                lb.maxLines = 1
                box.addView(lb)
                box.isClickable = true
                box.pressable(0.95f)
                box.setOnClickListener {
                    sh.dismiss()
                    t.action()
                }
                cell = box
            } else {
                cell = View(this)
            }
            val lp = LinearLayout.LayoutParams(0, dp(84), 1f)
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            row.addView(cell, lp)
        }
        sh.view(row)
        i += 3
    }
    sh.iconBtn(Ic.CLOSE, false).show()
}

fun Activity.inputSheet(
    title: String,
    initial: String,
    hint: String,
    multiline: Boolean = false,
    numeric: Boolean = false,
    ok: String = "Save",
    onOk: (String) -> Unit
) {
    val et = EditText(this)
    et.setText(initial)
    et.setSelection(et.text.length)
    et.hint = hint
    et.setTextColor(Theme.text())
    et.setHintTextColor(Theme.sub())
    et.typeface = Fonts.regular
    et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
    et.background = fieldBg(14f)
    et.setPadding(dp(14), dp(12), dp(14), dp(12))
    if (multiline) {
        et.minLines = 4
        et.gravity = Gravity.TOP or Gravity.START
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    } else {
        et.maxLines = 1
        et.inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
    }
    val sh = Sheet(this).title(title).view(et).keyboard()
    sh.iconBtn(Ic.CLOSE, false).iconBtn(Ic.CHECK, true) { onOk(et.text.toString().trim()) }.show()
    et.requestFocus()
}

fun Activity.confirmSheet(title: String, msg: String, ok: String, isDanger: Boolean, onOk: () -> Unit) {
    val sh = Sheet(this).title(title).message(msg)
    sh.iconBtn(Ic.CLOSE, false)
    if (isDanger) sh.iconBtn(Ic.TRASH, true, true, true, onOk) else sh.iconBtn(Ic.CHECK, true, true, false, onOk)
    sh.show()
}

fun Activity.colorSheet(initial: Int, onPick: (Int) -> Unit) {
    var chosen = initial
    val prev = View(this)
    val picker = ColorPickerView(this, initial) { c ->
        chosen = c
        val g = GradientDrawable()
        g.setColor(c)
        g.cornerRadius = dpf(12f)
        prev.background = g
    }
    val g0 = GradientDrawable()
    g0.setColor(initial)
    g0.cornerRadius = dpf(12f)
    prev.background = g0
    val sh = Sheet(this).title("Custom color")
    sh.view(picker, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36))
    lp.topMargin = dp(12)
    sh.view(prev, lp)
    sh.iconBtn(Ic.CLOSE, false).iconBtn(Ic.CHECK, true) { onPick(chosen) }.show()
}

private fun Activity.toggleRow(title: String, sub: String, key: String, def: Boolean): View {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, dp(8), 0, dp(8))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(label(title, 15f, Theme.text(), Fonts.medium))
    col.addView(label(sub, 12f, Theme.sub()))
    row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    val sw = Switch(this)
    sw.isChecked = Prefs.bool(this, key, def)
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    sw.trackTintList = ColorStateList(states, intArrayOf(Theme.accent, 0xFF8A93A6.toInt()))
    sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, 0xFFE4E7EE.toInt()))
    sw.setOnCheckedChangeListener { _, on -> Prefs.setBool(this, key, on) }
    row.addView(sw)
    return row
}

fun Activity.settingsSheet(onDone: () -> Unit) {
    startActivity(Intent(this, SettingsActivity::class.java))
}

private fun Activity.numStepper(icon: Int, key: String, def: Int, lo: Int, hi: Int): View {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, dp(4), 0, dp(4))
    row.addView(IconView(this, icon, Theme.sub(), 0.6f), LinearLayout.LayoutParams(dp(34), dp(34)))
    var v = Prefs.intOf(this, key, def).coerceIn(lo, hi)
    val value = label(Review.fmt(v), 20f, Theme.text(), Fonts.medium)
    value.gravity = Gravity.CENTER
    row.addView(value, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    fun sbtn(sym: String, d: Int): TextView {
        val b = label(sym, 22f, Theme.text(), Fonts.medium)
        b.gravity = Gravity.CENTER
        b.background = fieldBg(14f)
        b.pressable()
        b.setOnClickListener {
            v = (v + d).coerceIn(lo, hi)
            value.text = Review.fmt(v)
            Prefs.setInt(this, key, v)
        }
        return b
    }
    val l1 = LinearLayout.LayoutParams(dp(44), dp(44))
    l1.rightMargin = dp(8)
    row.addView(sbtn("–", -1), l1)
    row.addView(sbtn("+", 1), LinearLayout.LayoutParams(dp(44), dp(44)))
    return row
}
