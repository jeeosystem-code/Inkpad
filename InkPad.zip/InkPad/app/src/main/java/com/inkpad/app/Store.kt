package com.inkpad.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Meta(val id: String, val title: String, val modified: Long, val pages: Int, val hasPdf: Boolean)

object Store {
    fun root(ctx: Context): File {
        val f = File(ctx.filesDir, "notes")
        f.mkdirs()
        return f
    }

    fun dir(ctx: Context, id: String): File {
        val f = File(root(ctx), id)
        f.mkdirs()
        return f
    }

    fun newId(): String = java.lang.Long.toString(System.currentTimeMillis(), 36) + (100..999).random()

    private fun atomicWrite(target: File, text: String) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(target)) {
            target.writeText(text)
            tmp.delete()
        }
    }

    fun list(ctx: Context): List<Meta> {
        val out = ArrayList<Meta>()
        val dirs = root(ctx).listFiles() ?: return out
        for (d in dirs) {
            val mf = File(d, "meta.json")
            if (!mf.exists()) continue
            try {
                val o = JSONObject(mf.readText())
                out.add(Meta(d.name, o.optString("title", "Untitled"), o.optLong("modified"), o.optInt("pages"), o.optBoolean("pdf")))
            } catch (t: Throwable) {
            }
        }
        out.sortByDescending { it.modified }
        return out
    }

    fun save(ctx: Context, nb: Notebook) {
        nb.modified = System.currentTimeMillis()
        val d = dir(ctx, nb.id)
        val o = JSONObject()
        o.put("title", nb.title)
        o.put("modified", nb.modified)
        o.put("pc", nb.pageColor)
        o.put("inv", nb.invertPdf)
        o.put("pdf", nb.hasPdf)
        val pg = JSONArray()
        for (p in nb.pages) {
            val po = JSONObject()
            po.put("w", p.w.toDouble())
            po.put("h", p.h.toDouble())
            po.put("tpl", p.template)
            po.put("pi", p.pdfIndex)
            val ia = JSONArray()
            for (item in p.items) ia.put(item.toJson())
            po.put("items", ia)
            pg.put(po)
        }
        o.put("pages", pg)
        val rec = JSONArray()
        for (r in nb.recordings) rec.put(r)
        o.put("rec", rec)
        atomicWrite(File(d, "note.json"), o.toString())
        val m = JSONObject()
        m.put("title", nb.title)
        m.put("modified", nb.modified)
        m.put("pages", nb.pages.size)
        m.put("pdf", nb.hasPdf)
        atomicWrite(File(d, "meta.json"), m.toString())
    }

    fun load(ctx: Context, id: String): Notebook? {
        val f = File(dir(ctx, id), "note.json")
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText())
            val nb = Notebook(id, o.optString("title", "Untitled"))
            nb.modified = o.optLong("modified")
            nb.pageColor = o.optInt("pc")
            nb.invertPdf = o.optBoolean("inv")
            nb.hasPdf = o.optBoolean("pdf")
            val pg = o.getJSONArray("pages")
            for (i in 0 until pg.length()) {
                val po = pg.getJSONObject(i)
                val p = Page(po.optDouble("w", 595.0).toFloat(), po.optDouble("h", 842.0).toFloat())
                p.template = po.optString("tpl", "blank")
                p.pdfIndex = po.optInt("pi", -1)
                val ia = po.optJSONArray("items")
                if (ia != null) {
                    for (k in 0 until ia.length()) {
                        val it = itemFromJson(ia.getJSONObject(k))
                        if (it != null) p.items.add(it)
                    }
                }
                nb.pages.add(p)
            }
            val rec = o.optJSONArray("rec")
            if (rec != null) for (i in 0 until rec.length()) nb.recordings.add(rec.getString(i))
            if (nb.pages.isEmpty()) nb.pages.add(Page(595f, 842f))
            nb
        } catch (t: Throwable) {
            null
        }
    }

    fun delete(ctx: Context, id: String) {
        File(root(ctx), id).deleteRecursively()
    }

    fun duplicate(ctx: Context, id: String): String {
        val newId = newId()
        File(root(ctx), id).copyRecursively(File(root(ctx), newId), true)
        val nb = load(ctx, newId)
        if (nb != null) {
            nb.title = nb.title + " copy"
            save(ctx, nb)
        }
        return newId
    }
}
