package com.inkpad.app

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("inkpad", Context.MODE_PRIVATE)

    fun theme(c: Context): Int = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) {
        sp(c).edit().putInt("theme", v).apply()
    }

    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) {
        sp(c).edit().putBoolean(k, v).apply()
    }

    fun intOf(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) {
        sp(c).edit().putInt(k, v).apply()
    }

    fun starred(c: Context): Set<String> = sp(c).getStringSet("starred", emptySet()) ?: emptySet()

    fun toggleStar(c: Context, id: String): Boolean {
        val s = HashSet(starred(c))
        val on: Boolean
        if (s.contains(id)) {
            s.remove(id)
            on = false
        } else {
            s.add(id)
            on = true
        }
        sp(c).edit().putStringSet("starred", s).apply()
        return on
    }

    fun recent(c: Context): List<Int> {
        val raw = sp(c).getString("recent", "") ?: ""
        return raw.split(",").mapNotNull { it.toIntOrNull() }
    }

    fun addRecent(c: Context, color: Int) {
        val l = ArrayList(recent(c))
        l.remove(color)
        l.add(0, color)
        while (l.size > 8) l.removeAt(l.size - 1)
        sp(c).edit().putString("recent", l.joinToString(",")).apply()
    }
}

object Theme {
    var dark = false
    val accent = 0xFF7C6CFF.toInt()
    val accent2 = 0xFF3BB4FF.toInt()
    val danger = 0xFFFF5C6C.toInt()

    fun apply(c: Context) {
        dark = when (Prefs.theme(c)) {
            1 -> false
            2 -> true
            else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
    }

    fun text(): Int = if (dark) 0xFFF4F5F8.toInt() else 0xFF12141C.toInt()
    fun sub(): Int = if (dark) 0xFF9AA3B5.toInt() else 0xFF667085.toInt()
    fun bgTop(): Int = if (dark) 0xFF0B0C12.toInt() else 0xFFEEF0FF.toInt()
    fun bgBottom(): Int = if (dark) 0xFF171326.toInt() else 0xFFF8F3FF.toInt()
    fun surround(): Int = if (dark) 0xFF0F1015.toInt() else 0xFFDDE1EE.toInt()
    fun field(): Int = if (dark) 0x26FFFFFF else 0x12000000
}

object Fonts {
    val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val light: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
    val black: Typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
}

fun Context.glass(radiusDp: Float = 22f, strong: Boolean = false): GradientDrawable {
    val top: Int
    val bot: Int
    if (Theme.dark) {
        top = if (strong) 0xF2262833.toInt() else 0xCC2A2C38.toInt()
        bot = if (strong) 0xF21B1C25.toInt() else 0xB31D1F29.toInt()
    } else {
        top = if (strong) 0xF7FFFFFF.toInt() else 0xD9FFFFFF.toInt()
        bot = if (strong) 0xF2F3F5FF.toInt() else 0xBFF1F3FF.toInt()
    }
    val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bot))
    g.cornerRadius = dpf(radiusDp)
    g.setStroke(dp(1), if (Theme.dark) 0x30FFFFFF else 0xB3FFFFFF.toInt())
    return g
}

fun Context.accentFill(radiusDp: Float = 16f): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Theme.accent, Theme.accent2))
    g.cornerRadius = dpf(radiusDp)
    return g
}

fun Context.fieldBg(radiusDp: Float = 14f): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(Theme.field())
    g.cornerRadius = dpf(radiusDp)
    return g
}

class AuroraView(ctx: Context) : View(ctx) {
    private val p = Paint()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, Theme.bgTop(), Theme.bgBottom(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        val dk = Theme.dark
        blob(c, w * 0.12f, h * 0.10f, w * 0.80f, Theme.accent, if (dk) 0x60 else 0x44)
        blob(c, w * 0.98f, h * 0.42f, w * 0.75f, Theme.accent2, if (dk) 0x48 else 0x38)
        blob(c, w * 0.15f, h * 0.98f, w * 0.85f, 0xFFFF7AB6.toInt(), if (dk) 0x38 else 0x30)
        p.shader = null
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, alpha: Int) {
        val inner = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
        p.shader = RadialGradient(cx, cy, r, intArrayOf(inner, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
    }
}
