package com.inkpad.app

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("inkpad", Context.MODE_PRIVATE)

    fun theme(c: Context): Int = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) {
        sp(c).edit().putInt("theme", v).apply()
    }

    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) {
        sp(c).edit().putBoolean(k, v).apply()
    }

    fun intOf(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) {
        sp(c).edit().putInt(k, v).apply()
    }

    fun starred(c: Context): Set<String> = sp(c).getStringSet("starred", emptySet()) ?: emptySet()

    fun toggleStar(c: Context, id: String): Boolean {
        val s = HashSet(starred(c))
        val on: Boolean
        if (s.contains(id)) {
            s.remove(id)
            on = false
        } else {
            s.add(id)
            on = true
        }
        sp(c).edit().putStringSet("starred", s).apply()
        return on
    }

    fun recent(c: Context): List<Int> {
        val raw = sp(c).getString("recent", "") ?: ""
        return raw.split(",").mapNotNull { it.toIntOrNull() }
    }

    fun addRecent(c: Context, color: Int) {
        val l = ArrayList(recent(c))
        l.remove(color)
        l.add(0, color)
        while (l.size > 8) l.removeAt(l.size - 1)
        sp(c).edit().putString("recent", l.joinToString(",")).apply()
    }
}

object Theme {
    var dark = false
    val accent = 0xFF7C6CFF.toInt()
    val accent2 = 0xFF3BB4FF.toInt()
    val danger = 0xFFFF5C6C.toInt()

    fun apply(c: Context) {
        dark = when (Prefs.theme(c)) {
            1 -> false
            2 -> true
            else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
    }

    fun text(): Int = if (dark) 0xFFF4F5F8.toInt() else 0xFF12141C.toInt()
    fun sub(): Int = if (dark) 0xFF9AA3B5.toInt() else 0xFF667085.toInt()
    fun bgTop(): Int = if (dark) 0xFF0B0C12.toInt() else 0xFFEEF0FF.toInt()
    fun bgBottom(): Int = if (dark) 0xFF171326.toInt() else 0xFFF8F3FF.toInt()
    fun surround(): Int = if (dark) 0xFF0F1015.toInt() else 0xFFDDE1EE.toInt()
    fun field(): Int = if (dark) 0x26FFFFFF else 0x12000000
}

object Fonts {
    var regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    var medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    var semi: Typeface = medium
    var bold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)
    var extra: Typeface = bold
    var light: Typeface = regular
    var black: Typeface = bold

    private var loaded = false
    private val faces = HashMap<String, Typeface>()

    private fun key(family: Int, bold: Boolean, italic: Boolean) = "$family|$bold|$italic"

    // Loads the fonts bundled in assets/fonts. Any file that is missing falls back to the system font.
    @Synchronized
    fun init(ctx: Context) {
        if (loaded) return
        loaded = true
        val am = ctx.applicationContext.assets
        fun load(name: String, fallback: Typeface): Typeface = try {
            Typeface.createFromAsset(am, "fonts/$name.ttf")
        } catch (t: Throwable) {
            fallback
        }

        regular = load("PlusJakartaSans-Regular", regular)
        medium = load("PlusJakartaSans-Medium", medium)
        semi = load("PlusJakartaSans-SemiBold", medium)
        bold = load("PlusJakartaSans-Bold", bold)
        extra = load("PlusJakartaSans-ExtraBold", bold)
        light = regular
        black = extra

        // Text tool families: 0 Sans, 1 Serif, 2 Mono, 3 Hand
        faces[key(0, false, false)] = regular
        faces[key(0, true, false)] = bold
        faces[key(0, false, true)] = load("PlusJakartaSans-Italic", Typeface.create(regular, Typeface.ITALIC))
        faces[key(0, true, true)] = load("PlusJakartaSans-BoldItalic", Typeface.create(bold, Typeface.ITALIC))

        val lr = load("Lora-Regular", Typeface.SERIF)
        val lb = load("Lora-Bold", Typeface.create(Typeface.SERIF, Typeface.BOLD))
        faces[key(1, false, false)] = lr
        faces[key(1, true, false)] = lb
        faces[key(1, false, true)] = load("Lora-Italic", Typeface.create(lr, Typeface.ITALIC))
        faces[key(1, true, true)] = load("Lora-BoldItalic", Typeface.create(lb, Typeface.ITALIC))

        val mr = load("JetBrainsMono-Regular", Typeface.MONOSPACE)
        val mb = load("JetBrainsMono-Bold", Typeface.create(Typeface.MONOSPACE, Typeface.BOLD))
        faces[key(2, false, false)] = mr
        faces[key(2, true, false)] = mb
        faces[key(2, false, true)] = load("JetBrainsMono-Italic", Typeface.create(mr, Typeface.ITALIC))
        faces[key(2, true, true)] = load("JetBrainsMono-BoldItalic", Typeface.create(mb, Typeface.ITALIC))

        val cr = load("Caveat-Regular", Typeface.create("cursive", Typeface.NORMAL))
        val cb = load("Caveat-Bold", Typeface.create("cursive", Typeface.BOLD))
        faces[key(3, false, false)] = cr
        faces[key(3, true, false)] = cb
        faces[key(3, false, true)] = Typeface.create(cr, Typeface.ITALIC)
        faces[key(3, true, true)] = Typeface.create(cb, Typeface.ITALIC)
    }

    fun textFace(family: Int, bold: Boolean, italic: Boolean): Typeface {
        val f = faces[key(family, bold, italic)]
        if (f != null) return f
        val base = when (family) {
            1 -> Typeface.SERIF
            2 -> Typeface.MONOSPACE
            3 -> Typeface.create("cursive", Typeface.NORMAL)
            else -> Typeface.SANS_SERIF
        }
        val st = if (bold && italic) Typeface.BOLD_ITALIC else if (bold) Typeface.BOLD else if (italic) Typeface.ITALIC else Typeface.NORMAL
        return Typeface.create(base, st)
    }
}

fun Context.glass(radiusDp: Float = 22f, strong: Boolean = false): GradientDrawable {
    val top: Int
    val bot: Int
    if (Theme.dark) {
        top = if (strong) 0xF2262833.toInt() else 0xCC2A2C38.toInt()
        bot = if (strong) 0xF21B1C25.toInt() else 0xB31D1F29.toInt()
    } else {
        top = if (strong) 0xF7FFFFFF.toInt() else 0xD9FFFFFF.toInt()
        bot = if (strong) 0xF2F3F5FF.toInt() else 0xBFF1F3FF.toInt()
    }
    val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bot))
    g.cornerRadius = dpf(radiusDp)
    g.setStroke(dp(1), if (Theme.dark) 0x30FFFFFF else 0xB3FFFFFF.toInt())
    return g
}

fun Context.accentFill(radiusDp: Float = 16f): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Theme.accent, Theme.accent2))
    g.cornerRadius = dpf(radiusDp)
    return g
}

fun Context.fieldBg(radiusDp: Float = 14f): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(Theme.field())
    g.cornerRadius = dpf(radiusDp)
    return g
}

class AuroraView(ctx: Context) : View(ctx) {
    private val p = Paint()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, Theme.bgTop(), Theme.bgBottom(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        val dk = Theme.dark
        blob(c, w * 0.12f, h * 0.10f, w * 0.80f, Theme.accent, if (dk) 0x60 else 0x44)
        blob(c, w * 0.98f, h * 0.42f, w * 0.75f, Theme.accent2, if (dk) 0x48 else 0x38)
        blob(c, w * 0.15f, h * 0.98f, w * 0.85f, 0xFFFF7AB6.toInt(), if (dk) 0x38 else 0x30)
        p.shader = null
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, alpha: Int) {
        val inner = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
        p.shader = RadialGradient(cx, cy, r, intArrayOf(inner, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
    }
}
