package com.inkpad.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import android.widget.Toast

object UiScale {
    // 1.0 on a 360dp-wide phone, larger on tablets, slightly smaller on compact phones
    fun factor(c: Context): Float {
        val sw = c.resources.configuration.smallestScreenWidthDp
        return (sw / 360f).coerceIn(0.88f, 1.4f)
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density * UiScale.factor(this) + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density * UiScale.factor(this)

// One shared type scale: every label snaps to a step so sizes stay consistent across screens.
object Type {
    fun snap(sp: Float): Float = when {
        sp <= 11.25f -> 11f
        sp <= 13f -> 12.5f
        sp <= 14.75f -> 14f
        sp <= 16.5f -> 15.5f
        sp <= 19f -> 18f
        sp <= 25f -> 22f
        sp <= 30f -> 28f
        else -> 32f
    }
}

fun Context.label(
    text: String,
    sizeSp: Float = 14f,
    color: Int = Theme.text(),
    font: Typeface = Fonts.regular,
    tabular: Boolean = false
): TextView {
    val t = TextView(this)
    val s = Type.snap(sizeSp)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, s * UiScale.factor(this))
    t.setTextColor(color)
    var face = font
    if (font === Fonts.medium && s >= 28f) face = Fonts.extra
    else if (font === Fonts.medium && s >= 18f) face = Fonts.semi
    t.typeface = face
    t.includeFontPadding = false
    if (tabular) t.fontFeatureSettings = "tnum"
    return t
}

fun Context.roundBg(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dpf(radiusDp.toFloat())
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.toast(s: String) {
    Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

fun View.pressable(scaleTo: Float = 0.93f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(scaleTo).scaleY(scaleTo).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

fun View.tick() {
    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
}

@Suppress("DEPRECATION")
fun Activity.edgeToEdge() {
    window.statusBarColor = Color.TRANSPARENT
    window.navigationBarColor = Color.TRANSPARENT
    var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    if (!Theme.dark && Build.VERSION.SDK_INT >= 23) f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    if (!Theme.dark && Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    window.decorView.systemUiVisibility = f
}
