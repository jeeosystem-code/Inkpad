package com.inkpad.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Shader
import android.widget.LinearLayout
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import kotlin.math.max
import kotlin.math.min

class BrushPreview(ctx: Context) : View(ctx) {
    var color = Color.BLACK
    var diameter = 6f
    var ring = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val half = min(width, height) / 2f
        p.style = Paint.Style.FILL
        p.color = Theme.field()
        c.drawCircle(cx, cy, half, p)
        val rad = (diameter / 2f).coerceIn(1.5f, half - 3f)
        if (ring) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * resources.displayMetrics.density
            p.color = Theme.text()
            c.drawCircle(cx, cy, rad, p)
        } else {
            p.style = Paint.Style.FILL
            p.color = color
            c.drawCircle(cx, cy, rad, p)
        }
    }
}

class ColorPickerView(ctx: Context, initial: Int, private val onChange: (Int) -> Unit) : View(ctx) {
    private val hsv = FloatArray(3)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sv = RectF()
    private val hue = RectF()
    private var drag = 0

    init {
        Color.colorToHSV(initial, hsv)
    }

    fun color(): Int = Color.HSVToColor(hsv)

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = (w * 0.62f).toInt() + context.dp(14) + context.dp(28)
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sv.set(0f, 0f, w.toFloat(), (h - context.dp(42)).toFloat())
        hue.set(0f, (h - context.dp(28)).toFloat(), w.toFloat(), h.toFloat())
    }

    override fun onDraw(c: Canvas) {
        val r = context.dpf(14f)
        val pure = Color.HSVToColor(floatArrayOf(hsv[0], 1f, 1f))
        val sat = LinearGradient(sv.left, 0f, sv.right, 0f, Color.WHITE, pure, Shader.TileMode.CLAMP)
        val dark = LinearGradient(0f, sv.top, 0f, sv.bottom, Color.WHITE, Color.BLACK, Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        p.shader = ComposeShader(dark, sat, PorterDuff.Mode.MULTIPLY)
        c.drawRoundRect(sv, r, r, p)
        val cols = IntArray(7)
        for (i in 0..6) cols[i] = Color.HSVToColor(floatArrayOf(i * 60f % 360f, 1f, 1f))
        p.shader = LinearGradient(hue.left, 0f, hue.right, 0f, cols, null, Shader.TileMode.CLAMP)
        c.drawRoundRect(hue, hue.height() / 2f, hue.height() / 2f, p)
        p.shader = null
        marker(c, sv.left + hsv[1] * sv.width(), sv.top + (1f - hsv[2]) * sv.height(), color())
        marker(c, hue.left + hsv[0] / 360f * hue.width(), hue.centerY(), pure)
    }

    private fun marker(c: Canvas, x: Float, y: Float, fill: Int) {
        val rad = context.dpf(11f)
        p.style = Paint.Style.FILL
        p.color = fill
        c.drawCircle(x, y, rad, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = context.dpf(3f)
        p.color = Color.WHITE
        c.drawCircle(x, y, rad, p)
        p.strokeWidth = context.dpf(1f)
        p.color = 0x55000000
        c.drawCircle(x, y, rad + context.dpf(1.5f), p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                drag = if (e.y <= sv.bottom + context.dp(7)) 1 else 2
                update(e)
            }
            MotionEvent.ACTION_MOVE -> update(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = 0
        }
        return true
    }

    private fun update(e: MotionEvent) {
        if (drag == 1) {
            hsv[1] = ((e.x - sv.left) / sv.width()).coerceIn(0f, 1f)
            hsv[2] = 1f - ((e.y - sv.top) / sv.height()).coerceIn(0f, 1f)
        } else if (drag == 2) {
            hsv[0] = (((e.x - hue.left) / hue.width()).coerceIn(0f, 1f) * 359.9f)
        }
        invalidate()
        onChange(color())
    }
}

class FlowLayout(ctx: Context) : ViewGroup(ctx) {
    var hGap = 0
    var vGap = 0

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec)
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            measureChild(c, MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            val cw = c.measuredWidth
            val ch = c.measuredHeight
            if (x > 0 && x + cw > maxW) {
                x = 0
                y += rowH + vGap
                rowH = 0
            }
            x += cw + hGap
            rowH = max(rowH, ch)
        }
        setMeasuredDimension(maxW, y + rowH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l
        var x = 0
        var y = 0
        var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            val cw = c.measuredWidth
            val ch = c.measuredHeight
            if (x > 0 && x + cw > maxW) {
                x = 0
                y += rowH + vGap
                rowH = 0
            }
            c.layout(x, y, x + cw, y + ch)
            x += cw + hGap
            rowH = max(rowH, ch)
        }
    }
}

class InteractLayout(ctx: Context) : LinearLayout(ctx) {
    var onTouch: (() -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        onTouch?.invoke()
        return super.dispatchTouchEvent(ev)
    }
}
